"""Portable inference, verification and retraining for the packaged SPFuse models.

Run `python spfuse.py --help`. Original experiment sources are in source_snapshot/.
"""
from pathlib import Path
import argparse,json,sys,gc
import numpy as np
import pandas as pd
import lightgbm as lgb
from scipy.special import expit
from sklearn.metrics import roc_auc_score,average_precision_score,matthews_corrcoef,mean_absolute_error,mean_squared_error,r2_score
ROOT=Path(__file__).resolve().parent
SEEDS=[42,7,2024,13,99]; MIC_SEEDS=[42,7,2024]
def read(p): return json.loads(Path(p).read_text())
def save(p,d):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def logit(p):
 p=np.clip(p,1e-6,1-1e-6);return np.log(p/(1-p))
def fused(z,meta):
 if meta['task']=='classification':z=logit(z)
 v=((z-np.asarray(meta['scaler_mean']))/np.asarray(meta['scaler_scale']))@np.asarray(meta['coef'])+meta['intercept']
 return expit(v) if meta['task']=='classification' else v
def infer(directory,x,threads=4):
 directory=Path(directory);meta=read(directory/'fusion.json')
 branches=np.column_stack([lgb.Booster(model_file=str(directory/f'{b}.lgb')).predict(x[b],num_threads=threads) for b in meta['branches']])
 return fused(branches,meta),branches

def features(smiles,task='classification'):
 from rdkit import Chem,rdBase
 from rdkit.Chem import AllChem,Descriptors,MACCSkeys,rdMolDescriptors
 if rdBase.rdkitVersion!='2022.03.3':raise RuntimeError('Feature reproduction requires RDKit 2022.03.3; use packaged features for other environments.')
 # Classification cache used np.float compatibility; the MIC feature generator did not.
 if task=='classification':np.float=float
 elif hasattr(np,'float'):delattr(np,'float')
 schema=read(ROOT/'data/feature_schema.json');funcs=dict(Descriptors._descList);pp=[];dd=[]
 for i,s in enumerate(smiles):
  mol=Chem.MolFromSmiles(str(s))
  if mol is None:raise ValueError(f'Invalid SMILES at input row {i}: {s}')
  bits=[AllChem.GetMorganFingerprintAsBitVect(mol,2,nBits=2048),AllChem.GetMorganFingerprintAsBitVect(mol,3,nBits=2048),MACCSkeys.GenMACCSKeys(mol),rdMolDescriptors.GetHashedAtomPairFingerprintAsBitVect(mol,nBits=1024),rdMolDescriptors.GetHashedTopologicalTorsionFingerprintAsBitVect(mol,nBits=1024)]
  pp.append(np.concatenate([np.asarray(b) for b in bits]).astype(np.uint8));v=[]
  for name in schema['D']:
   try:value=float(funcs[name](mol))
   except Exception:value=np.nan
   if not np.isfinite(value) or abs(value)>np.finfo(np.float32).max:value=np.nan
   v.append(value)
  dd.append(v)
 return {'P':np.asarray(pp,dtype=np.uint8),'D':np.asarray(dd,dtype=np.float32)}

def predict(args):
 frame=pd.read_csv(args.input)
 if args.smiles_column not in frame:raise ValueError(f'Missing column: {args.smiles_column}')
 x=features(frame[args.smiles_column],args.task);out=frame.copy()
 if args.task=='classification':
  p=[]
  for s in SEEDS:
   v,_=infer(ROOT/f'models/classification/{args.partition}/seed_{s}',x,args.threads);out[f'probability_seed_{s}']=v;p.append(v)
  out['probability_mean']=np.mean(p,axis=0);out['probability_sd']=np.std(p,axis=0,ddof=1);out['predicted_active']=(out.probability_mean>=.5).astype(int)
 else:
  for sp in ['ec','pa']:
   p=[]
   for s in MIC_SEEDS:
    v,_=infer(ROOT/f'models/mic/{sp}/seed_{s}',x,args.threads);out[f'{sp}_log2_mic_seed_{s}']=v;p.append(v)
   out[f'{sp}_log2_mic_mean']=np.mean(p,axis=0);out[f'{sp}_log2_mic_sd']=np.std(p,axis=0,ddof=1)
  out['delta_pa_minus_ec_mean']=out.pa_log2_mic_mean-out.ec_log2_mic_mean
 output=Path(args.output)
 if output.exists():raise FileExistsError(output)
 output.parent.mkdir(parents=True,exist_ok=True);out.to_csv(output,index=False);print(output)

def metrics(y,p,task):
 if task=='classification':return {'AUROC':float(roc_auc_score(y,p)),'AP':float(average_precision_score(y,p)),'MCC':float(matthews_corrcoef(y,p>=.5))}
 return {'MAE':float(mean_absolute_error(y,p)),'RMSE':float(np.sqrt(mean_squared_error(y,p))),'R2':float(r2_score(y,p))}

def verify(args):
 import joblib
 from sklearn.pipeline import make_pipeline
 from sklearn.preprocessing import StandardScaler
 from sklearn.linear_model import LogisticRegression,Ridge
 records=[];checks=[];versions={}
 import importlib.metadata as md
 for name in ['numpy','pandas','scipy','scikit-learn','lightgbm','rdkit','joblib']:versions[name]=md.version(name)
 labels=pd.read_csv(ROOT/'data/classification_molecules.csv');cache=np.load(ROOT/'data/classification_features.npz');xx={b:cache[b] for b in ['P','D']}
 if args.feature_check:
  ii=np.random.default_rng(20261109).choice(len(labels),32,replace=False);fresh=features(labels.PROCESSED_SMILES.iloc[ii])
  for b in xx:np.testing.assert_allclose(fresh[b],xx[b][ii],rtol=1e-6,atol=1e-7,equal_nan=True)
  checks.append({'check':'classification featurization','rows':len(ii),'passed':True})
 for cohort in ['official','scaffold']:
  mem=pd.read_csv(ROOT/f'data/{cohort}_membership.csv');np.testing.assert_array_equal(labels.COMPOUND_ID,mem.COMPOUND_ID)
  folds=np.load(ROOT/f'oof/classification_{cohort}_folds.npz');tr=np.flatnonzero(mem.group.eq('training'));np.testing.assert_array_equal(tr,folds['training_rows']);y=labels.TARGET.to_numpy()
  if cohort=='scaffold':
   groups={g:set(mem.loc[mem.group.eq(g),'boundary_group']) for g in ['training','valid','test']}
   for a,b in [('training','valid'),('training','test'),('valid','test')]:assert not groups[a]&groups[b]
   for k in range(5):assert not set(mem.boundary_group.iloc[tr[folds['fold']==k]])&set(mem.boundary_group.iloc[tr[folds['fold']!=k]])
  for s in SEEDS:
   directory=ROOT/f'models/classification/{cohort}/seed_{s}';meta=joblib.load(directory/'fusion.joblib');o=np.load(ROOT/f'oof/classification_{cohort}_{s}.npz');np.testing.assert_array_equal(tr,o['training_rows'])
   z=logit(np.column_stack([o['P'],o['D']]));refit=make_pipeline(StandardScaler(),LogisticRegression(C=1.,solver='lbfgs',max_iter=2000,random_state=s)).fit(z,y[tr])
   np.testing.assert_allclose(meta.predict_proba(z),refit.predict_proba(z),rtol=0,atol=1e-12)
   for group in ['valid','test']:
    ix=np.flatnonzero(mem.group.eq(group));ref=pd.read_csv(ROOT/f'reference_predictions/classification_{cohort}_{group}.csv');np.testing.assert_array_equal(mem.COMPOUND_ID.iloc[ix],ref.COMPOUND_ID);np.testing.assert_array_equal(y[ix],ref.TARGET)
    p,bp=infer(directory,{b:v[ix] for b,v in xx.items()},args.threads)
    np.testing.assert_allclose(p,ref[f'seed_{s}'],rtol=0,atol=1e-12);np.testing.assert_allclose(p,meta.predict_proba(logit(bp))[:,1],rtol=0,atol=1e-12)
    records.append({'task':'classification','partition':cohort,'split':group,'seed':s,'rows':len(ix),'max_prediction_error':float(np.max(np.abs(p-ref[f'seed_{s}']))),**metrics(y[ix],p,'classification')})
   print('Verified classification',cohort,s,flush=True)
 del xx;gc.collect()
 mem=pd.read_csv(ROOT/'data/mic_membership.csv');cache=np.load(ROOT/'data/mic_features.npz');xx={b:cache[b] for b in ['P','D']};tr=np.flatnonzero(mem.split.eq('training'));te=np.flatnonzero(mem.split.eq('test'))
 folds=np.load(ROOT/'oof/mic_folds.npz');np.testing.assert_array_equal(tr,folds['training_rows'])
 for k in range(5):assert not set(mem.boundary_group.iloc[tr[folds['fold']==k]])&set(mem.boundary_group.iloc[tr[folds['fold']!=k]])
 if args.feature_check:
  ii=np.random.default_rng(20261109).choice(len(mem),32,replace=False);fresh=features(mem.canonical.iloc[ii],task='mic')
  for b in xx:np.testing.assert_allclose(fresh[b],xx[b][ii],rtol=1e-6,atol=1e-7,equal_nan=True)
  checks.append({'check':'MIC featurization','rows':len(ii),'passed':True})
 pred={}
 for sp in ['ec','pa']:
  for s in MIC_SEEDS:
   directory=ROOT/f'models/mic/{sp}/seed_{s}';p,bp=infer(directory,xx,args.threads);ref=np.load(ROOT/f'reference_predictions/mic_{sp}_{s}.npz');y=mem[f'{sp}_log2_mic'].to_numpy();meta=joblib.load(directory/'fusion.joblib')
   np.testing.assert_allclose(p,ref['PD_fusion'],rtol=0,atol=1e-12);np.testing.assert_allclose(bp,np.column_stack([ref['P'],ref['D']]),rtol=0,atol=1e-12);np.testing.assert_allclose(p,meta.predict(bp),rtol=0,atol=1e-12)
   refit=make_pipeline(StandardScaler(),Ridge(alpha=1.)).fit(ref['oof'],y[tr]);np.testing.assert_allclose(p,refit.predict(bp),rtol=0,atol=1e-12)
   pred[sp,s]=p
   records.append({'task':'mic','endpoint':sp,'split':'test','seed':s,'rows':len(te),'max_prediction_error':float(np.max(np.abs(p-ref['PD_fusion']))),**metrics(y[te],p[te],'mic')})
   print('Verified MIC',sp,s,flush=True)
 for s in MIC_SEEDS:records.append({'task':'mic','endpoint':'delta','split':'test','seed':s,'rows':len(te),**metrics((mem.pa_log2_mic-mem.ec_log2_mic).to_numpy()[te],(pred['pa',s]-pred['ec',s])[te],'mic')})
 summaries=[]
 for cohort in ['official','scaffold']:
  rr=[r for r in records if r['task']=='classification' and r['partition']==cohort and r['split']=='test'];summaries.append({'task':'classification','partition':cohort,**{m:{'mean':float(np.mean([r[m] for r in rr])),'sd':float(np.std([r[m] for r in rr],ddof=1))} for m in ['AUROC','AP','MCC']}})
 for sp in ['ec','pa','delta']:
  rr=[r for r in records if r['task']=='mic' and r['endpoint']==sp];summaries.append({'task':'mic','endpoint':sp,**{m:{'mean':float(np.mean([r[m] for r in rr])),'sd':float(np.std([r[m] for r in rr],ddof=1))} for m in ['MAE','RMSE','R2']}})
 save(args.output,{'passed':True,'scope':'All packaged SPFuse validation/test predictions and all MIC predictions; refitted fusion layers; optionally 32 new featurizations/task. Baseline checkpoint inference is separate.','versions':versions,'checks':checks,'results':records,'summary':summaries});print(json.dumps(summaries,indent=2))

def train(args):
 from sklearn.pipeline import make_pipeline
 from sklearn.preprocessing import StandardScaler
 from sklearn.linear_model import LogisticRegression,Ridge
 import joblib
 out=Path(args.output)
 if out.exists():raise FileExistsError('Choose a new output directory: '+str(out))
 out.mkdir(parents=True);conf=read(ROOT/'training_config.json')[args.task];seed=args.seed
 if args.task=='classification':
  mem=pd.read_csv(ROOT/f'data/{args.partition}_membership.csv');labels=pd.read_csv(ROOT/'data/classification_molecules.csv');y=labels.TARGET.to_numpy();tr=np.flatnonzero(mem.group.eq('training'));cache=np.load(ROOT/'data/classification_features.npz');folds=np.load(ROOT/f'oof/classification_{args.partition}_folds.npz')
  params=dict(conf['hyperparameters'].get(str(seed),conf['hyperparameters']['42']),seed=seed,bagging_seed=seed+1,feature_fraction_seed=seed+2)
  meta=make_pipeline(StandardScaler(),LogisticRegression(C=1.,solver='lbfgs',max_iter=2000,random_state=seed))
 else:
  mem=pd.read_csv(ROOT/'data/mic_membership.csv');y=mem[f'{args.endpoint}_log2_mic'].to_numpy();tr=np.flatnonzero(mem.split.eq('training'));cache=np.load(ROOT/'data/mic_features.npz');folds=np.load(ROOT/'oof/mic_folds.npz')
  params=dict(conf['lgb'],seed=seed,bagging_seed=seed,feature_fraction_seed=seed,data_random_seed=seed);meta=make_pipeline(StandardScaler(),Ridge(alpha=1.))
 np.testing.assert_array_equal(tr,folds['training_rows']);fold=folds['fold'];oof=np.full((len(tr),2),np.nan);allp=[]
 save(out/'training_config.json',{'task':args.task,'partition':args.partition,'endpoint':args.endpoint,'seed':seed,'base_config':conf,'note':'Packaged train-only folds reused; no validation/test tuning. OOF uses 4 threads; final classification uses 8, MIC P uses 6 and D uses 4, matching source.'})
 for j,b in enumerate(['P','D']):
  x=cache[b].astype(np.float32)
  for k in range(5):
   fit=tr[fold!=k];hold=tr[fold==k];booster=lgb.train(dict(params,num_threads=4),lgb.Dataset(x[fit],label=y[fit]),num_boost_round=conf['num_boost_round']);oof[fold==k,j]=booster.predict(x[hold],num_threads=4);print('OOF',b,k,flush=True)
  nt=8 if args.task=='classification' else (6 if b=='P' else 4)
  booster=lgb.train(dict(params,num_threads=nt),lgb.Dataset(x[tr],label=y[tr]),num_boost_round=conf['num_boost_round']);booster.save_model(str(out/f'{b}.lgb'));allp.append(booster.predict(x,num_threads=4));del x;gc.collect()
 z=logit(oof) if args.task=='classification' else oof;meta.fit(z,y[tr]);joblib.dump(meta,out/'fusion.joblib');sc,lr=[v for _,v in meta.steps]
 spec={'task':'classification' if args.task=='classification' else 'regression','branches':['P','D'],'scaler_mean':sc.mean_.tolist(),'scaler_scale':sc.scale_.tolist(),'coef':np.asarray(lr.coef_).reshape(-1).tolist(),'intercept':float(np.asarray(lr.intercept_).reshape(-1)[0])};save(out/'fusion.json',spec)
 p=fused(np.column_stack(allp),spec);np.savez_compressed(out/'predictions.npz',training_rows=tr,oof=oof,prediction=p,P=allp[0],D=allp[1]);print(out)

def main():
 p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
 q=sub.add_parser('predict');q.add_argument('--task',choices=['classification','mic'],required=True);q.add_argument('--partition',choices=['official','scaffold'],default='official');q.add_argument('--input',required=True);q.add_argument('--smiles-column',default='SMILES');q.add_argument('--output',required=True);q.add_argument('--threads',type=int,default=4);q.set_defaults(func=predict)
 q=sub.add_parser('verify');q.add_argument('--feature-check',action='store_true');q.add_argument('--threads',type=int,default=4);q.add_argument('--output',default='verification.json');q.set_defaults(func=verify)
 q=sub.add_parser('train');q.add_argument('--task',choices=['classification','mic'],required=True);q.add_argument('--partition',choices=['official','scaffold'],default='official');q.add_argument('--endpoint',choices=['ec','pa'],default='ec');q.add_argument('--seed',type=int,default=42);q.add_argument('--output',required=True);q.set_defaults(func=train)
 a=p.parse_args();a.func(a)
if __name__=='__main__':main()
