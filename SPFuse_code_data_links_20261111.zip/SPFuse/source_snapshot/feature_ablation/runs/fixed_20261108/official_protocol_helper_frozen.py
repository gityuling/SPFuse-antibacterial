"""Frozen comparison on the authors' released molecular split.

prepare -> train (all seeds, no test labels) -> evaluate (sealed predictions).
The official split is retained exactly; this is not a scaffold split.
"""
import argparse
import gc
import hashlib
import importlib.metadata
import json
import platform
import shutil
import time
from datetime import datetime, timezone
from pathlib import Path

import joblib
import lightgbm as lgb
import numpy as np
import pandas as pd
from rdkit import Chem
from rdkit.Chem import AllChem, Descriptors, MACCSkeys, rdMolDescriptors
from rdkit.Chem.Scaffolds import MurckoScaffold
from scipy.sparse import csr_matrix
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (average_precision_score, confusion_matrix, f1_score,
                             matthews_corrcoef, precision_score, recall_score, roc_auc_score)
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_RUN = ROOT / 'official_comparison/runs/fixed_20261105'
SEEDS = [42, 7, 2024, 13, 99]
VARIANTS = ['retrieval_lgbm', 'no_retrieval_lgbm', 'rf85']
NAMES = ['top1_similarity', 'top1_target', 'top3_active_fraction', 'top5_active_fraction',
         'top10_active_fraction', 'top20_active_fraction', 'top5_mean_similarity',
         'nearest_active_similarity', 'nearest_inactive_similarity', 'weighted_active_fraction',
         'top10_active_fraction_duplicate', 'count_ge_0.5', 'count_ge_0.6', 'count_ge_0.7',
         'top10_mean_similarity', 'top20_active_mean_similarity']


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(2**20), b''):
            h.update(block)
    return h.hexdigest()


def write(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    tmp.replace(path)


def read(path):
    return json.loads(Path(path).read_text())


def verify_hashes(base, hashes):
    for name, expected in hashes.items():
        if sha(base / name) != expected:
            raise ValueError(f'Changed input/artifact: {name}')


def parameters(seed):
    return dict(objective='binary', metric='auc', learning_rate=.03, num_leaves=511,
                min_data_in_leaf=10, feature_fraction=.25, bagging_fraction=.8, bagging_freq=1,
                lambda_l2=5, max_bin=63, num_threads=8, verbosity=-1, force_row_wise=True,
                seed=seed, bagging_seed=seed+1, feature_fraction_seed=seed+2)


def metrics(y, p):
    return dict(auc=float(roc_auc_score(y, p)), ap=float(average_precision_score(y, p)),
                mcc=float(matthews_corrcoef(y, p >= .5)),
                precision=float(precision_score(y, p >= .5, zero_division=0)),
                recall=float(recall_score(y, p >= .5)), f1=float(f1_score(y, p >= .5)),
                confusion_matrix=confusion_matrix(y, p >= .5).tolist())


def retrieval_block(X, train_labels, query, reference):
    """Labels must exist only for allowed training rows; query labels are never accessed."""
    if np.intersect1d(query, reference).size:
        raise ValueError('Retrieval includes the query itself')
    by = train_labels[reference]
    if not np.isin(by, [0, 1]).all() or not (np.any(by == 0) and np.any(by == 1)):
        raise ValueError('References include a held-out row or lack both classes')
    B = X[reference].T.tocsr()
    bsum = np.asarray(B.sum(0)).ravel().astype(np.float32)
    features, ids, sims = [], [], []
    for start in range(0, len(query), 128):
        q = query[start:start+128]
        A = X[q]
        inter = (A @ B).toarray().astype(np.float32)
        asum = np.asarray(A.sum(1)).ravel().astype(np.float32)
        sim = inter / np.maximum(asum[:, None] + bsum[None, :] - inter, 1e-6)
        top = np.argpartition(sim, -20, axis=1)[:, -20:]
        ts = np.take_along_axis(sim, top, axis=1)
        order = np.argsort(-ts, axis=1)
        top = np.take_along_axis(top, order, axis=1)
        ts = np.take_along_axis(ts, order, axis=1)
        tl = by[top]
        f = np.zeros((len(q), 16), np.float32)
        f[:, 0], f[:, 1] = ts[:, 0], tl[:, 0]
        for col, k in [(2, 3), (3, 5), (4, 10), (5, 20)]:
            f[:, col] = tl[:, :k].mean(1)
        f[:, 6] = ts[:, :5].mean(1)
        f[:, 7], f[:, 8] = sim[:, by == 1].max(1), sim[:, by == 0].max(1)
        f[:, 9] = (ts * tl).sum(1) / np.maximum(ts.sum(1), 1e-6)
        f[:, 10] = tl[:, :10].mean(1)
        for col, threshold in [(11, .5), (12, .6), (13, .7)]:
            f[:, col] = (sim >= threshold).sum(1)
        f[:, 14] = ts[:, :10].mean(1)
        f[:, 15] = (ts * (tl == 1)).sum(1) / np.maximum((tl == 1).sum(1), 1)
        features.append(f); ids.append(reference[top]); sims.append(ts)
    return np.vstack(features), np.vstack(ids), np.vstack(sims).astype(np.float32)


def prepare(run):
    if (run / 'protocol.json').exists():
        raise ValueError('Existing run: use train/evaluate; do not overwrite a frozen protocol')
    run.mkdir(parents=True, exist_ok=True)
    source_paths = ['data/raw/SA_FG_fragments.csv', 'data/raw/S_aureus.csv',
                    'data/processed/s_aureus_master.csv', 'optimization/cache/rd_fp.npy',
                    'optimization/cache/rd_extra_fp.npy', 'optimization/cache/rd_desc.npy',
                    'optimization/cache/rd_desc_names.json',
                    'path_a/runs/scaffold_clean_20261104/experiment_config.json',
                    'upstream/RF_model/RF_CV.py']
    input_hashes = {name: sha(ROOT / name) for name in source_paths}
    raw = pd.read_csv(ROOT / source_paths[0], low_memory=False)
    master = pd.read_csv(ROOT / source_paths[2], low_memory=False)
    frag = [c for c in raw if c.startswith('fr_')]
    assert len(frag) == 85 and len(master) == 43777
    pd.testing.assert_frame_equal(raw[['COMPOUND_ID', 'PROCESSED_SMILES', 'TARGET', 'group']+frag],
                                  master[['COMPOUND_ID', 'PROCESSED_SMILES', 'TARGET', 'group']+frag])
    assert master.COMPOUND_ID.is_unique
    assert master.group.value_counts().to_dict() == {'training': 35006, 'test': 4393, 'valid': 4378}
    old = read(ROOT / source_paths[7])
    for seed in SEEDS:
        assert parameters(seed) == old['parameters'][str(seed)]
    for name in source_paths[3:6]:
        assert input_hashes[name] == old['input_hashes'][name]
    protocol = dict(created_utc=now(), input_hashes=input_hashes, seeds=SEEDS, variants=VARIANTS,
                    split_source='Author released SA_FG_fragments.csv group labels, unchanged',
                    training_rows=35006, validation_rows=4378, test_rows=4393,
                    fit_policy='Only training rows; all weights=1; no external data or pretrained checkpoints',
                    validation_policy='Report only; no new tuning or early stopping in this fixed-config run',
                    hyperparameter_source='Current path_a fixed LightGBM configuration; not newly selected on this split',
                    parameters={str(s): parameters(s) for s in SEEDS}, rounds=900, threshold=.5,
                    retrieval=dict(k=20, oof='StratifiedGroupKFold', folds=5, seed=42,
                                   groups='Nonchiral Murcko; acyclic nonisomeric connectivity',
                                   reference='Only training rows; OOF complements for training queries'),
                    rf=dict(n_estimators=100, max_depth=None, min_samples_split=2,
                            max_features='sqrt', scaler='StandardScaler fitted on training only',
                            reference='Author RF_CV.py model settings, fitted on full training for matched data size'),
                    primary_summary='All five individual runs: mean and sample SD',
                    secondary_summary='Arithmetic mean of all five probability vectors; no seed selection',
                    evaluation_order='Save and hash every prediction/model before opening test labels for scoring',
                    history='Existing model recipe reused; this rerun does not reset prior development history',
                    bootstrap=dict(draws=1000, seed=20261105, unit='Murcko / acyclic connectivity group', paired=True),
                    paper_reference=dict(RF={'auc': .866, 'auc_sd': .003, 'mcc': .545, 'mcc_sd': .014},
                                         CNN={'auc': .860, 'auc_sd': .015, 'mcc': .532, 'mcc_sd': .035},
                                         RGCN={'auc': .901, 'auc_sd': .068, 'mcc': .623, 'mcc_sd': .150}),
                    paper_precision_column={'RF': .923, 'CNN': .918, 'RGCN': .947},
                    paper_comparison='Reported means only; not a claim that published CV runs have identical training membership',
                    source_script_sha256=sha(__file__))
    write(run / 'protocol.json', protocol)
    shutil.copy2(__file__, run / 'run_official_split.py')
    write(run / 'status.json', {'state': 'preparing', 'utc': now()})
    write(run / 'environment.json', {'python': platform.python_version(),
          'packages': {n: importlib.metadata.version(n) for n in ['numpy', 'pandas', 'scipy', 'scikit-learn', 'lightgbm', 'rdkit', 'joblib']}})
    fp = np.load(ROOT / source_paths[3], mmap_mode='r')
    extra = np.load(ROOT / source_paths[4], mmap_mode='r')
    desc = np.load(ROOT / source_paths[5], mmap_mode='r')
    assert fp.shape == (43777, 4263) and extra.shape == (43777, 2048) and desc.shape == (43777, 208)
    assert read(ROOT / source_paths[6]) == [n for n, _ in Descriptors._descList]
    # Check cached feature semantics and row alignment against fresh RDKit calculations.
    np.float = float  # RDKit 2022 legacy descriptor compatibility, matching the feature generator.
    sample = np.random.default_rng(20261105).choice(len(master), 64, replace=False)
    for row in sample:
        m = Chem.MolFromSmiles(master.PROCESSED_SMILES.iloc[row])
        expected = np.r_[np.asarray(AllChem.GetMorganFingerprintAsBitVect(m, 2, nBits=2048)),
                         np.asarray(AllChem.GetMorganFingerprintAsBitVect(m, 3, nBits=2048)),
                         np.asarray(MACCSkeys.GenMACCSKeys(m))]
        np.testing.assert_array_equal(fp[row], expected)
        expected_extra = np.r_[np.asarray(rdMolDescriptors.GetHashedAtomPairFingerprintAsBitVect(m, nBits=1024)),
                               np.asarray(rdMolDescriptors.GetHashedTopologicalTorsionFingerprintAsBitVect(m, nBits=1024))]
        np.testing.assert_array_equal(extra[row], expected_extra)
        vals = []
        for name, fn in Descriptors._descList:
            try:
                v = float(fn(m))
            except Exception:
                v = np.nan
            vals.append(v if np.isfinite(v) else np.nan)
        np.testing.assert_allclose(desc[row], vals, rtol=1e-6, atol=1e-7, equal_nan=True)
    Xbase = np.hstack([raw[frag].to_numpy(np.float32), fp, extra, desc]).astype(np.float32)
    assert Xbase.shape[1] == 6604 and not np.isinf(Xbase).any()
    np.save(run / 'base_features.npy', Xbase)
    del Xbase; gc.collect()
    chemistry = []
    for row, s in enumerate(master.PROCESSED_SMILES):
        m = Chem.MolFromSmiles(s)
        iso = Chem.MolToSmiles(m, isomericSmiles=True)
        conn = Chem.MolToSmiles(m, isomericSmiles=False)
        scaffold = MurckoScaffold.MurckoScaffoldSmiles(mol=m, includeChirality=False)
        chemistry.append((row, iso, conn, 'MURCKO:'+scaffold if scaffold else 'ACYCLIC_STRUCTURE:'+conn))
    chemistry = pd.DataFrame(chemistry, columns=['row', 'canonical', 'connectivity', 'boundary_group'])
    members = master[['COMPOUND_ID', 'PROCESSED_SMILES', 'group']].copy()
    members.insert(0, 'row', np.arange(len(master)))
    members['boundary_group'] = chemistry.boundary_group
    members.to_csv(run / 'membership.csv', index=False)
    chemistry.to_csv(run / 'chemistry.csv', index=False)
    train = np.flatnonzero(master.group.eq('training'))
    valid = np.flatnonzero(master.group.eq('valid'))
    test = np.flatnonzero(master.group.eq('test'))
    ytrain = np.full(len(master), -1, dtype=np.int8)
    ytrain[train] = master.TARGET.iloc[train]
    np.save(run / 'training_targets.npy', ytrain)
    np.save(run / 'validation_targets.npy', master.TARGET.iloc[valid].to_numpy(np.int8))
    audit = {'split_equals_raw_release': True, 'canonical_overlap': {}, 'same_connectivity_rows': {},
             'feature_checks': {'sample_rows': sample.tolist(), 'fresh_rdkit_matches': True,
                                'full_cache_hashes_match_previous_verified_run': True},
             'official_split_preserved': True, 'external_training_rows': 0,
             'test_labels_present_in_training_target_array': False}
    for label, idx in [('valid', valid), ('test', test)]:
        audit['canonical_overlap'][label] = int(chemistry.canonical.iloc[idx].isin(chemistry.canonical.iloc[train]).sum())
        audit['same_connectivity_rows'][label] = int(chemistry.connectivity.iloc[idx].isin(chemistry.connectivity.iloc[train]).sum())
        assert audit['canonical_overlap'][label] == 0
    audit['scaffold_overlap_policy'] = 'Natural scaffold/analogue overlap in the released random split retained, no post-hoc filtering'
    write(run / 'data_audit.json', audit)
    groups = members.boundary_group.to_numpy()
    folds = np.full(len(master), -1, np.int8)
    F = np.zeros((len(master), 16), np.float32)
    neighbors = np.full((len(master), 20), -1, np.int32)
    similarities = np.zeros((len(master), 20), np.float32)
    # int32 avoids overflow when a fingerprint has more than 255 set bits.
    sparse = csr_matrix(fp[:, :2048], dtype=np.int32)
    cv = StratifiedGroupKFold(5, shuffle=True, random_state=42)
    for fold, (a, b) in enumerate(cv.split(train, ytrain[train], groups[train])):
        q, ref = train[b], train[a]
        assert not set(groups[q]) & set(groups[ref])
        folds[q] = fold
        F[q], neighbors[q], similarities[q] = retrieval_block(sparse, ytrain, q, ref)
        print(f'Prepared OOF fold {fold+1}/5 ({len(q)} rows)', flush=True)
    for label, q in [('valid', valid), ('test', test)]:
        F[q], neighbors[q], similarities[q] = retrieval_block(sparse, ytrain, q, train)
        print(f'Prepared {label} retrieval ({len(q)} rows); no query labels used', flush=True)
    assert np.isfinite(F).all() and np.isin(neighbors, train).all()
    assert not np.any(neighbors == np.arange(len(master))[:, None])
    assert not np.any(folds[train, None] == folds[neighbors[train]])
    for name, arr in [('retrieval_features', F), ('neighbor_rows', neighbors), ('neighbor_similarity', similarities), ('oof_folds', folds)]:
        np.save(run / (name+'.npy'), arr)
    names = frag + [f'fp_{i}' for i in range(fp.shape[1])] + [f'extra_fp_{i}' for i in range(extra.shape[1])] + [n for n, _ in Descriptors._descList]
    write(run / 'feature_schema.json', {'base': names, 'retrieval': NAMES, 'total': 6620})
    files = ['protocol.json', 'membership.csv', 'chemistry.csv', 'training_targets.npy', 'validation_targets.npy',
             'base_features.npy', 'retrieval_features.npy', 'neighbor_rows.npy', 'neighbor_similarity.npy', 'oof_folds.npy',
             'feature_schema.json', 'data_audit.json', 'run_official_split.py', 'environment.json']
    verify_hashes(ROOT, input_hashes)
    write(run / 'prepared_manifest.json', {'utc': now(), 'hashes': {f: sha(run/f) for f in files}})
    write(run / 'status.json', {'state': 'prepared', 'utc': now()})


def train(run):
    if (run / 'prediction_seal.json').exists():
        raise ValueError('Predictions already sealed; do not retrain after evaluation')
    verify_hashes(run, read(run/'prepared_manifest.json')['hashes'])
    config = read(run/'protocol.json')
    verify_hashes(ROOT, config['input_hashes'])
    if sha(__file__) != config['source_script_sha256']:
        repair = read(run/'runtime_repair.json')
        assert repair['original_script_sha256'] == config['source_script_sha256']
        assert repair['updated_script_sha256'] == sha(__file__)
        assert repair['test_metrics_computed_before_repair'] is False
    members = pd.read_csv(run/'membership.csv')
    tr, va, te = [np.flatnonzero(members.group.eq(s)) for s in ['training', 'valid', 'test']]
    y = np.load(run/'training_targets.npy')
    assert np.isin(y[tr], [0, 1]).all() and np.all(y[np.r_[va, te]] == -1)
    Xbase = np.load(run/'base_features.npy', mmap_mode='r')
    K = np.load(run/'retrieval_features.npy')
    records = []
    for variant in config['variants']:
        directory = run/variant
        directory.mkdir(exist_ok=True)
        if variant == 'retrieval_lgbm':
            Xtr = np.hstack([Xbase[tr], K[tr]])
            Xva, Xte = np.hstack([Xbase[va], K[va]]), np.hstack([Xbase[te], K[te]])
        else:
            cols = slice(0, 85) if variant == 'rf85' else slice(None)
            Xtr, Xva, Xte = Xbase[tr, cols], Xbase[va, cols], Xbase[te, cols]
        for seed in config['seeds']:
            record_path = directory/f'seed_{seed}_record.json'
            if record_path.exists():
                record = read(record_path)
                assert record['variant'] == variant and record['seed'] == seed
                assert sha(run/record['prediction_file']) == record['prediction_sha256']
                assert sha(run/record['model_file']) == record['model_sha256']
                saved = np.load(run/record['prediction_file'])
                np.testing.assert_array_equal(saved['test_rows'], te)
                np.testing.assert_array_equal(saved['valid_rows'], va)
                records.append(record)
                print(f'Resumed verified {variant} seed {seed}', flush=True)
                continue
            started = time.time()
            write(run/'status.json', {'state': 'training', 'variant': variant, 'seed': seed,
                                     'completed_models': len(records), 'total_models': 15, 'utc': now()})
            if variant == 'rf85':
                model = make_pipeline(StandardScaler(), RandomForestClassifier(n_estimators=100, max_depth=None,
                                      min_samples_split=2, max_features='sqrt', random_state=seed, n_jobs=8))
                model.fit(Xtr, y[tr])
                model_path = directory/f'seed_{seed}.joblib'
                joblib.dump(model, model_path, compress=3)
                pv, pt = model.predict_proba(Xva)[:, 1], model.predict_proba(Xte)[:, 1]
                reloaded = joblib.load(model_path)
                check = reloaded.predict_proba(Xte[::37])[:, 1]
            else:
                model = lgb.train(config['parameters'][str(seed)], lgb.Dataset(Xtr, label=y[tr]), num_boost_round=config['rounds'])
                model_path = directory/f'seed_{seed}.lgb'
                model.save_model(str(model_path))
                pv, pt = model.predict(Xva), model.predict(Xte)
                reloaded = lgb.Booster(model_file=str(model_path))
                check = reloaded.predict(Xte[::37])
            # Parallel RF probability reductions can differ by one floating-point ULP.
            np.testing.assert_allclose(check, pt[::37], rtol=0, atol=1e-12)
            assert np.isfinite(pv).all() and np.isfinite(pt).all()
            assert np.all((pt >= 0) & (pt <= 1))
            path = directory/f'seed_{seed}_predictions.npz'
            np.savez_compressed(path, valid=pv, test=pt, valid_rows=va, test_rows=te)
            record = {'variant': variant, 'seed': seed, 'seconds': round(time.time()-started, 2),
                      'prediction_file': str(path.relative_to(run)), 'prediction_sha256': sha(path),
                      'model_file': str(model_path.relative_to(run)), 'model_sha256': sha(model_path),
                      'reload_max_absolute_error': float(np.max(np.abs(check-pt[::37])))}
            records.append(record)
            write(directory/f'seed_{seed}_record.json', record)
            print(json.dumps({'completed_models': len(records), **record}), flush=True)
            del model, reloaded
            gc.collect()
        del Xtr, Xva, Xte
        gc.collect()
    verify_hashes(ROOT, config['input_hashes'])
    seal = {'utc': now(), 'protocol_sha256': sha(run/'protocol.json'), 'prepared_manifest_sha256': sha(run/'prepared_manifest.json'),
            'all_seeds_retained': True, 'test_metrics_computed_during_training': False, 'models': records}
    write(run/'prediction_seal.json', seal)
    write(run/'status.json', {'state': 'predictions_sealed', 'completed_models': len(records), 'utc': now()})


def evaluate(run):
    if (run/'results.json').exists():
        raise ValueError('Run already evaluated; read results.json')
    seal = read(run/'prediction_seal.json')
    config = read(run/'protocol.json')
    assert sha(run/'protocol.json') == seal['protocol_sha256']
    assert sha(run/'prepared_manifest.json') == seal['prepared_manifest_sha256']
    verify_hashes(run, read(run/'prepared_manifest.json')['hashes'])
    verify_hashes(ROOT, config['input_hashes'])
    assert {(r['variant'], r['seed']) for r in seal['models']} == {(v, s) for v in VARIANTS for s in SEEDS}
    for r in seal['models']:
        assert sha(run/r['prediction_file']) == r['prediction_sha256']
        assert sha(run/r['model_file']) == r['model_sha256']
    members = pd.read_csv(run/'membership.csv')
    raw = pd.read_csv(ROOT/'data/raw/SA_FG_fragments.csv', usecols=['COMPOUND_ID', 'TARGET', 'group'])
    assert np.array_equal(raw.COMPOUND_ID, members.COMPOUND_ID)
    indices = {split: np.flatnonzero(members.group.eq(split)) for split in ['valid', 'test']}
    results, ensemble = {}, {}
    for variant in VARIANTS:
        runs, probs = [], {s: [] for s in indices}
        for seed in SEEDS:
            predictions = np.load(run/variant/f'seed_{seed}_predictions.npz')
            record = {'seed': seed}
            for split, idx in indices.items():
                np.testing.assert_array_equal(predictions[split+'_rows'], idx)
                p = predictions[split]
                probs[split].append(p)
                record[split] = metrics(raw.TARGET.iloc[idx].to_numpy(), p)
            runs.append(record)
        item = {'runs': runs, 'mean': {}, 'sd': {}, 'ensemble': {}}
        for split, idx in indices.items():
            item['mean'][split] = {m: float(np.mean([r[split][m] for r in runs])) for m in ['auc', 'ap', 'mcc']}
            item['sd'][split] = {m: float(np.std([r[split][m] for r in runs], ddof=1)) for m in ['auc', 'ap', 'mcc']}
            p = np.mean(probs[split], axis=0)
            item['ensemble'][split] = metrics(raw.TARGET.iloc[idx].to_numpy(), p)
            out = pd.DataFrame({'COMPOUND_ID': raw.COMPOUND_ID.iloc[idx], 'TARGET': raw.TARGET.iloc[idx], 'probability': p})
            for seed, pp in zip(SEEDS, probs[split]):
                out[f'seed_{seed}'] = pp
            out.to_csv(run/variant/(split+'_predictions.csv'), index=False)
            if split == 'test':
                ensemble[variant] = p
        results[variant] = item
    te = indices['test']; y = raw.TARGET.iloc[te].to_numpy()
    groups = members.boundary_group.iloc[te].to_numpy()
    unique = np.unique(groups)
    group_rows = [np.flatnonzero(groups == g) for g in unique]
    boot = {v: {m: [] for m in ['auc', 'ap', 'mcc']} for v in VARIANTS}
    rng = np.random.default_rng(config['bootstrap']['seed'])
    for _ in range(config['bootstrap']['draws']):
        rows = np.concatenate([group_rows[i] for i in rng.integers(0, len(unique), len(unique))])
        if len(np.unique(y[rows])) != 2:
            continue
        for variant, p in ensemble.items():
            measured = metrics(y[rows], p[rows])
            for m in boot[variant]:
                boot[variant][m].append(measured[m])
    intervals = {v: {m: np.quantile(scores, [.025, .975]).tolist() for m, scores in mm.items()} for v, mm in boot.items()}
    differences = {}
    for reference in ['no_retrieval_lgbm', 'rf85']:
        differences[reference] = {}
        for m in ['auc', 'ap', 'mcc']:
            scores = np.array(boot['retrieval_lgbm'][m])-np.array(boot[reference][m])
            differences[reference][m] = {'delta': results['retrieval_lgbm']['ensemble']['test'][m]-results[reference]['ensemble']['test'][m],
                                        'ci95': np.quantile(scores, [.025, .975]).tolist()}
    final = {'completed_utc': now(), 'prediction_seal_sha256': sha(run/'prediction_seal.json'),
             'n_training': 35006, 'n_valid': 4378, 'n_test': 4393, 'test_positives': int(y.sum()),
             'results': results, 'ensemble_group_bootstrap_ci95': intervals,
             'paired_ensemble_differences': differences, 'bootstrap_test_groups': len(unique),
             'paper_reference': config['paper_reference'],
             'claims_scope': 'Same released train/valid/test allocation for the three retrained models; published paper means are contextual references, not matched re-training'}
    write(run/'results.json', final)
    write(run/'status.json', {'state': 'complete', 'verified': True, 'models': 15, 'utc': now()})
    print(json.dumps({v: {'mean': r['mean']['test'], 'sd': r['sd']['test'], 'ensemble': r['ensemble']['test']} for v, r in results.items()}, indent=2), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=['prepare', 'train', 'evaluate'])
    parser.add_argument('--run', type=Path, default=DEFAULT_RUN)
    args = parser.parse_args()
    {'prepare': prepare, 'train': train, 'evaluate': evaluate}[args.stage](args.run)
