"""Fixed feature/learner ablation; every planned prediction is sealed before scoring.

F: supplied 85 fragment counts; P: 6311 fingerprint bits;
D: 123 non-fragment RDKit descriptors. No retrieval/external training data.
"""
import argparse
import gc
import importlib.util
import json
import shutil
import sys
import time
from pathlib import Path

import joblib
import lightgbm as lgb
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score, average_precision_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parents[2]
PRIOR = ROOT/'official_comparison/runs/fixed_20261105'
DEFAULT_RUN = ROOT/'feature_ablation/runs/fixed_20261108'
HELPER = ROOT/'official_comparison/scripts/run_official_split.py'
spec = importlib.util.spec_from_file_location('official_protocol', HELPER)
common = importlib.util.module_from_spec(spec)
spec.loader.exec_module(common)
sha, read, write, now = common.sha, common.read, common.write, common.now
SEEDS = [42, 7, 2024, 13, 99]


def feature_sets(names, fragment_names):
    F = list(range(85))
    P = list(range(85, 6396))
    D = [6396+i for i, n in enumerate(names) if n not in fragment_names]
    result = {'F': F, 'P': P, 'D': D, 'FP': F+P, 'FD': F+D, 'PD': P+D, 'FPD': F+P+D,
              'legacy': list(range(6604)),
              'exact_dedup': [i for i in range(6604) if i < 6396 or names[i-6396] not in fragment_names or names[i-6396] == 'fr_unbrch_alkane']}
    assert [len(result[k]) for k in ['F', 'P', 'D', 'FPD', 'exact_dedup']] == [85, 6311, 123, 6519, 6520]
    assert not (set(F)&set(P) or set(F)&set(D) or set(P)&set(D))
    return result


def split_memberships(members, raw):
    official = members.copy()
    scaffold = members.copy(); scaffold['group'] = 'excluded'
    scaffold['original_group'] = 'excluded'
    lookup = members.set_index('COMPOUND_ID').row
    for group in ['training', 'valid', 'test']:
        source = pd.read_csv(ROOT/f'path_a/splits/scaffold/{group}.csv')
        rows = lookup.loc[source.COMPOUND_ID].to_numpy()
        np.testing.assert_array_equal(raw.TARGET.iloc[rows], source.TARGET)
        scaffold.loc[rows, ['group', 'original_group']] = group
    assert not scaffold.group.eq('excluded').any()
    # Preserve the old test set exactly. Correct its legacy per-row acyclic grouping.
    old_valid_test = set(scaffold.loc[scaffold.group.ne('training'), 'boundary_group'])
    test_groups = set(scaffold.loc[scaffold.group.eq('test'), 'boundary_group'])
    bad_tr = scaffold.group.eq('training') & scaffold.boundary_group.isin(old_valid_test)
    bad_va = scaffold.group.eq('valid') & scaffold.boundary_group.isin(test_groups)
    excluded = scaffold[bad_tr | bad_va].copy()
    excluded['reason'] = np.where(excluded.group.eq('training'), 'Shares boundary group with frozen validation or test', 'Shares boundary group with frozen test')
    scaffold.loc[bad_tr | bad_va, 'group'] = 'excluded'
    assert scaffold.group.eq('test').sum() == 4591
    audit = {}
    chemistry = pd.read_csv(PRIOR/'chemistry.csv')
    for cohort, frame in [('official', official), ('scaffold', scaffold)]:
        info = {'counts': {}, 'overlap': {}}
        for group in ['training', 'valid', 'test', 'excluded']:
            rows = np.flatnonzero(frame.group.eq(group))
            info['counts'][group] = {'n': len(rows), 'positive': int(raw.TARGET.iloc[rows].sum())}
        for a, b in [('training', 'valid'), ('training', 'test'), ('valid', 'test')]:
            ai, bi = np.flatnonzero(frame.group.eq(a)), np.flatnonzero(frame.group.eq(b))
            item = {'same_id': len(set(frame.COMPOUND_ID.iloc[ai]) & set(frame.COMPOUND_ID.iloc[bi])),
                    'same_isomeric_structure': len(set(chemistry.canonical.iloc[ai]) & set(chemistry.canonical.iloc[bi])),
                    'shared_boundary_groups': len(set(frame.boundary_group.iloc[ai]) & set(frame.boundary_group.iloc[bi]))}
            assert item['same_id'] == item['same_isomeric_structure'] == 0
            if cohort == 'scaffold':
                assert item['shared_boundary_groups'] == 0
            info['overlap'][a+'/'+b] = item
        audit[cohort] = info
    return {'official': official, 'scaffold': scaffold}, excluded, audit


def model_plan():
    standard = [{'id': 'lgb_'+f, 'learner': 'lightgbm', 'features': f} for f in ['F', 'P', 'D', 'FP', 'FD', 'PD', 'FPD']]
    rf = [{'id': 'rf_F', 'learner': 'rf', 'features': 'F'}, {'id': 'rf_FPD', 'learner': 'rf', 'features': 'FPD'}]
    official = standard + rf + [
        {'id': 'lgb_exact_dedup', 'learner': 'lightgbm', 'features': 'exact_dedup'},
        {'id': 'lgb_legacy', 'learner': 'lightgbm', 'features': 'legacy', 'reuse': 'no_retrieval_lgbm'},
        {'id': 'rf_legacy', 'learner': 'rf', 'features': 'legacy'}]
    official = [dict(m, **({'reuse': 'rf85'} if m['id'] == 'rf_F' else {})) for m in official]
    return {'official': official, 'scaffold': standard+rf}


def prepare(run):
    if (run/'protocol.json').exists():
        raise ValueError('Frozen run already exists; use train/score stages')
    run.mkdir(parents=True, exist_ok=True)
    prior_manifest = read(PRIOR/'prepared_manifest.json')
    common.verify_hashes(PRIOR, prior_manifest['hashes'])
    prior_protocol = read(PRIOR/'protocol.json')
    common.verify_hashes(ROOT, prior_protocol['input_hashes'])
    raw = pd.read_csv(ROOT/'data/raw/SA_FG_fragments.csv')
    members = pd.read_csv(PRIOR/'membership.csv')
    np.testing.assert_array_equal(raw.COMPOUND_ID, members.COMPOUND_ID)
    np.testing.assert_array_equal(raw.group, members.group)
    fragment_names = [c for c in raw if c.startswith('fr_')]
    descriptor_names = read(ROOT/'optimization/cache/rd_desc_names.json')
    base = np.load(PRIOR/'base_features.npy', mmap_mode='r')
    assert base.shape == (43777, 6604) and not np.isinf(base).any()
    sets = feature_sets(descriptor_names, fragment_names)
    duplicates, differing = [], []
    for i, name in enumerate(fragment_names):
        j = 6396+descriptor_names.index(name)
        if np.array_equal(base[:, i], base[:, j], equal_nan=True):
            duplicates.append({'name': name, 'supplied_column': i, 'recomputed_column': j})
        else:
            mask = base[:, i] != base[:, j]
            differing.append({'name': name, 'rows': int(mask.sum()), 'max_absolute_difference': float(np.max(np.abs(base[:, i]-base[:, j])))})
            raw.loc[mask, ['COMPOUND_ID']].assign(supplied=base[mask, i], recomputed=base[mask, j]).to_csv(run/'descriptor_version_discrepancies.csv', index=False)
    assert len(duplicates) == 84 and [x['name'] for x in differing] == ['fr_unbrch_alkane']
    matrices, excluded, audit = split_memberships(members, raw)
    excluded.to_csv(run/'scaffold_exclusions.csv', index=False)
    prepared = []
    for cohort, frame in matrices.items():
        directory = run/cohort; directory.mkdir(exist_ok=True)
        frame.to_csv(directory/'membership.csv', index=False)
        target = np.full(len(raw), -1, np.int8)
        tr = np.flatnonzero(frame.group.eq('training'))
        target[tr] = raw.TARGET.iloc[tr]
        np.save(directory/'training_targets.npy', target)
        prepared += [str((directory/f).relative_to(run)) for f in ['membership.csv', 'training_targets.npy']]
    write(run/'feature_audit.json', {'exact_duplicate_columns': duplicates, 'same_name_but_different': differing,
          'interpretation': 'D contains 123 NON-fragment RDKit descriptors, including physicochemical and topological descriptors; not all are global physicochemical properties.',
          'blocks': {k: len(v) for k, v in sets.items()}, 'nan_values': int(np.isnan(base).sum()),
          'preprocessing': 'NaNs preserved, native handling in both learners; StandardScaler trained only on RF training rows; no target-dependent feature selection'})
    write(run/'feature_sets.json', sets)
    write(run/'split_audit.json', audit)
    source_files = [ROOT/'data/raw/SA_FG_fragments.csv', PRIOR/'base_features.npy', PRIOR/'membership.csv',
                    PRIOR/'chemistry.csv', PRIOR/'protocol.json', PRIOR/'prediction_seal.json',
                    ROOT/'optimization/cache/rd_desc_names.json', HELPER,
                    *[ROOT/f'path_a/splits/scaffold/{s}.csv' for s in ['training', 'valid', 'test']]]
    contrasts = [
        ['lgb_F', 'rf_F', 'learner_at_F'], ['lgb_FPD', 'rf_FPD', 'learner_at_FPD'],
        ['lgb_FPD', 'lgb_F', 'representation_gain_LGBM'], ['rf_FPD', 'rf_F', 'representation_gain_RF'],
        ['lgb_FPD', 'lgb_P', 'full_vs_fingerprints'], ['lgb_FPD', 'lgb_D', 'full_vs_descriptors'],
        ['lgb_FPD', 'lgb_FP', 'add_D_to_FP'], ['lgb_FPD', 'lgb_FD', 'add_P_to_FD'],
        ['lgb_FPD', 'lgb_PD', 'add_F_to_PD']]
    plans = model_plan()
    protocol = {'created_utc': now(), 'seeds': SEEDS, 'plans': plans, 'split_audit': audit,
                'primary_summary': 'All five seeds mean and sample SD; no best-seed or best-feature selection',
                'secondary_summary': 'Equal probability average of all five models',
                'training': 'Only each cohort training partition, unit weights, no external data, no retrieval, no validation refit',
                'hyperparameters': {str(s): prior_protocol['parameters'][str(s)] for s in SEEDS},
                'num_boost_round': 900, 'threshold': .5,
                'rf': {'n_estimators': 100, 'max_depth': None, 'min_samples_split': 2, 'min_samples_leaf': 1,
                       'max_features': 'sqrt', 'bootstrap': True, 'n_jobs': 8},
                'rf_preprocessing': 'StandardScaler fitted on training only; native NaNs',
                'hyperparameter_policy': 'Fixed inherited recipes; estimates are conditional on these recipes, not best-tuned algorithm comparisons',
                'scaffold_policy': 'Frozen 4591 test IDs, remove 10 training and 2 validation rows sharing acyclic connectivity boundary groups; do not alter old split files',
                'bootstrap': {'draws': 1000, 'seed': 20261108, 'unit': 'nonempty Murcko / acyclic connectivity',
                              'summary': 'paired ensemble differences', 'intervals': 'pointwise 95%, exploratory; no multiplicity correction'},
                'contrasts': contrasts,
                'official_extra_contrasts': [['lgb_legacy', 'rf_legacy', 'learner_at_legacy'],
                    ['lgb_legacy', 'lgb_exact_dedup', 'effect_of_84_duplicate_columns'],
                    ['lgb_exact_dedup', 'lgb_FPD', 'effect_of_recomputed_fr_unbrch_alkane']],
                'evaluation_policy': 'Save ALL planned models and validation/test predictions in BOTH cohorts before scoring new predictions',
                'source_script_sha256': sha(__file__), 'input_hashes': {str(p.relative_to(ROOT)): sha(p) for p in source_files}}
    assert audit['scaffold']['counts']['training']['n'] == 35074
    assert audit['scaffold']['counts']['valid']['n'] == 4100
    write(run/'protocol.json', protocol)
    shutil.copy2(__file__, run/'run_ablation_frozen.py')
    shutil.copy2(HELPER, run/'official_protocol_helper_frozen.py')
    write(run/'environment.json', {'python': common.platform.python_version(),
          'packages': {n: common.importlib.metadata.version(n) for n in ['numpy', 'pandas', 'scipy', 'scikit-learn', 'lightgbm', 'rdkit', 'joblib']}})
    prepared += ['protocol.json', 'feature_audit.json', 'feature_sets.json', 'split_audit.json', 'scaffold_exclusions.csv',
                 'descriptor_version_discrepancies.csv', 'run_ablation_frozen.py', 'official_protocol_helper_frozen.py', 'environment.json']
    write(run/'prepared_manifest.json', {'utc': now(), 'hashes': {f: sha(run/f) for f in prepared}})
    write(run/'status.json', {'state': 'prepared', 'planned_model_records': 105, 'new_fits': 95, 'reused_verified_models': 10, 'utc': now()})
    print(json.dumps({'models': {k: len(v)*len(SEEDS) for k, v in plans.items()}, 'splits': audit, 'duplicates': len(duplicates), 'differing': differing}, indent=2), flush=True)


def train(run, cohort):
    if (run/cohort/'prediction_seal.json').exists():
        raise ValueError('Cohort already sealed; do not overwrite')
    common.verify_hashes(run, read(run/'prepared_manifest.json')['hashes'])
    config = read(run/'protocol.json')
    common.verify_hashes(ROOT, config['input_hashes'])
    assert sha(__file__) == config['source_script_sha256']
    frame = pd.read_csv(run/cohort/'membership.csv')
    tr, va, te = [np.flatnonzero(frame.group.eq(s)) for s in ['training', 'valid', 'test']]
    y = np.load(run/cohort/'training_targets.npy')
    assert np.isin(y[tr], [0, 1]).all() and np.all(y[~frame.group.eq('training').to_numpy()] == -1)
    base = np.load(PRIOR/'base_features.npy', mmap_mode='r')
    sets = read(run/'feature_sets.json')
    old_seal = read(PRIOR/'prediction_seal.json')
    records = []
    for planned in config['plans'][cohort]:
        name = planned['id']; columns = np.array(sets[planned['features']])
        directory = run/cohort/name; directory.mkdir(exist_ok=True)
        if 'reuse' not in planned:
            Xtr, Xva, Xte = [base[np.ix_(idx, columns)] for idx in [tr, va, te]]
        for seed in SEEDS:
            path = directory/f'seed_{seed}_record.json'
            if path.exists():
                record = read(path)
                assert record['model'] == name and record['seed'] == seed
                common.verify_hashes(run, record['hashes'])
                records.append(record)
                continue
            write(run/cohort/'status.json', {'state': 'training', 'model': name, 'seed': seed,
                  'completed': len(records), 'total': len(config['plans'][cohort])*5, 'utc': now()})
            started = time.time()
            suffix = '.joblib' if planned['learner'] == 'rf' else '.lgb'
            model_file = directory/f'seed_{seed}{suffix}'
            pred_file = directory/f'seed_{seed}_predictions.npz'
            reused_from = None
            if 'reuse' in planned:
                old = next(r for r in old_seal['models'] if r['variant'] == planned['reuse'] and r['seed'] == seed)
                assert sha(PRIOR/old['model_file']) == old['model_sha256']
                assert sha(PRIOR/old['prediction_file']) == old['prediction_sha256']
                saved = np.load(PRIOR/old['prediction_file'])
                np.testing.assert_array_equal(saved['valid_rows'], va)
                np.testing.assert_array_equal(saved['test_rows'], te)
                shutil.copy2(PRIOR/old['model_file'], model_file)
                shutil.copy2(PRIOR/old['prediction_file'], pred_file)
                error = old['reload_max_absolute_error']
                reused_from = {'record': old, 'source_run': str(PRIOR.relative_to(ROOT))}
            else:
                if planned['learner'] == 'lightgbm':
                    model = lgb.train(config['hyperparameters'][str(seed)], lgb.Dataset(Xtr, label=y[tr]), num_boost_round=config['num_boost_round'])
                    model.save_model(str(model_file))
                    pv, pt = model.predict(Xva), model.predict(Xte)
                    reloaded = lgb.Booster(model_file=str(model_file))
                    check = reloaded.predict(Xte[::37])
                else:
                    model = make_pipeline(StandardScaler(), RandomForestClassifier(random_state=seed, **config['rf']))
                    model.fit(Xtr, y[tr])
                    # Deterministic inference order; learning still uses eight workers.
                    model.set_params(randomforestclassifier__n_jobs=1)
                    joblib.dump(model, model_file, compress=3)
                    pv, pt = model.predict_proba(Xva)[:, 1], model.predict_proba(Xte)[:, 1]
                    reloaded = joblib.load(model_file)
                    check = reloaded.predict_proba(Xte[::37])[:, 1]
                error = float(np.max(np.abs(check-pt[::37])))
                np.testing.assert_allclose(check, pt[::37], rtol=0, atol=1e-12)
                assert np.isfinite(pv).all() and np.isfinite(pt).all()
                assert np.all((pt >= 0) & (pt <= 1))
                np.savez_compressed(pred_file, valid=pv, test=pt, valid_rows=va, test_rows=te)
                del model, reloaded
                gc.collect()
            files = [model_file, pred_file]
            record = {'cohort': cohort, 'model': name, 'seed': seed, 'n_features': len(columns), 'n_training': len(tr),
                      'seconds': round(time.time()-started, 2), 'reload_max_absolute_error': error,
                      'model_file': str(model_file.relative_to(run)), 'prediction_file': str(pred_file.relative_to(run)),
                      'hashes': {str(p.relative_to(run)): sha(p) for p in files}, 'reused_from': reused_from}
            write(path, record); records.append(record)
            print(json.dumps({'cohort': cohort, 'completed': len(records), 'model': name, 'seed': seed, 'seconds': record['seconds'], 'reused': bool(reused_from)}), flush=True)
        if 'reuse' not in planned:
            del Xtr, Xva, Xte
            gc.collect()
    common.verify_hashes(ROOT, config['input_hashes'])
    write(run/cohort/'prediction_seal.json', {'utc': now(), 'protocol_sha256': sha(run/'protocol.json'),
          'models': records, 'new_test_metrics_computed_during_training': False})
    write(run/cohort/'status.json', {'state': 'predictions_sealed', 'completed': len(records), 'utc': now()})


def basic_metrics(y, p, weights=None):
    if weights is None:
        weights = np.ones(len(y))
    binary = p >= .5
    tp = float(weights[(y == 1)&binary].sum()); tn = float(weights[(y == 0)&~binary].sum())
    fp = float(weights[(y == 0)&binary].sum()); fn = float(weights[(y == 1)&~binary].sum())
    denominator = np.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
    return {'auc': float(roc_auc_score(y, p, sample_weight=weights)),
            'ap': float(average_precision_score(y, p, sample_weight=weights)),
            'mcc': (tp*tn-fp*fn)/denominator if denominator else 0.}


def validate_seals(run):
    config = read(run/'protocol.json')
    common.verify_hashes(run, read(run/'prepared_manifest.json')['hashes'])
    common.verify_hashes(ROOT, config['input_hashes'])
    for cohort, plans in config['plans'].items():
        seal = read(run/cohort/'prediction_seal.json')
        assert seal['protocol_sha256'] == sha(run/'protocol.json')
        assert {(r['model'], r['seed']) for r in seal['models']} == {(m['id'], s) for m in plans for s in SEEDS}
        for record in seal['models']:
            common.verify_hashes(run, record['hashes'])
    return config


def score(run):
    if (run/'results.json').exists():
        raise ValueError('This run has already been scored')
    config = validate_seals(run)
    raw = pd.read_csv(ROOT/'data/raw/SA_FG_fragments.csv')
    final, table, bootstraps = {}, [], {}
    for cohort, planned in config['plans'].items():
        members = pd.read_csv(run/cohort/'membership.csv')
        np.testing.assert_array_equal(members.COMPOUND_ID, raw.COMPOUND_ID)
        indices = {s: np.flatnonzero(members.group.eq(s)) for s in ['valid', 'test']}
        outputs, ensembles = {}, {}
        for model in planned:
            name = model['id']; records = []; probs = {s: [] for s in indices}
            for seed in SEEDS:
                saved = np.load(run/cohort/name/f'seed_{seed}_predictions.npz')
                record = {'seed': seed}
                for split, rows in indices.items():
                    np.testing.assert_array_equal(saved[split+'_rows'], rows)
                    p = saved[split]; probs[split].append(p)
                    record[split] = basic_metrics(raw.TARGET.iloc[rows].to_numpy(), p)
                records.append(record)
            item = {'runs': records, 'mean': {}, 'sd': {}, 'ensemble': {}, 'n_features': len(read(run/'feature_sets.json')[model['features']])}
            for split, rows in indices.items():
                item['mean'][split] = {m: float(np.mean([r[split][m] for r in records])) for m in ['auc', 'ap', 'mcc']}
                item['sd'][split] = {m: float(np.std([r[split][m] for r in records], ddof=1)) for m in ['auc', 'ap', 'mcc']}
                p = np.mean(probs[split], axis=0)
                item['ensemble'][split] = basic_metrics(raw.TARGET.iloc[rows].to_numpy(), p)
                df = pd.DataFrame({'COMPOUND_ID': raw.COMPOUND_ID.iloc[rows], 'TARGET': raw.TARGET.iloc[rows], 'probability': p})
                for seed, pp in zip(SEEDS, probs[split]):
                    df[f'seed_{seed}'] = pp
                df.to_csv(run/cohort/name/f'{split}_predictions.csv', index=False)
                if split == 'test':
                    ensembles[name] = p
            outputs[name] = item
            table.append({'cohort': cohort, 'model': name, 'n_features': item['n_features'],
                          **{m: item['mean']['test'][m] for m in ['auc', 'ap', 'mcc']},
                          **{m+'_sd': item['sd']['test'][m] for m in ['auc', 'ap', 'mcc']},
                          **{'ensemble_'+m: item['ensemble']['test'][m] for m in ['auc', 'ap', 'mcc']}})
        rows = indices['test']; y = raw.TARGET.iloc[rows].to_numpy()
        groups, inv = np.unique(members.boundary_group.iloc[rows].to_numpy(), return_inverse=True)
        scores = {name: {m: [] for m in ['auc', 'ap', 'mcc']} for name in ensembles}
        rng = np.random.default_rng(config['bootstrap']['seed'])
        for step in range(config['bootstrap']['draws']):
            counts = np.bincount(rng.integers(0, len(groups), len(groups)), minlength=len(groups))
            weights = counts[inv]
            if not weights[y == 0].sum() or not weights[y == 1].sum():
                continue
            for name, p in ensembles.items():
                measured = basic_metrics(y, p, weights)
                for m in measured:
                    scores[name][m].append(measured[m])
            if (step+1) % 100 == 0:
                write(run/'status.json', {'state': 'bootstrap', 'cohort': cohort, 'draws_completed': step+1, 'draws_total': config['bootstrap']['draws'], 'utc': now()})
                print(f'{cohort} bootstrap {step+1}/{config["bootstrap"]["draws"]}', flush=True)
        contrasts = config['contrasts']+(config['official_extra_contrasts'] if cohort == 'official' else [])
        differences = {}
        for left, right, name in contrasts:
            differences[name] = {'left': left, 'right': right, 'metrics': {}}
            for m in ['auc', 'ap', 'mcc']:
                delta = np.array(scores[left][m])-np.array(scores[right][m])
                differences[name]['metrics'][m] = {'delta': outputs[left]['ensemble']['test'][m]-outputs[right]['ensemble']['test'][m],
                                                   'ci95': np.quantile(delta, [.025, .975]).tolist()}
        interaction = {}
        for m in ['auc', 'ap', 'mcc']:
            vals = (np.array(scores['lgb_FPD'][m])-np.array(scores['lgb_F'][m]))-(np.array(scores['rf_FPD'][m])-np.array(scores['rf_F'][m]))
            delta = (outputs['lgb_FPD']['ensemble']['test'][m]-outputs['lgb_F']['ensemble']['test'][m])-(outputs['rf_FPD']['ensemble']['test'][m]-outputs['rf_F']['ensemble']['test'][m])
            interaction[m] = {'delta': delta, 'ci95': np.quantile(vals, [.025, .975]).tolist()}
        final[cohort] = {'models': outputs, 'paired_ensemble_contrasts': differences, 'learner_representation_interaction': interaction,
                         'bootstrap_group_count': len(groups), 'ensemble_ci95': {n: {m: np.quantile(a, [.025, .975]).tolist() for m, a in ss.items()} for n, ss in scores.items()}}
        bootstraps[cohort] = scores
    write(run/'results.json', {'completed_utc': now(), 'protocol_sha256': sha(run/'protocol.json'), 'cohorts': final})
    pd.DataFrame(table).to_csv(run/'comparison.csv', index=False)
    write(run/'bootstrap_samples.json', bootstraps)
    write(run/'status.json', {'state': 'scored', 'models': 105, 'utc': now()})
    print(pd.DataFrame(table).to_string(index=False), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=['prepare', 'train', 'score'])
    parser.add_argument('--cohort', choices=['official', 'scaffold'])
    parser.add_argument('--run', type=Path, default=DEFAULT_RUN)
    args = parser.parse_args()
    if args.stage == 'train':
        if args.cohort is None:
            parser.error('--cohort is required for training')
        train(args.run, args.cohort)
    else:
        {'prepare': prepare, 'score': score}[args.stage](args.run)
