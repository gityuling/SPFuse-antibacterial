"""Finish the already-running frozen grid after both prediction seals exist."""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RUN = ROOT/'feature_ablation/runs/fixed_20261108'


def main():
    while not all((RUN/c/'prediction_seal.json').exists() for c in ['official', 'scaffold']):
        time.sleep(15)
    stages = [
        ('scoring.log', 'run_ablation.py', ['score'], 'results.json'),
        ('metric_verification.log', 'verify_ablation.py', ['metrics'], 'independent_metric_verification.json'),
    ]
    for log, script, args, result in stages:
        if (RUN/result).exists():
            continue
        print('Starting', script, *args, flush=True)
        with (RUN/log).open('w') as output:
            subprocess.run([sys.executable, '-u', str(ROOT/'feature_ablation/scripts'/script), *args],
                           cwd=ROOT, stdout=output, stderr=subprocess.STDOUT, check=True)
    print('Creating verified report', flush=True)
    subprocess.run([sys.executable, str(ROOT/'feature_ablation/scripts/report_ablation.py')], cwd=ROOT, check=True)
    manifest = json.loads((RUN/'artifact_manifest.json').read_text())
    for name, expected in manifest['files'].items():
        h = hashlib.sha256()
        with (RUN/name).open('rb') as f:
            for block in iter(lambda: f.read(2**20), b''):
                h.update(block)
        assert h.hexdigest() == expected, name
    print('All', len(manifest['files']), 'artifact hashes independently verified', flush=True)


if __name__ == '__main__':
    main()
