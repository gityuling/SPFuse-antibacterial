"""Report the prespecified feature/learner grid; never select a winning variant."""
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
PROJECT = ROOT/'feature_ablation'
RUN = PROJECT/'runs/fixed_20261108'
FEATURES = ['F', 'P', 'D', 'FP', 'FD', 'PD', 'FPD']
METRICS = {'auc': 'AUROC', 'ap': 'AP', 'mcc': 'MCC'}
COHORTS = {'official': '作者官方划分', 'scaffold': '骨架隔离划分'}
CONTRASTS = {
    'learner_at_F': '片段相同：LightGBM − RF',
    'learner_at_FPD': '完整特征相同：LightGBM − RF',
    'representation_gain_LGBM': 'LightGBM：FPD − F',
    'representation_gain_RF': 'RF：FPD − F',
    'full_vs_fingerprints': 'LightGBM：FPD − P',
    'full_vs_descriptors': 'LightGBM：FPD − D',
    'add_D_to_FP': '加入描述符 D：FPD − FP',
    'add_P_to_FD': '加入指纹 P：FPD − FD',
    'add_F_to_PD': '加入片段 F：FPD − PD',
    'learner_at_legacy': '旧版 6604 维相同：LightGBM − RF',
    'effect_of_84_duplicate_columns': '84 个重复列：旧版 − 精确去重',
    'effect_of_recomputed_fr_unbrch_alkane': '额外同名计数：精确去重 − FPD',
}


def read(path):
    return json.loads(path.read_text())


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(2**20), b''):
            h.update(block)
    return h.hexdigest()


def mean_row(label, values):
    return '| '+label+' | '+str(values['n_features'])+' | '+' | '.join(
        f"{values['mean']['test'][m]:.5f} ± {values['sd']['test'][m]:.5f}" for m in METRICS)+' |'


def interval_cell(values):
    lo, hi = values['ci95']
    return f"{values['delta']:+.5f} [{lo:+.5f}, {hi:+.5f}]"


def interpretation(values):
    lo, hi = values['ci95']
    if lo > 0:
        return '差值区间高于 0'
    if hi < 0:
        return '差值区间低于 0'
    return '差值区间包含 0，未证明额外收益'


def write_figures(data):
    plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})
    fig, axes = plt.subplots(2, 3, figsize=(13, 7.4), layout='constrained')
    for row, cohort in enumerate(COHORTS):
        models = data[cohort]['models']
        for col, metric in enumerate(METRICS):
            ax = axes[row, col]
            means = [models['lgb_'+f]['mean']['test'][metric] for f in FEATURES]
            sd = [models['lgb_'+f]['sd']['test'][metric] for f in FEATURES]
            ax.errorbar(np.arange(7), means, yerr=sd, fmt='o', capsize=4, color='#2166ac', markersize=6,
                        label='LightGBM: mean ± SD (5 seeds)')
            for name, color, linestyle in [('rf_F', '#b35806', '--'), ('rf_FPD', '#238b45', ':')]:
                ax.axhline(models[name]['mean']['test'][metric], color=color, linestyle=linestyle,
                           label='RF: '+name.removeprefix('rf_')+' (5-seed mean)')
            ax.set_xticks(np.arange(7), FEATURES)
            ax.set_ylabel(METRICS[metric]); ax.grid(axis='y', alpha=.2)
            ax.set_title(('Official released split' if cohort == 'official' else 'Scaffold-disjoint split')+' | '+METRICS[metric])
            if col == 0:
                ax.legend(fontsize=8, loc='best')
    fig.suptitle('Fixed feature ablation | F: fragments, P: fingerprints, D: non-fragment RDKit descriptors\nTraining partition only; threshold 0.5; axes are independently scaled', fontsize=12)
    fig.savefig(RUN/'feature_ablation.png', dpi=190)
    fig.savefig(RUN/'feature_ablation.pdf')
    plt.close(fig)


def main():
    config = read(RUN/'protocol.json')
    result = read(RUN/'results.json')
    assert result['protocol_sha256'] == sha(RUN/'protocol.json')
    assert read(RUN/'independent_data_verification.json')['passed']
    verification = read(RUN/'independent_metric_verification.json')
    assert verification['passed'] and verification['model_split_summaries_checked'] == 42
    data = result['cohorts']
    write_figures(data)
    lines = [
        '# 特征与学习器消融：固定协议实验（2026-11-08）', '',
        '本轮补充实验回答：已有性能提升有多少来自学习器，有多少来自分子表示；三类特征是否分别提供额外信息；这些结论在骨架隔离测试中是否仍成立。全部计划、参数、种子和对比项在本轮新模型评分前冻结。', '',
        '**主结果为全部 5 个种子的均值 ± 样本标准差。** AP 使用 `average_precision_score`，MCC 固定阈值 0.5。配对区间针对另行报告的五模型等权概率平均集成，不能与单模型种子均值混为一谈。', '',
        '## 实验所得的直接证据', '',
    ]
    # Describe all three prespecified incremental contributions, never just a winner.
    findings = {}
    for cohort, label in COHORTS.items():
        models = data[cohort]['models']
        full, rf = models['lgb_FPD'], models['rf_F']
        changes = {m: full['mean']['test'][m]-rf['mean']['test'][m] for m in METRICS}
        lines += [f"**{label}**：完整 FPD LightGBM 相对片段 RF 的五种子均值变化为 "+'，'.join(f'{METRICS[m]} {changes[m]:+.5f}' for m in METRICS)+'。', '']
        findings[cohort] = {'full_lgbm_minus_fragment_rf_seed_mean': changes, 'incremental_blocks': {}}
        for key, title in [('add_D_to_FP', '描述符 D 的增量'), ('add_P_to_FD', '指纹 P 的增量'), ('add_F_to_PD', '片段 F 的增量')]:
            c = data[cohort]['paired_ensemble_contrasts'][key]['metrics']
            lines += [f"- {title}："+'；'.join(f'{METRICS[m]} {interval_cell(c[m])}（{interpretation(c[m])}）' for m in METRICS)+'。']
            findings[cohort]['incremental_blocks'][key] = c
        lines += ['']
    lines += [
        '上述区间为预先列出的多项探索性对照的逐项 95% 区间，未校正多重比较。若某个特征块在某项指标上没有额外收益，应按实报告，不能据整体模型强于 RF 就推断三个特征块均有效。', '',
        '## 特征定义与重复列审计', '',
        '| 特征块 | 维度 | 内容 |', '|---|---:|---|',
        '| F | 85 | 作者提供的片段计数 |',
        '| P | 6311 | Morgan radius 2/3 各 2048 位，MACCS 167 位，atom-pair / topological-torsion 各 1024 位 |',
        '| D | 123 | 排除所有 `fr_` 片段计数后的 RDKit 描述符，包含物化和拓扑描述符 |',
        '| FPD | 6519 | 本轮用于三块消融的完整表示 |',
        '| 精确去重 | 6520 | 旧版移除 84 个完全重复列；额外保留重算的 `fr_unbrch_alkane` |',
        '| 旧版 | 6604 | 既有模型的原始完整输入，用于衔接旧结果 |', '',
        '旧版的 208 个 RDKit 描述符包含与作者 85 个片段计数同名的列。其中 84 列在全部 43,777 个分子上数值完全一致；`fr_unbrch_alkane` 在 4,773 个分子上不同，绝对差最大为 11。后者不是精确重复列，差异的具体来源（版本、实现或预处理）尚未确定。审计文件保留逐分子的两个值。', '',
        '重复输入可能改变树模型的特征抽样机会，因此分别测试“去掉 84 个重复列”和“去掉额外重算计数”。没有根据测试标签挑选特征。D 中还包含拓扑描述符，不能把 D 的任何收益全部解释为全局物化性质的作用。', '',
        '## 完整结果：固定特征组合', '',
    ]
    for cohort, label in COHORTS.items():
        models = data[cohort]['models']
        lines += [f'### {label}', '', '| LightGBM 特征 | 维度 | AUROC | AP | MCC |', '|---|---:|---:|---:|---:|']
        lines += [mean_row(f, models['lgb_'+f]) for f in FEATURES]
        lines += ['', '相同特征比较学习器，相同学习器比较表示：', '', '| 学习器与特征 | 维度 | AUROC | AP | MCC |', '|---|---:|---:|---:|---:|']
        lines += [mean_row(n, models[n]) for n in ['rf_F', 'lgb_F', 'rf_FPD', 'lgb_FPD']]
        if cohort == 'official':
            lines += ['', '与旧版输入的衔接对照：', '', '| 模型 | 维度 | AUROC | AP | MCC |', '|---|---:|---:|---:|---:|']
            lines += [mean_row(n, models[n]) for n in ['lgb_FPD', 'lgb_exact_dedup', 'lgb_legacy', 'rf_legacy']]
        lines += ['']
    lines += ['![Feature ablation](runs/fixed_20261108/feature_ablation.png)', '',
              '## 集成与配对差值', '',
              '每个方案均使用预定的五种子等权概率平均，不选择最好种子。对同一测试队列按非空、非手性 Murcko 骨架分组 bootstrap；无环分子按非立体连接结构分组。每次各模型使用完全相同的组抽样权重，重采样 1,000 次。区间度量测试队列抽样不确定性，不能替代重新划分数据后的重复实验。', '']
    for cohort, label in COHORTS.items():
        lines += [f'### {label}：集成分数', '', '| 模型 | AUROC | AP | MCC |', '|---|---:|---:|---:|']
        for name, values in data[cohort]['models'].items():
            lines.append('| '+name+' | '+' | '.join(f"{values['ensemble']['test'][m]:.5f}" for m in METRICS)+' |')
        lines += ['', f"共 {data[cohort]['bootstrap_group_count']:,} 个测试骨架/无环连接组。下表为前者减后者，差值 [95% 区间]。", '',
                  '| 预先规定的对比 | AUROC | AP | MCC |', '|---|---:|---:|---:|']
        for name, contrast in data[cohort]['paired_ensemble_contrasts'].items():
            lines.append('| '+CONTRASTS[name]+' | '+' | '.join(interval_cell(contrast['metrics'][m]) for m in METRICS)+' |')
        lines += ['| 学习器 × 表示交互 | '+' | '.join(interval_cell(data[cohort]['learner_representation_interaction'][m]) for m in METRICS)+' |', '',
                  '交互定义为 `(LightGBM_FPD − LightGBM_F) − (RF_FPD − RF_F)`；正值表示这一固定配方下，扩展表示对 LightGBM 的帮助更大。', '']
    audit = read(RUN/'split_audit.json')
    lines += ['## 划分、参数与适用范围', '', '| 队列 | 训练 | 验证 | 测试 | 测试阳性 |', '|---|---:|---:|---:|---:|']
    for c, label in COHORTS.items():
        counts = audit[c]['counts']
        lines.append(f"| {label} | {counts['training']['n']:,} | {counts['valid']['n']:,} | {counts['test']['n']:,} | {counts['test']['positive']:,} |")
    lines += ['',
        '- 官方划分逐行保留发布文件的标签，不消除作者随机划分中自然存在的骨架相似性。',
        '- 骨架划分沿用已有测试集 4,591 个分子，测试 ID 和顺序完全保留；本轮训练副本去掉 10 个与验证/测试共享无环连接结构的分子，验证副本再去掉 2 个与测试共享连接结构的分子，三组间边界重叠均为 0。源划分文件未修改。',
        '- 两个队列均仅使用各自 training：不合并 valid、不加入外部数据、不使用检索、不使用预训练权重。验证集只做冻结方案的描述性评估。',
        '- LightGBM：固定 900 轮、学习率 0.03、511 叶、min_data_in_leaf=10、feature_fraction=0.25、bagging_fraction=0.8、bagging_freq=1、L2=5、max_bin=63。',
        '- RF：100 棵树，max_features=sqrt，深度不限制，叶节点最少 1、分裂最少 2，bootstrap=True。StandardScaler 仅在 training 拟合；两类学习器均保留 NaN 并使用原生处理。',
        '- 五个种子固定为 42、7、2024、13、99。使用既有参数配方，不做参数搜索或逐组合早停。',
        '- 官方 12 个方案 × 5，骨架 9 个方案 × 5，共 105 组模型记录；95 次新训练，10 个严格同协议的既有官方 RF-F / LightGBM-旧版模型经过训练行、模型和预测哈希核验后复用。',
        '- 训练阶段全部非训练行的目标数组设为 -1。两个队列的全部计划模型及预测封存后，统一评分。',
        '- 不同特征维度会改变 sqrt 和 feature_fraction 对应的候选特征数量；这里衡量固定配方下的特征与学习器效果，不宣称完成每个算法/组合的最优调参比较。',
        '- 骨架集合不重叠只表示这一骨架定义下的隔离，不能据此宣称测试分子与训练分子完全不相似。官方与骨架测试成员不同，不能把两队列分数差严格归因于单一变量。',
        '- 既有 path_a 报告还涉及 train+valid 或外部训练数据，其绝对分数不与本轮训练条件混用。',
        '- 本轮为已有模型开发后的固定协议消融。它能支撑特征贡献分析；不能单凭这些分数证明药理机制、临床有效性或一个从未研究过的新问题。', '',
        '## 文件与复核', '',
        f"独立程序重新计算全部 43,777 个分子的边界分组；核对训练/验证/测试成员、屏蔽标签及三块特征的 256 行样本对齐。独立指标程序从逐分子预测重新计算 {verification['model_split_summaries_checked']} 个模型×划分的五种子、均值、标准差及集成 AUROC/AP/MCC，全部通过。保存模型重新加载预测检查均通过 1e-12 的绝对误差容差。", '',
        '- [冻结协议](runs/fixed_20261108/protocol.json) · [数据划分审计](runs/fixed_20261108/split_audit.json) · [特征审计](runs/fixed_20261108/feature_audit.json)',
        '- [完整结果 JSON](runs/fixed_20261108/results.json) · [主比较表 CSV](runs/fixed_20261108/comparison.csv)',
        '- [独立数据核对](runs/fixed_20261108/independent_data_verification.json) · [独立指标复核](runs/fixed_20261108/independent_metric_verification.json)',
        '- [官方模型及预测封存](runs/fixed_20261108/official/prediction_seal.json) · [骨架模型及预测封存](runs/fixed_20261108/scaffold/prediction_seal.json)',
        '- 模型、NPZ 预测及 valid/test 逐分子 CSV 均在各队列/模型子目录中；旧实验原始结果保留。',
        '- 精确重算优先使用 NPZ；CSV 请使用 `pd.read_csv(..., float_precision="round_trip")`，保留 0.5 边界和相同分数的排序语义。',
        '- [科学图 PDF](runs/fixed_20261108/feature_ablation.pdf) · [全部产物哈希](runs/fixed_20261108/artifact_manifest.json)', '',
        '复现训练时使用新目录，冻结目录拒绝被重复 prepare/score 覆盖。在项目根目录运行：', '',
        '```bash',
        '../MAPViS-reproduction/.venv/bin/python feature_ablation/scripts/run_ablation.py prepare --run feature_ablation/runs/reproduction',
        '../MAPViS-reproduction/.venv/bin/python feature_ablation/scripts/run_ablation.py train --cohort official --run feature_ablation/runs/reproduction',
        '../MAPViS-reproduction/.venv/bin/python feature_ablation/scripts/run_ablation.py train --cohort scaffold --run feature_ablation/runs/reproduction',
        '../MAPViS-reproduction/.venv/bin/python feature_ablation/scripts/run_ablation.py score --run feature_ablation/runs/reproduction',
        '../MAPViS-reproduction/.venv/bin/python feature_ablation/tests/test_ablation.py',
        '```', '',
    ]
    (PROJECT/'README.md').write_text('\n'.join(lines))
    (RUN/'findings.json').write_text(json.dumps(findings, indent=2)+'\n')
    for path in [*list((PROJECT/'scripts').glob('*.py')), *list((PROJECT/'tests').glob('*.py'))]:
        dst = RUN/'source'/path.parent.name/path.name
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, dst)
    (RUN/'status.json').write_text(json.dumps({'state': 'complete', 'verified': True, 'models': 105,
        'new_fits': 95, 'reused_verified_models': 10, 'utc': datetime.now(timezone.utc).isoformat()}, indent=2)+'\n')
    files = sorted(p for p in RUN.rglob('*') if p.is_file() and p.name != 'artifact_manifest.json' and '__pycache__' not in p.parts)
    manifest = {'files': {str(p.relative_to(RUN)): sha(p) for p in files}, 'readme_sha256': sha(PROJECT/'README.md')}
    (RUN/'artifact_manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print(PROJECT/'README.md')


if __name__ == '__main__':
    main()
