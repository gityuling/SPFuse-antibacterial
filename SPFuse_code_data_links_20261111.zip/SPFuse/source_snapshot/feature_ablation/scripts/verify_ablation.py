"""Independent data boundary checks and post-score metric verification."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from rdkit import Chem
from rdkit.Chem.Scaffolds import MurckoScaffold
from sklearn.metrics import roc_auc_score, average_precision_score, matthews_corrcoef

ROOT = Path(__file__).resolve().parents[2]
RUN = ROOT/'feature_ablation/runs/fixed_20261108'


def data_checks():
    raw = pd.read_csv(ROOT/'data/raw/SA_FG_fragments.csv')
    boundaries = []
    for s in raw.PROCESSED_SMILES:
        mol = Chem.MolFromSmiles(s)
        scaffold = MurckoScaffold.MurckoScaffoldSmiles(mol=mol, includeChirality=False)
        boundaries.append('MURCKO:'+scaffold if scaffold else 'ACYCLIC_STRUCTURE:'+Chem.MolToSmiles(mol, isomericSmiles=False))
    boundaries = np.array(boundaries)
    audit = {}
    for cohort in ['official', 'scaffold']:
        members = pd.read_csv(RUN/cohort/'membership.csv')
        np.testing.assert_array_equal(members.COMPOUND_ID, raw.COMPOUND_ID)
        np.testing.assert_array_equal(members.PROCESSED_SMILES, raw.PROCESSED_SMILES)
        np.testing.assert_array_equal(members.boundary_group, boundaries)
        targets = np.load(RUN/cohort/'training_targets.npy')
        tr = members.group.eq('training').to_numpy()
        np.testing.assert_array_equal(targets[tr], raw.TARGET[tr])
        assert np.all(targets[~tr] == -1)
        test = members[members.group.eq('test')]
        if cohort == 'official':
            np.testing.assert_array_equal(members.group, raw.group)
            np.testing.assert_array_equal(test.COMPOUND_ID, raw.loc[raw.group.eq('test'), 'COMPOUND_ID'])
        else:
            old_test = pd.read_csv(ROOT/'path_a/splits/scaffold/test.csv')
            np.testing.assert_array_equal(test.COMPOUND_ID, old_test.COMPOUND_ID)
            sets = {s: set(boundaries[members.group.eq(s)]) for s in ['training', 'valid', 'test']}
            assert not (sets['training']&sets['valid'] or sets['training']&sets['test'] or sets['valid']&sets['test'])
        audit[cohort] = {'test_membership_preserved': True, 'heldout_targets_in_fit_array': 0,
                         'n_train': int(tr.sum()), 'n_valid': int(members.group.eq('valid').sum()), 'n_test': len(test)}
    sets = json.loads((RUN/'feature_sets.json').read_text())
    fp = np.load(ROOT/'optimization/cache/rd_fp.npy', mmap_mode='r')
    extra = np.load(ROOT/'optimization/cache/rd_extra_fp.npy', mmap_mode='r')
    desc = np.load(ROOT/'optimization/cache/rd_desc.npy', mmap_mode='r')
    names = json.loads((ROOT/'optimization/cache/rd_desc_names.json').read_text())
    base = np.load(ROOT/'official_comparison/runs/fixed_20261105/base_features.npy', mmap_mode='r')
    frag = [c for c in raw if c.startswith('fr_')]
    sample = np.random.default_rng(20261108).choice(len(raw), 256, replace=False)
    expected = {'F': raw[frag].to_numpy(np.float32)[sample], 'P': np.hstack([fp[sample], extra[sample]]),
                'D': desc[np.ix_(sample, [i for i, n in enumerate(names) if not n.startswith('fr_')])].astype(np.float32)}
    for block, values in expected.items():
        np.testing.assert_array_equal(base[np.ix_(sample, sets[block])], values)
    for a, b in [('F', 'P'), ('F', 'D'), ('P', 'D')]:
        assert not set(sets[a]) & set(sets[b])
    report = {'passed': True, 'fresh_rdkit_structures': len(raw), 'cohorts': audit,
              'feature_alignment_sample_rows': sample.tolist(), 'F_P_D_column_blocks_disjoint': True,
              'test_metrics_computed': False}
    (RUN/'independent_data_verification.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'feature_alignment_sample_rows'}, indent=2))


def metric_checks():
    results = json.loads((RUN/'results.json').read_text())
    raw = pd.read_csv(ROOT/'data/raw/SA_FG_fragments.csv')
    records = []
    for cohort, data in results['cohorts'].items():
        members = pd.read_csv(RUN/cohort/'membership.csv')
        indices = {s: np.flatnonzero(members.group.eq(s)) for s in ['valid', 'test']}
        for model, values in data['models'].items():
            for split, idx in indices.items():
                frame = pd.read_csv(RUN/cohort/model/f'{split}_predictions.csv', float_precision='round_trip')
                np.testing.assert_array_equal(frame.COMPOUND_ID, raw.COMPOUND_ID.iloc[idx])
                np.testing.assert_array_equal(frame.TARGET, raw.TARGET.iloc[idx])
                seeds = [np.load(RUN/cohort/model/f'seed_{s}_predictions.npz')[split] for s in [42, 7, 2024, 13, 99]]
                np.testing.assert_array_equal(frame.probability, np.mean(seeds, axis=0))
                y = frame.TARGET.to_numpy()
                def measured(p):
                    return dict(auc=float(roc_auc_score(y, p)), ap=float(average_precision_score(y, p)),
                                mcc=float(matthews_corrcoef(y, p >= .5)))
                checks = measured(frame.probability.to_numpy())
                individual = [measured(p) for p in seeds]
                for metric in checks:
                    assert abs(checks[metric]-values['ensemble'][split][metric]) < 1e-12
                    np.testing.assert_allclose([x[metric] for x in individual], [x[split][metric] for x in values['runs']], rtol=0, atol=1e-12)
                    assert abs(np.mean([x[metric] for x in individual])-values['mean'][split][metric]) < 1e-12
                    assert abs(np.std([x[metric] for x in individual], ddof=1)-values['sd'][split][metric]) < 1e-12
                records.append({'cohort': cohort, 'model': model, 'split': split, 'verified': True})
    report = {'passed': True, 'model_split_summaries_checked': len(records), 'five_seed_predictions_each': True,
              'raw_ids_labels_and_mean_sd_ensemble_all_checked': True, 'checks': records}
    (RUN/'independent_metric_verification.json').write_text(json.dumps(report, indent=2)+'\n')
    print('Verified model/split summaries:', len(records))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('stage', choices=['data', 'metrics'])
    args = parser.parse_args()
    {'data': data_checks, 'metrics': metric_checks}[args.stage]()
