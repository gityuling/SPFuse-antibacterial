"""Produce global stability summaries and deterministic local PD-fusion cases."""
from pathlib import Path
import hashlib
from itertools import combinations
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from rdkit import Chem
from rdkit.Chem import AllChem, Draw

R=Path(__file__).resolve().parent
ROOT=R.parents[2]
BASE=ROOT/'official_comparison/runs/fixed_20261105/base_features.npy'
SEEDS=[42,7,2024,13,99]
assert json.loads((R/'status.json').read_text())['state']=='complete'
schema=json.loads((R/'protocol.json').read_text()); names=schema['feature_names_P']+schema['feature_names_D']
df=pd.read_csv(R/'test_membership.csv'); contributions={}; components={}; ranks=[]; branch_ranks={'P':[],'D':[]}
for s in SEEDS:
    c=np.load(R/f'seed_{s}_components.npz');components[s]=c
    arrays=[np.load(R/f'{b}_seed_{s}.npy',mmap_mode='r') for b in ['P','D']]
    contributions[s]=arrays
    imp=np.concatenate([np.mean(np.abs(arrays[j][:,:-1]),axis=0)*abs(c['weights'][j]) for j in range(2)])
    ranks.append(set(np.argsort(-imp,kind='stable')[:20]))
    branch_ranks['P'].append(set(np.argsort(-imp[:6311],kind='stable')[:10]))
    branch_ranks['D'].append(set(np.argsort(-imp[6311:],kind='stable')[:10]))
stability=[len(a&b)/len(a|b) for a,b in combinations(ranks,2)]
branch_stability={b:[len(a&c)/len(a|c) for a,c in combinations(v,2)] for b,v in branch_ranks.items()}
local_rows=[]
for start in range(0,len(df),128):
    end=min(start+128,len(df)); block=[]
    for s in SEEDS:
        c=components[s];a=contributions[s]
        block.append(np.concatenate([a[0][start:end,:-1]*c['weights'][0],a[1][start:end,:-1]*c['weights'][1]],axis=1))
    block=np.array(block)
    for i in range(end-start):
        v=block[:,i,:];top=[set(np.argsort(-np.abs(z),kind='stable')[:10]) for z in v]
        jaccards=[len(a&b)/len(a|b) for a,b in combinations(top,2)]
        union=np.array(sorted(set.union(*top)),dtype=int); selected=v[:,union]
        unanimous=np.all(selected>1e-8,axis=0)|np.all(selected< -1e-8,axis=0)
        local_rows.append({'COMPOUND_ID':df.COMPOUND_ID.iloc[start+i],'mean_top10_jaccard':float(np.mean(jaccards)),
                           'union_size':len(union),'unanimous_direction_fraction':float(np.mean(unanimous))})
pd.DataFrame(local_rows).to_csv(R/'local_stability.csv',index=False)
df['probability']=np.mean([components[s]['fusion_probability'] for s in SEEDS],axis=0)
df['category']=np.where(df.TARGET.eq(1),np.where(df.probability.ge(.5),'TP','FN'),np.where(df.probability.ge(.5),'FP','TN'))
base=np.load(BASE,mmap_mode='r');cases=[];mols=[];highlights=[]
fig,axs=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
for ax,category in zip(axs.flat,['TP','TN','FP','FN']):
    group=df[df.category.eq(category)].sort_values(['probability','COMPOUND_ID']);assert len(group)
    row=group.iloc[len(group)//2];pos=int(row.name);per_seed=[]
    for s in SEEDS:
        c=components[s];a=contributions[s]
        per_seed.append(np.r_[a[0][pos,:-1]*c['weights'][0],a[1][pos,:-1]*c['weights'][1]])
    per_seed=np.array(per_seed);values=per_seed.mean(axis=0);top=np.argsort(-np.abs(values),kind='stable')[:8]
    chosen=[]; mol=Chem.MolFromSmiles(row.PROCESSED_SMILES); assert mol is not None
    structural=[]
    for k in np.argsort(-np.abs(values[:6311]),kind='stable'):
        name=names[k]
        if not name.startswith('Morgan_r') or base[int(row.row),85+k] != 1: continue
        tag,bit=name.rsplit('_bit_',1);radius=int(tag[-1]);info={}
        fp=AllChem.GetMorganFingerprintAsBitVect(mol,radius,nBits=2048,bitInfo=info)
        offset=85 if radius==2 else 2133
        np.testing.assert_array_equal(np.asarray(fp),base[int(row.row),offset:offset+2048])
        atoms=set();occ=[]
        for center,radius0 in info[int(bit)]:
            bonds=list(Chem.FindAtomEnvironmentOfRadiusN(mol,int(radius0),int(center))); hit={int(center)}
            for bi in bonds:
                bond=mol.GetBondWithIdx(bi);hit.update([bond.GetBeginAtomIdx(),bond.GetEndAtomIdx()])
            atoms.update(hit);occ.append({'center':int(center),'radius':int(radius0),'atoms':sorted(hit)})
        if occ:
            structural={'feature':name,'contribution':float(values[k]),'occurrences':occ};chosen=sorted(atoms);break
    mols.append(mol);highlights.append(chosen)
    rr=[]
    for s in SEEDS:
        c=components[s];posscore=float(c['intercept']+np.dot(c['weights'],c['expected'][pos]+c['feature_sum'][pos]+c['residual'][pos]+c['clip_correction'][pos]))
        rr.append(posscore)
    cases.append({'compound_id':row.COMPOUND_ID,'smiles':row.PROCESSED_SMILES,'category':category,'probability_mean':float(row.probability),
       'mean_fusion_logit':float(np.mean(rr)),'fingerprint_sum':float(values[:6311].sum()),'descriptor_sum':float(values[6311:].sum()),
       'mapped_morgan':structural,'top_features':[{'name':names[k],'branch':'P' if k<6311 else 'D','mean_contribution':float(values[k]),
                                                  'sd':float(per_seed[:,k].std(ddof=1))} for k in top]})
    top=top[::-1];ax.barh([names[k].replace('_bit_',' bit ') for k in top],values[top],xerr=per_seed[:,top].std(axis=0,ddof=1),
        color=['#2674a5' if k<6311 else '#13866c' for k in top],capsize=2)
    ax.axvline(0,color='black',lw=.6);ax.set_title(f'{category}: {row.COMPOUND_ID}  (p={row.probability:.3f})');ax.set_xlabel('Contribution to fusion log-odds')
    ax.spines[['top','right']].set_visible(False)
for ext in ['png','pdf']:fig.savefig(R/f'classification_cases.{ext}',dpi=250); 
plt.close(fig)
img=Draw.MolsToGridImage(mols,molsPerRow=2,subImgSize=(600,320),legends=[x['category']+' '+x['compound_id'] for x in cases],highlightAtomLists=highlights)
img.save(str(R/'case_morgan_environments.png'))
(R/'classification_cases.json').write_text(json.dumps(cases,indent=2,allow_nan=False)+'\n')
(R/'analysis_summary.json').write_text(json.dumps({'global_top20_jaccard_mean':float(np.mean(stability)),
    'global_top20_jaccard_range':[float(min(stability)),float(max(stability))],
    'branch_top10_jaccard_mean':{b:float(np.mean(v)) for b,v in branch_stability.items()},
    'local_top10_jaccard_mean':float(np.mean([x['mean_top10_jaccard'] for x in local_rows])),
    'local_top10_union_direction_mean':float(np.mean([x['unanimous_direction_fraction'] for x in local_rows])),
    'local_direction_rule':'Same nonzero sign in all five seeds; evaluate union of seed-specific top-10 features per molecule.',
    'analysis_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'case_selection':'Median ensemble probability within each TP/TN/FP/FN category, tie by compound identifier.',
    'interpretation':'Values decompose the mean of individual fusion log-odds, not the logit of the mean predicted probability. Mapped Morgan bits can represent multiple folded environments.',
    'cases':len(cases)},indent=2)+'\n')
print('PD classification analysis complete',flush=True)
ranking=pd.read_csv(R/'feature_rankings.csv')
fig,axs=plt.subplots(1,2,figsize=(12,5.5),constrained_layout=True)
for ax,b,title,color in zip(axs,['P','D'],['Fingerprint branch','Descriptor branch'],['#2674a5','#13866c']):
    d=ranking[ranking.branch.eq(b)].head(10).iloc[::-1]
    ax.barh(d.feature.str.replace('_bit_',' bit ',regex=False),d.mean_absolute_fusion_logit_contribution,xerr=d.seed_sd,color=color,capsize=2)
    ax.set_title(title);ax.set_xlabel('Mean absolute contribution to fusion log-odds')
    ax.spines[['top','right']].set_visible(False);ax.grid(axis='x',alpha=.2);ax.set_axisbelow(True)
fig.suptitle('SPFuse: global feature contributions',fontweight='bold')
for ext in ['png','pdf']:fig.savefig(R/f'classification_global.{ext}',dpi=250)
plt.close(fig)
