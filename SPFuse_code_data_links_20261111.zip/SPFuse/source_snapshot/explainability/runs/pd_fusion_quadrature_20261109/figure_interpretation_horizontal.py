from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm,ListedColormap
from rdkit import Chem
from rdkit.Chem import Draw
from PIL import Image,ImageChops
R=Path(__file__).resolve().parent;O=R/'figures_v7';O.mkdir(exist_ok=True)
schema=json.loads((R/'protocol.json').read_text());rank=pd.read_csv(R/'feature_rankings.csv');test=pd.read_csv(R/'test_membership.csv');seeds=[42,7,2024,13,99];comp=[np.load(R/f'seed_{s}_components.npz') for s in seeds];prob=np.mean([c['fusion_probability'] for c in comp],axis=0);target=test.TARGET.to_numpy();order=np.lexsort((prob,target));boundary=int(np.sum(target==0));rows=[];labels=[]
for branch in ('P','D'):
 names=schema['feature_names_'+branch];arrays=[np.load(R/f'{branch}_seed_{s}.npy',mmap_mode='r') for s in seeds];w=0 if branch=='P' else 1
 for _,v in rank[rank.branch.eq(branch)].head(8).iterrows():
  idx=names.index(v.feature);rows.append(np.mean([a[:,idx]*float(c['weights'][w]) for a,c in zip(arrays,comp)],axis=0)[order]);labels.append(v.feature.replace('Morgan_r2_bit_','Morgan r2 · ').replace('Morgan_r3_bit_','Morgan r3 · ').replace('AtomPair_bit_','Atom pair · ').replace('MACCS_bit_','MACCS · ').replace('Torsion_bit_','Torsion · '))
mat=np.array(rows);cases=json.loads((R/'classification_cases.json').read_text());values=json.loads((R/'figures_v2/figure4_values.json').read_text())
ink='#263b48';blue='#346B96';green='#328474'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42,'svg.fonttype':'none','text.color':ink,'axes.labelcolor':ink,'xtick.color':ink,'ytick.color':ink,'axes.spines.top':False,'axes.spines.right':False})
fig=plt.figure(figsize=(14,8.5),facecolor='white');fig.text(.025,.97,'A',fontsize=15,fontweight='bold',va='top');fig.text(.057,.97,'Global attribution',fontsize=13,fontweight='bold',va='top');fig.text(.495,.97,'B',fontsize=15,fontweight='bold',va='top');fig.text(.526,.97,'Representative molecular predictions',fontsize=13,fontweight='bold',va='top')
# Left: one column per held-out molecule; grouped by label and then model probability.
a=fig.add_axes([.18,.884,.265,.020]);a.imshow(target[order][None,:],aspect='auto',interpolation='nearest',cmap=ListedColormap(['#cfd8dd','#647d8d']),vmin=0,vmax=1,rasterized=True);a.axis('off')
b=fig.add_axes([.18,.85,.265,.024]);b.imshow(prob[order][None,:],aspect='auto',interpolation='nearest',cmap='YlGnBu',vmin=0,vmax=1,rasterized=True);b.axis('off')
fig.text(.175,.892,'Measured',ha='right',va='center',fontsize=10.5);fig.text(.175,.861,'Predicted',ha='right',va='center',fontsize=10.5)
ax=fig.add_axes([.18,.22,.265,.60]);im=ax.imshow(mat,aspect='auto',interpolation='nearest',cmap='RdBu_r',norm=TwoSlopeNorm(vmin=-.15,vcenter=0,vmax=.15),rasterized=True)
ax.axvline(boundary-.5,color=ink,lw=.75);ax.axhline(7.5,color='white',lw=2);ax.set_yticks(range(16),labels);ax.tick_params(axis='y',length=0,pad=4,labelsize=10.5);ax.set_xticks([boundary/2,(boundary+len(test))/2],['Inactive','Active']);ax.tick_params(axis='x',length=0,pad=5,labelsize=10.5);[v.set_visible(False) for v in ax.spines.values()]
cbax=fig.add_axes([.18,.13,.265,.017]);cb=fig.colorbar(im,cax=cbax,orientation='horizontal',extend='both');cb.ax.tick_params(labelsize=10,length=2);cb.set_label('Feature contribution to fusion log-odds',fontsize=10.5,labelpad=2)
# Right: four individual cards, molecule above a compact three-step waterfall.
lab={'TP':'True positive','TN':'True negative','FP':'False positive','FN':'False negative'}
for i,(case,rec) in enumerate(zip(cases,values)):
 col=i%2;row=i//2;x0=.52+col*.24; y0=.53-row*.44
 assert case['compound_id']==rec['compound_id']
 fig.text(x0,y0+.385,f"{case['category']}  {lab[case['category']]}",fontsize=11,fontweight='bold',color=ink)
 fig.text(x0,y0+.355,f"{case['compound_id']}  ·  p = {case['probability_mean']:.3f}",fontsize=10,color='#607681')
 m=Chem.MolFromSmiles(case['smiles']);mapping=case['mapped_morgan'];atoms=sorted(set(a for occ in mapping['occurrences'] for a in occ['atoms']));img=Draw.MolToImage(m,size=(640,300),highlightAtoms=atoms).convert('RGB');bb=ImageChops.difference(img,Image.new('RGB',img.size,'white')).getbbox();img=img.crop((max(0,bb[0]-15),max(0,bb[1]-15),min(img.width,bb[2]+15),min(img.height,bb[3]+15)))
 ia=fig.add_axes([x0,y0+.20,.20,.14]);ia.imshow(img);ia.axis('off')
 ax=fig.add_axes([x0+.06,y0+.025,.155,.145]);mu=rec['means'];sd=rec['sd']
 for j,(start,change,end,err,color) in enumerate(zip([0,mu[0],mu[3]],[mu[0],mu[1],mu[2]],[mu[0],mu[3],mu[4]],[sd[0],sd[3],sd[4]],['#a4aeb7',blue,green])):
  ax.barh(j,change,left=start,height=.44,color=color,zorder=2);ax.errorbar(end,j,xerr=err,fmt='o',color=ink,markersize=2,capsize=1.5,elinewidth=.7,zorder=3)
  ax.text(end+(.09+err if end>=start else -.09-err),j,f'{change:+.2f}',va='center',ha='left' if end>=start else 'right',fontsize=9.5)
 ax.axvline(0,color='#a9b6bc',lw=.7);ax.set_xlim(-4.6,4.8);ax.set_ylim(2.6,-.6);ax.set_yticks([0,1,2],['Baseline','Fingerprint','Property']);ax.set_xticks([-4,0,4]);ax.tick_params(length=0,pad=3,labelsize=9.5);ax.grid(axis='x',color='#e6ecee',lw=.6);ax.set_axisbelow(True);ax.spines['left'].set_visible(False);ax.spines['bottom'].set_color('#cbd5d9')
 if row==1:ax.set_xlabel('Cumulative fusion log-odds',fontsize=10)
for ext in ('png','pdf','svg'):fig.savefig(O/f'spfuse_interpretation_horizontal.{ext}',dpi=300,facecolor='white')
print(O)
