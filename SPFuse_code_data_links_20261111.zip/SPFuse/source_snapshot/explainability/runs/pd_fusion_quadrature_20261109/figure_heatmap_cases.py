from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
R=Path(__file__).resolve().parent
out=R/'figures_v6';out.mkdir(exist_ok=True)
heat=Image.open(R/'figures_v5/spfuse_heatmap.png').convert('RGB')
cases=Image.open(R/'figures_v3/spfuse_combined_cases.png').convert('RGB')
# Remove redundant exterior whitespace, preserving the legends and labels.
heat=heat.crop((0,35,heat.width,heat.height-55)); cases=cases.crop((0,20,cases.width,cases.height-25))
fig=plt.figure(figsize=(11,15.1),facecolor='white')
a=fig.add_axes([.045,.505,.91,.465]);a.imshow(heat);a.axis('off')
b=fig.add_axes([.045,.025,.91,.465]);b.imshow(cases);b.axis('off')
fig.text(.025,.985,'A',fontweight='bold',fontsize=17,va='top',color='#263b48')
fig.text(.025,.500,'B',fontweight='bold',fontsize=17,va='top',color='#263b48')
for ext in ['png','pdf']:fig.savefig(out/f'spfuse_heatmap_cases.{ext}',dpi=300,facecolor='white')
print(out)
