from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
out=R/'figures_v5';out.mkdir(exist_ok=True)
schema=json.loads((R/'protocol.json').read_text())
rank=pd.read_csv(R/'feature_rankings.csv')
seeds=[42,7,2024,13,99]
components=[np.load(R/f'seed_{s}_components.npz') for s in seeds]
rng=np.random.default_rng(729)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42,'svg.fonttype':'none','text.color':'#273b47','axes.labelcolor':'#273b47','axes.spines.top':False,'axes.spines.right':False})
fig,axs=plt.subplots(1,2,figsize=(12.6,5.3))
for ax,branch,color,title in zip(axs,['P','D'],['#386e99','#278675'],['Fingerprint features','Molecular properties']):
 names=schema['feature_names_'+branch]; rows=rank[rank.branch.eq(branch)].head(8).iloc[::-1]
 data=[];raw=[np.load(R/f'{branch}_seed_{s}.npy',mmap_mode='r') for s in seeds]
 for _,row in rows.iterrows():
  idx=names.index(row.feature); wi=0 if branch=='P' else 1
  vals=np.mean([a[:,idx]*float(c['weights'][wi]) for a,c in zip(raw,components)],axis=0);data.append(vals)
 lim=max(np.quantile(np.abs(np.concatenate(data)),.997),.05)
 # Preserve every observation: tail observations beyond axis boundary are shown at the boundary.
 lim=float(np.ceil(lim*10)/10)
 for y,vals in enumerate(data):
  bins=np.floor(np.clip(vals,-lim,lim)/(.012*lim)).astype(int)
  _,inverse,counts=np.unique(bins,return_inverse=True,return_counts=True)
  density=counts[inverse]/counts.max()
  jitter=rng.uniform(-1,1,len(vals))*.36*np.sqrt(density)
  ax.scatter(np.clip(vals,-lim,lim),y+jitter,s=4,color=color,alpha=.22,linewidths=0,rasterized=True)
  ax.scatter([np.median(vals)],[y],s=20,color='#263442',edgecolor='white',linewidth=.5,zorder=4)
 labels=rows.feature.str.replace('Morgan_r2_bit_','Morgan r2 · ',regex=False).str.replace('Morgan_r3_bit_','Morgan r3 · ',regex=False).str.replace('AtomPair_bit_','Atom pair · ',regex=False).str.replace('MACCS_bit_','MACCS · ',regex=False).str.replace('Torsion_bit_','Torsion · ',regex=False)
 ax.set_yticks(np.arange(len(rows)),labels);ax.set_ylim(-.65,len(rows)-.35);ax.set_xlim(-lim,lim)
 ax.axvline(0,color='#7f8d96',lw=.9);ax.grid(axis='x',color='#e7ecef',lw=.7);ax.set_axisbelow(True)
 ax.set_title(title,loc='left',fontweight='bold',color=color,fontsize=11,pad=12)
 ax.set_xlabel('Contribution to fusion log-odds');ax.tick_params(length=0,pad=5);ax.spines['left'].set_visible(False);ax.spines['bottom'].set_color('#cbd4d9')
 print(branch,'limit',lim,'clipped',sum(np.sum(np.abs(v)>lim) for v in data),'molecules',len(data[0]))
fig.subplots_adjust(left=.13,right=.98,top=.86,bottom=.21,wspace=.60)
fig.text(.13,.96,'Global feature attribution across test molecules',fontsize=13,fontweight='bold',va='top')
fig.text(.13,.09,'Each dot: one molecule (mean across five seeds)     |     Dark dot: median',fontsize=8.5,color='#52626d')
for ext in ['png','pdf','svg']:fig.savefig(out/f'spfuse_beeswarm.{ext}',dpi=300,facecolor='white')
