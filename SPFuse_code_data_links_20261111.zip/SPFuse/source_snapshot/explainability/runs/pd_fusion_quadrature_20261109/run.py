"""Explain PD fusion through its component models on the official test partition."""
from pathlib import Path
import hashlib
import json
import os
import time
import joblib
import lightgbm as lgb
import numpy as np
import pandas as pd
from scipy.special import expit, logit

assert lgb.__version__ == '4.7.0.99', f'Wrong LightGBM attribution backend: {lgb.__version__}'
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
ABL=ROOT/'feature_ablation/runs/fixed_20261108'
OLD=ROOT/'official_comparison/runs/fixed_20261105'
FUS=ROOT/'fusion_probe/stacking_ablation_20261109'
SEEDS=[42,7,2024,13,99]

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for x in iter(lambda:f.read(1048576),b''):h.update(x)
    return h.hexdigest()

def save(p,v):
    t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n');t.replace(p)

def setup():
    df=pd.read_csv(ABL/'official/membership.csv'); raw=pd.read_csv(ROOT/'data/raw/SA_FG_fragments.csv',usecols=['COMPOUND_ID','TARGET'])
    np.testing.assert_array_equal(df.COMPOUND_ID,raw.COMPOUND_ID)
    ix=np.flatnonzero(df.group.eq('test')); assert len(ix)==4393
    sets=json.loads((ABL/'feature_sets.json').read_text()); names=json.loads((ROOT/'explainability/runs/multirepresentation_20261108/feature_schema.json').read_text())['names']
    assert len(sets['P'])==6311 and len(sets['D'])==123 and len(names)==6519
    files=[Path(__file__),ROOT/'explainability/runtime/lightgbm_nightly/lightgbm/lib/lib_lightgbm.so', ROOT/'explainability/runs/multirepresentation_20261108/selected_backend.json',ABL/'official/membership.csv',ABL/'feature_sets.json',OLD/'base_features.npy',FUS/'protocol.json']
    for s in SEEDS:
        for branch in ['P','D']:
            rec=json.loads((ABL/f'official/lgb_{branch}/seed_{s}_record.json').read_text())
            for name,digest in rec['hashes'].items():
                assert sha(ABL/name)==digest
            files.append(ABL/f'official/lgb_{branch}/seed_{s}.lgb')
        files.extend([FUS/f'seed_{s}/PD.joblib',FUS/f'seed_{s}/predictions.npz'])
    save(OUT/'protocol.json',{'description':'PD fusion attribution; isolated LightGBM 4.7.0.99 exact-degree QuadratureTreeSHAP pred_contrib, scaled by logistic meta coefficients in fusion log-odds.',
         'partition':'official test','n':len(ix),'seeds':SEEDS,'feature_names_P':names[85:6396],'feature_names_D':names[6396:],
         'important':'Contributions describe model score, not biological causality. Raw clipping corrections and native SHAP residuals are separately retained.',
         'sources':{str(p.relative_to(ROOT)):sha(p) for p in files}})
    df=df.iloc[ix].copy();df['TARGET']=raw.TARGET.iloc[ix].to_numpy();df.to_csv(OUT/'test_membership.csv',index=False)
    return ix,sets

def main():
    assert not (OUT/'protocol.json').exists(), 'Existing run: inspect before retry'
    ix,sets=setup(); base=np.load(OLD/'base_features.npy',mmap_mode='r')
    data={b:base[np.ix_(ix,sets[b])] for b in ['P','D']}
    summaries=[]
    for s in SEEDS:
        start=time.monotonic(); meta=joblib.load(FUS/f'seed_{s}/PD.joblib')
        scaler,lr=meta.steps[0][1],meta.steps[1][1]
        weights=lr.coef_[0]/scaler.scale_; intercept=float(lr.intercept_[0]-np.dot(weights,scaler.mean_))
        saved=np.load(FUS/f'seed_{s}/predictions.npz')['PD_test']; raw_branches=[]; branch_contrib=[]
        for j,b in enumerate(['P','D']):
            model=lgb.Booster(model_file=str(ABL/f'official/lgb_{b}/seed_{s}.lgb'))
            X=data[b]; raw=model.predict(X,raw_score=True,num_threads=4);raw_branches.append(raw)
            path=OUT/f'{b}_seed_{s}.npy'
            a=np.lib.format.open_memmap(path,mode='w+',dtype=np.float64,shape=(len(ix),X.shape[1]+1))
            for st in range(0,len(ix),128):
                end=min(len(ix),st+128)
                block=model.predict(X[st:end],pred_contrib=True,num_threads=4)
                np.testing.assert_allclose(block.sum(axis=1),raw[st:end],atol=1e-8,rtol=0)
                a[st:end]=block
                if st%512==0:
                    save(OUT/'status.json',{'state':'computing','pid':os.getpid(),'seed':s,'branch':b,'rows':end,'total':len(ix)})
                    print('SHAP',s,b,end,'/',len(ix),flush=True)
            a.flush()
            residual=raw-np.asarray(a,dtype=np.float64).sum(axis=1)
            assert np.max(np.abs(residual)) < 1e-8, 'TreeSHAP additivity failure'
            branch_contrib.append({'expected':np.asarray(a[:,-1],dtype=float),'feature_sum':np.asarray(a[:,:-1],dtype=float).sum(axis=1),'residual':residual})
            del a
        raw_arr=np.column_stack(raw_branches); clipped=logit(np.clip(expit(raw_arr),1e-6,1-1e-6)); correction=clipped-raw_arr
        reconstructed=intercept+sum(weights[j]*(branch_contrib[j]['expected']+branch_contrib[j]['feature_sum']+branch_contrib[j]['residual']+correction[:,j]) for j in range(2))
        np.testing.assert_allclose(expit(reconstructed),saved,atol=1e-10,rtol=0)
        np.savez_compressed(OUT/f'seed_{s}_components.npz',weights=weights,intercept=intercept,raw=raw_arr,clip_correction=correction,
             expected=np.column_stack([z['expected'] for z in branch_contrib]),feature_sum=np.column_stack([z['feature_sum'] for z in branch_contrib]),
             residual=np.column_stack([z['residual'] for z in branch_contrib]),fusion_probability=saved)
        summaries.append({'seed':s,'weights':weights.tolist(),'max_abs_prediction_error':float(np.max(np.abs(expit(reconstructed)-saved))),
             'max_abs_native_residual':float(max(np.max(np.abs(z['residual'])) for z in branch_contrib)),
             'clipped_branch_values':int((np.abs(correction)>1e-10).sum()),'seconds':round(time.monotonic()-start,1)})
        save(OUT/'progress.json',{'finished':summaries});print('Completed seed',s,flush=True)
    names=json.loads((OUT/'protocol.json').read_text());rows=[]
    for b in ['P','D']:
        values=[]
        for s in SEEDS:
            a=np.load(OUT/f'{b}_seed_{s}.npy',mmap_mode='r'); w=np.load(OUT/f'seed_{s}_components.npz')['weights'][0 if b=='P' else 1]
            values.append(np.mean(np.abs(a[:,:-1]),axis=0)*abs(w))
        values=np.array(values)
        for name,mean,sd in zip(names[f'feature_names_{b}'],values.mean(axis=0),values.std(axis=0,ddof=1)):
            rows.append({'branch':b,'feature':name,'mean_absolute_fusion_logit_contribution':float(mean),'seed_sd':float(sd)})
    pd.DataFrame(rows).sort_values('mean_absolute_fusion_logit_contribution',ascending=False).to_csv(OUT/'feature_rankings.csv',index=False)
    save(OUT/'status.json',{'state':'complete','pid':os.getpid(),'finished':summaries})

if __name__=='__main__':main()
