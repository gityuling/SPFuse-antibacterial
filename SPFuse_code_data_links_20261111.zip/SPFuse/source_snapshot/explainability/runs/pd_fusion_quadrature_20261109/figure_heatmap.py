from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm, ListedColormap
from matplotlib.lines import Line2D
R=Path(__file__).resolve().parent
O=R/'figures_v5';O.mkdir(exist_ok=True)
schema=json.loads((R/'protocol.json').read_text()); rank=pd.read_csv(R/'feature_rankings.csv'); test=pd.read_csv(R/'test_membership.csv')
seeds=[42,7,2024,13,99]; comp=[np.load(R/f'seed_{s}_components.npz') for s in seeds]
prob=np.mean([c['fusion_probability'] for c in comp],axis=0); target=test.TARGET.to_numpy(); order=np.lexsort((prob,target)); boundary=int(np.sum(target==0))
rows=[]; labels=[]
for branch in ('P','D'):
 names=schema['feature_names_'+branch]; arrays=[np.load(R/f'{branch}_seed_{s}.npy',mmap_mode='r') for s in seeds]; w=0 if branch=='P' else 1
 for _,v in rank[rank.branch.eq(branch)].head(8).iterrows():
  idx=names.index(v.feature); rows.append(np.mean([a[:,idx]*float(c['weights'][w]) for a,c in zip(arrays,comp)],axis=0)[order]);labels.append(v.feature.replace('Morgan_r2_bit_','Morgan r2 · ').replace('Morgan_r3_bit_','Morgan r3 · ').replace('AtomPair_bit_','Atom pair · ').replace('MACCS_bit_','MACCS · ').replace('Torsion_bit_','Torsion · '))
mat=np.array(rows); lim=.15; print('shape',mat.shape,'clipped',np.sum(np.abs(mat)>lim),'of',mat.size)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42,'svg.fonttype':'none','text.color':'#263b48','axes.labelcolor':'#263b48','xtick.color':'#263b48','ytick.color':'#263b48','axes.spines.top':False,'axes.spines.right':False})
fig=plt.figure(figsize=(11,6.8));gs=fig.add_gridspec(3,2,height_ratios=[.19,.42,4.8],width_ratios=[30,1],left=.19,right=.90,top=.88,bottom=.13,hspace=.13,wspace=.13)
a=fig.add_subplot(gs[0,0]);a.imshow(target[order][None,:],aspect='auto',interpolation='nearest',cmap=ListedColormap(['#ced6dc','#647d8d']),vmin=0,vmax=1,rasterized=True);a.set_yticks([0],['Measured activity']);a.set_xticks([]);a.tick_params(length=0,labelbottom=False);[sp.set_visible(False) for sp in a.spines.values()]
b=fig.add_subplot(gs[1,0],sharex=a);b.imshow(prob[order][None,:],aspect='auto',interpolation='nearest',cmap='YlGnBu',vmin=0,vmax=1,rasterized=True);b.set_yticks([0],['Predicted probability']);b.set_xticks([]);b.tick_params(length=0,labelbottom=False);[sp.set_visible(False) for sp in b.spines.values()]
ax=fig.add_subplot(gs[2,0],sharex=a); im=ax.imshow(mat,aspect='auto',interpolation='nearest',cmap='RdBu_r',norm=TwoSlopeNorm(vmin=-lim,vcenter=0,vmax=lim),rasterized=True)
ax.axvline(boundary-.5,color='#273b47',lw=.8);ax.axhline(7.5,color='white',lw=2);ax.set_yticks(range(16),labels);ax.tick_params(axis='y',length=0,pad=5);ax.set_xticks([boundary/2,(boundary+len(test))/2],['Measured inactive','Measured active']);ax.tick_params(axis='x',length=0,pad=7);[sp.set_visible(False) for sp in ax.spines.values()]
cax=fig.add_subplot(gs[2,1]);cb=fig.colorbar(im,cax=cax,extend='both');cb.set_label('Contribution to fusion log-odds',fontsize=9);cb.ax.tick_params(labelsize=8)
fig.text(.19,.97,'Attribution patterns across test molecules',fontsize=13,fontweight='bold',va='top');fig.text(.19,.925,'Molecules are ordered by predicted probability within each measured class',fontsize=9,color='#536670')
fig.text(.015,.52,'Fingerprint',fontsize=9,fontweight='bold',color='#346B96',rotation=90,va='center');fig.text(.015,.23,'Property',fontsize=9,fontweight='bold',color='#328474',rotation=90,va='center')
fig.text(.19,.055,'One column per molecule; values are averaged across five seeds. Color is capped at ±0.15.',fontsize=8.3,color='#536670')
for ext in ('png','pdf','svg'):fig.savefig(O/f'spfuse_heatmap.{ext}',dpi=300,facecolor='white')
