"""Run the descriptive analysis once the independent attribution job finishes."""
from pathlib import Path
import json,os,subprocess,sys,time
R=Path(__file__).resolve().parent
pid=int((R/'run.pid').read_text())
while True:
    status=json.loads((R/'status.json').read_text()) if (R/'status.json').exists() else {}
    if status.get('state')=='complete':
        result=subprocess.run([sys.executable,str(R/'analyze.py')],check=False)
        (R/'analysis_status.json').write_text(json.dumps({'state':'complete' if result.returncode==0 else 'failed','exit_code':result.returncode},indent=2)+'\n')
        break
    try: os.kill(pid,0)
    except ProcessLookupError:
        (R/'analysis_status.json').write_text(json.dumps({'state':'blocked','reason':'Attribution process ended before completion'},indent=2)+'\n')
        break
    time.sleep(30)
