from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from rdkit import Chem
from rdkit.Chem import Draw
R=Path(__file__).resolve().parent
O=R/'figures_v4'; O.mkdir(exist_ok=True)
r=pd.read_csv(R/'feature_rankings.csv')
cases=json.loads((R/'classification_cases.json').read_text())
values=json.loads((R/'figures_v2/figure4_values.json').read_text())
blue,green,ink='#346B96','#328474','#263442'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42,'svg.fonttype':'none','text.color':ink,'axes.labelcolor':ink,'xtick.color':ink,'ytick.color':ink,'axes.spines.top':False,'axes.spines.right':False})
fig=plt.figure(figsize=(10,13.2),facecolor='white')
outer=fig.add_gridspec(2,1,height_ratios=[3.1,7.1],left=.15,right=.97,top=.925,bottom=.055,hspace=.27)
globalgs=outer[0].subgridspec(1,2,wspace=.66)
for j,(b,title,color) in enumerate([('P','Fingerprint features',blue),('D','Molecular properties',green)]):
 ax=fig.add_subplot(globalgs[0,j]); d=r[r.branch.eq(b)].head(8).iloc[::-1]; y=np.arange(len(d))
 lab=d.feature.str.replace('Morgan_r2_bit_','Morgan r2 · ',regex=False).str.replace('Morgan_r3_bit_','Morgan r3 · ',regex=False).str.replace('AtomPair_bit_','Atom pair · ',regex=False).str.replace('MACCS_bit_','MACCS · ',regex=False).str.replace('Torsion_bit_','Torsion · ',regex=False)
 ax.barh(y,d.mean_absolute_fusion_logit_contribution,height=.54,color=color,alpha=.82)
 ax.errorbar(d.mean_absolute_fusion_logit_contribution,y,xerr=d.seed_sd,fmt='none',ecolor=ink,elinewidth=.9,capsize=2,zorder=3)
 ax.set_yticks(y,lab);ax.set_xlim(0,.052);ax.set_title(title,loc='left',fontsize=10,fontweight='bold',color=color,pad=9)
 ax.grid(axis='x',color='#e7ebee',lw=.7);ax.set_axisbelow(True);ax.tick_params(length=0,pad=4,labelsize=8)
 ax.spines['left'].set_visible(False);ax.spines['bottom'].set_color('#cbd4d9');ax.set_xlabel('Mean absolute contribution',fontsize=8.5)
fig.text(.025,.985,'A',fontsize=15,fontweight='bold',va='top')
fig.text(.15,.985,'Global feature attribution',fontsize=11.5,fontweight='bold',va='top')
fig.text(.025,.645,'B',fontsize=15,fontweight='bold',va='top')
fig.text(.15,.645,'Representative molecular predictions',fontsize=11.5,fontweight='bold',va='top')
casegs=outer[1].subgridspec(4,2,width_ratios=[1.38,1.75],hspace=.39,wspace=.13)
labels={'TP':'True positive','TN':'True negative','FP':'False positive','FN':'False negative'}
for i,(case,rec) in enumerate(zip(cases,values)):
 assert case['compound_id']==rec['compound_id']
 mol=Chem.MolFromSmiles(case['smiles']); mapping=case['mapped_morgan'];atoms=sorted(set(a for occ in mapping['occurrences'] for a in occ['atoms']))
 img=Draw.MolToImage(mol,size=(720,310),highlightAtoms=atoms)
 left=fig.add_subplot(casegs[i,0]);left.imshow(img);left.set_axis_off()
 left.text(.02,1.03,f"{case['category']}  {labels[case['category']]}  ·  {case['compound_id']}",transform=left.transAxes,fontsize=8.8,fontweight='bold',va='bottom')
 left.text(.02,-.025,f"p(active) = {case['probability_mean']:.3f}   |   {mapping['feature'].replace('_bit_', ' bit ')}",transform=left.transAxes,fontsize=8,color='#52626D',va='top')
 ax=fig.add_subplot(casegs[i,1]);m=rec['means'];sd=rec['sd']
 for k,(start,change,end,err,color) in enumerate(zip([0,m[0],m[3]],[m[0],m[1],m[2]],[m[0],m[3],m[4]],[sd[0],sd[3],sd[4]],['#a4aeb7',blue,green])):
  ax.barh(k,change,left=start,height=.43,color=color,alpha=.9,zorder=2)
  ax.errorbar(end,k,xerr=err,fmt='o',color=ink,markersize=2.7,capsize=2,elinewidth=.8,zorder=3)
  ax.text(end+(.1+err if end>=start else -.1-err),k,f'{change:+.2f}',va='center',ha='left' if end>=start else 'right',fontsize=8)
 ax.axvline(0,color='#89969e',lw=.8);ax.set_xlim(-2.8,3.35);ax.set_ylim(2.65,-.65)
 ax.set_yticks([0,1,2],['Baseline','Fingerprint','Property']);ax.tick_params(length=0,pad=4,labelsize=8)
 ax.grid(axis='x',color='#e7ebee',lw=.7);ax.set_axisbelow(True);ax.spines['left'].set_visible(False);ax.spines['bottom'].set_color('#cbd4d9')
 if i<3:ax.tick_params(labelbottom=False)
 else:ax.set_xlabel('Cumulative fusion log-odds',fontsize=8.5)
fig.text(.08,.018,'Bars: mean contribution   |   Error bars: standard deviation across five seeds   |   Highlight: selected Morgan environment',fontsize=7.7,color='#52626D')
for ext in ('pdf','png','svg'): fig.savefig(O/f'spfuse_interpretation_combined.{ext}',dpi=240,facecolor='white')
print(O)
