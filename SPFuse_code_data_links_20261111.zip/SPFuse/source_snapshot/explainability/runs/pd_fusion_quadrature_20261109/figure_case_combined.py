"""Combine molecule mappings and branch score decompositions for four cases."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from rdkit import Chem
from rdkit.Chem import Draw

R=Path(__file__).resolve().parent
OUT=R/'figures_v3';OUT.mkdir(exist_ok=True)
cases=json.loads((R/'classification_cases.json').read_text())
values=json.loads((R/'figures_v2/figure4_values.json').read_text())
assert len(cases)==len(values)==4
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9.0,'pdf.fonttype':42,'svg.fonttype':'none',
    'axes.spines.top':False,'axes.spines.right':False,'text.color':'#263442','axes.labelcolor':'#263442',
    'xtick.color':'#263442','ytick.color':'#263442'})
blue,green,gray='#346B96','#328474','#9BA6AF'
fig=plt.figure(figsize=(10,8.6))
gs=fig.add_gridspec(4,2,width_ratios=[1.35,1.8],left=.055,right=.97,top=.965,bottom=.105,hspace=.32,wspace=.11)
for i,(case,rec) in enumerate(zip(cases,values)):
    assert case['compound_id']==rec['compound_id'] and case['category']==rec['category']
    mol=Chem.MolFromSmiles(case['smiles']);assert mol is not None
    mapping=case['mapped_morgan']; atoms=sorted(set(a for occ in mapping['occurrences'] for a in occ['atoms'])) if mapping else []
    image=Draw.MolToImage(mol,size=(720,310),highlightAtoms=atoms)
    left=fig.add_subplot(gs[i,0]);left.imshow(image);left.set_axis_off()
    labels={'TP':'True positive','TN':'True negative','FP':'False positive','FN':'False negative'}
    left.text(.02,1.02,f"{case['category']}  {labels[case['category']]}  ·  {case['compound_id']}",
              transform=left.transAxes,ha='left',va='bottom',fontsize=9.4,fontweight='bold')
    left.text(.02,-.02,f"p(active) = {case['probability_mean']:.3f}   |   highlighted: {mapping['feature'].replace('_bit_', ' bit ') if mapping else 'none'}",
              transform=left.transAxes,ha='left',va='top',fontsize=8.1,color='#52626D')
    right=fig.add_subplot(gs[i,1]);m=rec['means'];sd=rec['sd']
    starts=[0,m[0],m[3]]; changes=[m[0],m[1],m[2]];ends=[m[0],m[3],m[4]];errs=[sd[0],sd[3],sd[4]]
    for j,(start,change,end,err,color) in enumerate(zip(starts,changes,ends,errs,[gray,blue,green])):
        right.barh(j,change,left=start,height=.42,color=color,alpha=.9,zorder=2)
        right.errorbar(end,j,xerr=err,fmt='o',color='#263442',markersize=3,capsize=2,elinewidth=.85,zorder=3)
        pos=end+(.11+err if end>=start else -.11-err)
        right.text(pos,j,f'{change:+.2f}',va='center',ha='left' if end>=start else 'right',fontsize=8.4)
    right.axvline(0,color='#84939c',lw=.85);right.set_xlim(-2.8,3.35);right.set_ylim(2.65,-.65)
    right.set_yticks([0,1,2],['Baseline','Fingerprint','Property']);right.tick_params(axis='both',length=0,pad=4)
    right.grid(axis='x',color='#e6ebee',lw=.7);right.set_axisbelow(True)
    right.spines['left'].set_visible(False);right.spines['bottom'].set_color('#cbd4d9')
    if i<3:right.tick_params(labelbottom=False)
    else:right.set_xlabel('Cumulative fusion log-odds',fontsize=9)
fig.text(.055,.025,'Structures: highlighted Morgan environment   |   Bars: mean contribution   |   Dots: cumulative score (mean ± SD)',
         fontsize=8.1,color='#52626D')
for ext in ['pdf','png','svg']:fig.savefig(OUT/f'spfuse_combined_cases.{ext}',dpi=300,facecolor='white')
print('Saved',OUT/'spfuse_combined_cases.pdf')
