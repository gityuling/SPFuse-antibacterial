"""Redraw publication figures using the frozen SPFuse attribution results."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

R=Path(__file__).resolve().parent
OUT=R/'figures_v2'; OUT.mkdir(exist_ok=True)
SEEDS=[42,7,2024,13,99]
BLUE='#346B96'; GREEN='#328474'; GRAY='#9BA6AF'; INK='#263442'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9.5,'axes.labelcolor':INK,
    'text.color':INK,'xtick.color':INK,'ytick.color':INK,'pdf.fonttype':42,'svg.fonttype':'none',
    'axes.spines.top':False,'axes.spines.right':False})

ranking=pd.read_csv(R/'feature_rankings.csv')
fig,axs=plt.subplots(1,2,figsize=(10,4.8),sharex=True)
for ax,b,title,color in zip(axs,['P','D'],['Fingerprint branch','Property branch'],[BLUE,GREEN]):
    d=ranking[ranking.branch.eq(b)].head(8).iloc[::-1]
    y=np.arange(len(d));labels=d.feature.str.replace('Morgan_r2_bit_','Morgan r2 · ',regex=False).str.replace('Morgan_r3_bit_','Morgan r3 · ',regex=False).str.replace('AtomPair_bit_','Atom pair · ',regex=False).str.replace('MACCS_bit_','MACCS · ',regex=False).str.replace('Torsion_bit_','Torsion · ',regex=False)
    ax.hlines(y,0,d.mean_absolute_fusion_logit_contribution,color=color,alpha=.24,lw=2)
    ax.errorbar(d.mean_absolute_fusion_logit_contribution,y,xerr=d.seed_sd,fmt='o',color=color,
                markersize=5.8,elinewidth=1.15,capsize=2.4,zorder=3)
    ax.set_yticks(y,labels);ax.set_xlim(0,.052);ax.set_title(title,loc='left',fontweight='bold',fontsize=11,pad=12)
    ax.set_xlabel('Mean |contribution| to fusion log-odds');ax.grid(axis='x',color='#E5EAED',lw=.7);ax.set_axisbelow(True)
    ax.tick_params(axis='both',length=0,pad=5);ax.spines['left'].set_visible(False);ax.spines['bottom'].set_color('#CED5DA')
fig.subplots_adjust(left=.16,right=.99,bottom=.15,top=.90,wspace=.43)
for ext in ['pdf','png','svg']:fig.savefig(OUT/f'spfuse_global.{ext}',dpi=300,facecolor='white')
plt.close(fig)

cases=json.loads((R/'classification_cases.json').read_text());members=pd.read_csv(R/'test_membership.csv')
components={s:np.load(R/f'seed_{s}_components.npz') for s in SEEDS}
arrays={s:[np.load(R/f'{b}_seed_{s}.npy',mmap_mode='r') for b in ['P','D']] for s in SEEDS}
records=[]
for case in cases:
    positions=np.flatnonzero(members.COMPOUND_ID.eq(case['compound_id']).to_numpy());assert len(positions)==1
    pos=int(positions[0]); values=[]
    for s in SEEDS:
        c=components[s];w=c['weights']; a=arrays[s]
        baseline=float(c['intercept']+np.dot(w,c['expected'][pos]+c['residual'][pos]+c['clip_correction'][pos]))
        p=float(w[0]*a[0][pos,:-1].sum()); d=float(w[1]*a[1][pos,:-1].sum())
        values.append([baseline,p,d,baseline+p,baseline+p+d])
    values=np.array(values);means=values.mean(axis=0);sd=values.std(axis=0,ddof=1)
    np.testing.assert_allclose(means[4],case['mean_fusion_logit'],atol=1e-9)
    np.testing.assert_allclose(means[1:3],[case['fingerprint_sum'],case['descriptor_sum']],atol=1e-9)
    records.append({'category':case['category'],'compound_id':case['compound_id'],'probability':case['probability_mean'],
                    'means':means.tolist(),'sd':sd.tolist()})

fig=plt.figure(figsize=(9.2,8.0)); gs=fig.add_gridspec(4,2,width_ratios=[1.35,3.4],left=.055,right=.97,bottom=.13,top=.965,hspace=.46,wspace=.2)
for i,rec in enumerate(records):
    axlabel=fig.add_subplot(gs[i,0]);axlabel.axis('off')
    label={'TP':'True positive','TN':'True negative','FP':'False positive','FN':'False negative'}[rec['category']]
    axlabel.text(0,.86,f"{rec['category']}  {label}",fontsize=10.5,fontweight='bold',va='top')
    axlabel.text(0,.54,rec['compound_id'],fontsize=9,va='center')
    axlabel.text(0,.18,f"p(active) = {rec['probability']:.3f}",fontsize=9,va='bottom',color='#4D5B66')
    ax=fig.add_subplot(gs[i,1]);mu=np.array(rec['means']);sd=np.array(rec['sd'])
    starts=[0,mu[0],mu[3]]; steps=[mu[0],mu[1],mu[2]]; ends=[mu[0],mu[3],mu[4]]; end_sd=[sd[0],sd[3],sd[4]]
    for j,(start,step,end,err,color) in enumerate(zip(starts,steps,ends,end_sd,[GRAY,BLUE,GREEN])):
        ax.barh(j,step,left=start,height=.44,color=color,alpha=.9,zorder=2)
        ax.errorbar(end,j,xerr=err,fmt='o',color='#243743',markersize=3,elinewidth=1,capsize=2,zorder=3)
        xtext=end+(.10+err if end>=start else -.10-err)
        ax.text(xtext,j,f'{step:+.2f}',va='center',ha='left' if end>=start else 'right',fontsize=9)
    ax.axvline(0,color='#7D8B94',lw=.9);ax.set_xlim(-2.8,3.35);ax.set_ylim(2.65,-.65)
    ax.set_yticks([0,1,2],['Baseline','Fingerprint','Property']);ax.tick_params(axis='both',length=0,pad=5)
    ax.grid(axis='x',color='#E5EAED',lw=.7);ax.set_axisbelow(True)
    ax.spines['left'].set_visible(False);ax.spines['bottom'].set_color('#CED5DA')
    if i<3:ax.tick_params(labelbottom=False)
    else:ax.set_xlabel('Cumulative fusion log-odds')
fig.text(.055,.035,'Bars: mean contribution across five seeds   |   Dots: cumulative log-odds (mean ± SD)',fontsize=9,color='#52626D')
for ext in ['pdf','png','svg']:fig.savefig(OUT/f'spfuse_cases.{ext}',dpi=300,facecolor='white')
plt.close(fig)
(OUT/'figure4_values.json').write_text(json.dumps(records,indent=2,ensure_ascii=False)+'\n')
print('Saved figures to',OUT)
