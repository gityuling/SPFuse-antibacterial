"""All seven branch subsets, identical OOF logistic fusion settings, five seeds."""
import importlib.util
import json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[1]
PREV = ROOT / 'fusion_probe/stacking_20261109'
spec = importlib.util.spec_from_file_location('frozen_stacking', PREV / 'run.py')
core = importlib.util.module_from_spec(spec)
spec.loader.exec_module(core)
GROUPS = ['F', 'P', 'D', 'FP', 'FD', 'PD', 'FPD']


def main():
    assert not (RUN / 'protocol.json').exists(), 'Existing run; do not overwrite results.'
    core.verify()
    members, y, idx, _ = core.load_data()
    tr = idx['training']
    sources = [Path(__file__), PREV / 'protocol.json']
    for s in core.SEEDS:
        seal = json.loads((PREV / f'seed_{s}/seal.json').read_text())
        for name in ['oof.npz', 'predictions.npz']:
            path = PREV / f'seed_{s}' / name
            assert core.sha(path) == seal['files'][name]
            sources.append(path)
        sources += [core.OLD / f'official/lgb_{f}/seed_{s}_predictions.npz' for f in ['F', 'P', 'D']]
    core.write(RUN / 'protocol.json', {'created_utc': core.now(), 'groups': GROUPS, 'seeds': core.SEEDS,
        'method': 'Reuse identical F/P/D base models and training-only OOF predictions. Fit a separate StandardScaler + L2 logistic regression C1 on logit probabilities for every subset.',
        'single_branch': 'F/P/D also pass through the same one-input meta learner; this is OOF logistic calibration, distinct from raw base-model probabilities.',
        'controls': 'Same original official membership, same five seeds, same frozen base and meta configurations. No tuning or test-based subset selection.',
        'evaluation': 'Save all35 prediction sets before scoring. Mean and sample SD over seeds; MCC threshold0.5.',
        'source_sha256': {str(p.relative_to(ROOT)): core.sha(p) for p in sources}})
    (RUN / 'protocol.sha256').write_text(core.sha(RUN / 'protocol.json') + '\n')
    for s in core.SEEDS:
        folder = RUN / f'seed_{s}'
        folder.mkdir(exist_ok=True)
        oof = np.load(PREV / f'seed_{s}/oof.npz')
        np.testing.assert_array_equal(oof['training_rows'], tr)
        held = {f: np.load(core.OLD / f'official/lgb_{f}/seed_{s}_predictions.npz') for f in ['F', 'P', 'D']}
        old = np.load(PREV / f'seed_{s}/predictions.npz')
        outputs = {}
        coefs = {}
        for group in GROUPS:
            z = core.logits(np.column_stack([oof[f] for f in group]))
            model = core.meta_model(s).fit(z, y[tr])
            assert int(model.steps[-1][1].n_iter_.max()) < 2000
            joblib.dump(model, folder / f'{group}.joblib')
            coefs[group] = {'branches': list(group), 'scaled_logit_coefficients': model.steps[-1][1].coef_.tolist(),
                            'intercept': model.steps[-1][1].intercept_.tolist()}
            for split in ['valid', 'test']:
                for f in group:
                    np.testing.assert_array_equal(held[f][split + '_rows'], idx[split])
                zz = core.logits(np.column_stack([held[f][split] for f in group]))
                p = model.predict_proba(zz)[:, 1]
                assert np.isfinite(p).all()
                if group in ['P', 'FPD']:
                    key = 'P_calibrated' if group == 'P' else 'FPD_stack'
                    np.testing.assert_allclose(p, old[key + '_' + split], rtol=0, atol=1e-12)
                outputs[group + '_' + split] = p
        np.savez_compressed(folder / 'predictions.npz', valid_rows=idx['valid'], test_rows=idx['test'], **outputs)
        core.write(folder / 'coefficients.json', coefs)
        print('Prepared all subsets for seed', s, flush=True)
    core.write(RUN / 'prediction_seal.json', {'sealed_utc': core.now(), 'test_scored': False,
        'files': {str(p.relative_to(RUN)): core.sha(p) for p in RUN.glob('seed_*/*') if p.is_file()},
        'existing_FPD_and_P_calibration_reproduced': True})
    raw = pd.read_csv(ROOT / 'data/raw/SA_FG_fragments.csv')
    np.testing.assert_array_equal(raw.COMPOUND_ID, members.COMPOUND_ID)
    rows, per_seed = [], []
    for split in ['valid', 'test']:
        yy = raw.TARGET.to_numpy()[idx[split]]
        for group in GROUPS:
            vals = []
            frame = raw.iloc[idx[split]][['COMPOUND_ID', 'TARGET']].copy()
            for s in core.SEEDS:
                saved = np.load(RUN / f'seed_{s}/predictions.npz')
                np.testing.assert_array_equal(saved[split + '_rows'], idx[split])
                p = saved[group + '_' + split]
                frame[f'seed_{s}'] = p
                metrics = core.score(yy, p)
                vals.append(metrics)
                per_seed.append(dict(split=split, group=group, seed=s, **metrics))
            row = dict(split=split, group=group, n_seeds=5)
            for m in ['AUROC', 'AP', 'MCC']:
                row[m] = float(np.mean([v[m] for v in vals]))
                row[m + '_sd'] = float(np.std([v[m] for v in vals], ddof=1))
            rows.append(row)
            frame.to_csv(RUN / f'{group}_{split}_predictions.csv', index=False)
    pd.DataFrame(rows).to_csv(RUN / 'comparison.csv', index=False)
    core.write(RUN / 'results.json', {'completed_utc': core.now(), 'summary': rows, 'per_seed': per_seed})
    lines = ['融合器全组合消融：同一官方测试集，5种子均值±样本SD，MCC阈值0.5。',
             '所有组都使用相同逻辑回归融合层；F/P/D单分支相当于折外概率校准。', '']
    for r in rows:
        if r['split'] == 'test':
            lines.append(r['group'] + ' | ' + ' | '.join(f"{m} {r[m]:.4f} ± {r[m + '_sd']:.4f}" for m in ['AUROC', 'AP', 'MCC']))
    (RUN / '结果速览.txt').write_text('\n'.join(lines) + '\n')
    print('\n'.join(lines))


if __name__ == '__main__':
    main()
