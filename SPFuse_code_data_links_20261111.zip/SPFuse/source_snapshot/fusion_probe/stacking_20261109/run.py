"""OOF-trained representation fusion and matched three-fingerprint-model controls."""
import argparse
from datetime import datetime, timezone
import fcntl
import gc
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import joblib
import lightgbm as lgb
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score, matthews_corrcoef
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[1]
OLD = ROOT / 'feature_ablation/runs/fixed_20261108'
BASE = ROOT / 'official_comparison/runs/fixed_20261105/base_features.npy'
SEEDS = [42, 7, 2024, 13, 99]
BRANCHES = {'F': ('F', 0), 'P': ('P', 0), 'D': ('D', 0), 'P2': ('P', 10000), 'P3': ('P', 20000)}


def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def write(p, value):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    tmp.replace(p)


def now():
    return datetime.now(timezone.utc).isoformat()


def load_data():
    members = pd.read_csv(OLD / 'official/membership.csv')
    y = np.load(OLD / 'official/training_targets.npy')
    indices = {g: np.flatnonzero(members.group.eq(g)) for g in ['training', 'valid', 'test']}
    assert [len(indices[g]) for g in indices] == [35006, 4378, 4393]
    assert np.isin(y[indices['training']], [0, 1]).all()
    assert (y[np.r_[indices['valid'], indices['test']]] == -1).all()
    features = json.loads((OLD / 'feature_sets.json').read_text())
    return members, y, indices, features


def params(seed):
    p = json.loads((OLD / 'protocol.json').read_text())['hyperparameters']['42'].copy()
    return dict(p, seed=seed, bagging_seed=seed + 1, feature_fraction_seed=seed + 2, num_threads=4)


def logits(p):
    p = np.clip(p, 1e-6, 1 - 1e-6)
    return np.log(p / (1 - p))


def meta_model(seed):
    return make_pipeline(StandardScaler(), LogisticRegression(C=1., solver='lbfgs', max_iter=2000, random_state=seed))


def smoke():
    _, y, idx, sets = load_data()
    # Small training-only functional test, deliberately not a performance estimate.
    sample = np.r_[idx['training'][y[idx['training']] == 0][:80], idx['training'][y[idx['training']] == 1][:80]]
    X = np.load(BASE, mmap_mode='r')[np.ix_(sample, sets['F'])]
    yy = y[sample]
    oof = np.full(len(yy), np.nan)
    for fit, hold in StratifiedKFold(2, shuffle=True, random_state=42).split(X, yy):
        assert not set(fit) & set(hold)
        model = lgb.train(params(42), lgb.Dataset(X[fit], label=yy[fit]), num_boost_round=5)
        oof[hold] = model.predict(X[hold])
    assert np.isfinite(oof).all()
    z = logits(np.column_stack([oof, oof, oof]))
    meta = meta_model(42).fit(z, yy)
    p = meta.predict_proba(z)[:, 1]
    joblib.dump(meta, RUN / 'smoke_meta.joblib')
    np.testing.assert_allclose(joblib.load(RUN / 'smoke_meta.joblib').predict_proba(z)[:, 1], p, atol=1e-14)
    write(RUN / 'smoke.json', {'passed': True, 'training_rows_only': len(sample), 'finite_oof': True, 'reload_passed': True})
    print('Smoke passed', flush=True)


def freeze():
    assert not (RUN / 'protocol.json').exists()
    assert json.loads((RUN / 'smoke.json').read_text())['passed']
    _, y, idx, _ = load_data()
    tr = idx['training']
    fold = np.full(len(tr), -1)
    for k, (fit, hold) in enumerate(StratifiedKFold(5, shuffle=True, random_state=42).split(tr, y[tr])):
        assert not set(fit) & set(hold)
        fold[hold] = k
    assert (fold >= 0).all()
    np.savez_compressed(RUN / 'folds.npz', training_rows=tr, fold=fold)
    sources = [Path(__file__), BASE, OLD / 'protocol.json', OLD / 'feature_sets.json',
               OLD / 'official/membership.csv', OLD / 'official/training_targets.npy', RUN / 'folds.npz']
    sources += [OLD / f'official/lgb_{f}/seed_{s}_predictions.npz' for f in ['F', 'P', 'D', 'FPD'] for s in SEEDS]
    protocol = {'created_utc': now(), 'seeds': SEEDS, 'folds': 5, 'fold_seed': 42,
        'training': 'Official training partition only; stratified inner folds. Every meta-training row is predicted by base models excluding that row. No external labels, validation refit or heldout-driven selection.',
        'base_config_seed42': params(42), 'num_boost_round': 900,
        'branches': BRANCHES, 'planned_new_base_fits': 135,
        'full_models': 'Reuse original full-training F/P/D/FPD predictions; train two additional full-training P models per outer seed. Fold models produce OOF probabilities only and are not inference ensemble members.',
        'fusion': 'StandardScaler on clipped log-odds; L2 logistic regression C=1,lbfgs,max_iter2000. Fit scaler and meta-model on OOF training predictions. No hyperparameter or threshold search.',
        'primary_models': ['FPD_stack', 'P3_stack', 'P3_mean', 'FPD_concat', 'P_single'],
        'additional_controls': ['FPD_mean', 'P_calibrated'],
        'control': 'FPD_stack and P3_stack both use three full-training LightGBM base models plus the same meta learner. P_calibrated isolates single-branch recalibration.',
        'evaluation': 'Freeze and save all five-seed predictions before scoring official test. AUROC/AP/MCC threshold0.5; mean and sample SD across outer seeds. Validation not used for selection.',
        'source_sha256': {str(p.relative_to(ROOT)): sha(p) for p in sources}}
    write(RUN / 'protocol.json', protocol)
    (RUN / 'protocol.sha256').write_text(sha(RUN / 'protocol.json') + '\n')
    print('Frozen', sha(RUN / 'protocol.json'), flush=True)


def verify():
    assert sha(RUN / 'protocol.json') == (RUN / 'protocol.sha256').read_text().strip()
    p = json.loads((RUN / 'protocol.json').read_text())
    for name, h in p['source_sha256'].items():
        assert sha(ROOT / name) == h, name


def train_seed(seed):
    verify()
    members, y, idx, sets = load_data()
    tr = idx['training']
    folds = np.load(RUN / 'folds.npz')
    np.testing.assert_array_equal(tr, folds['training_rows'])
    fold = folds['fold']
    base = np.load(BASE, mmap_mode='r')
    folder = RUN / f'seed_{seed}'
    folder.mkdir(exist_ok=True)
    if (folder / 'seal.json').exists():
        for name, h in json.loads((folder / 'seal.json').read_text())['files'].items():
            assert sha(folder / name) == h
        print('Verified completed seed', seed, flush=True)
        return
    oof, held = {}, {}
    for branch, (family, offset) in BRANCHES.items():
        actual_seed = seed + offset
        X = base[np.ix_(tr, sets[family])]
        oof[branch] = np.full(len(tr), np.nan)
        for k in range(5):
            path = folder / f'{branch}_fold{k}.npz'
            hold = np.flatnonzero(fold == k)
            fit = np.flatnonzero(fold != k)
            if not path.exists():
                write(RUN / 'current_fit.json', {'seed': seed, 'branch': branch, 'fold': k,
                      'fit_rows': len(fit), 'hold_rows': len(hold), 'updated_utc': now()})
                print('Fit OOF', seed, branch, k, flush=True)
                model = lgb.train(params(actual_seed), lgb.Dataset(X[fit], label=y[tr[fit]]), num_boost_round=900)
                p = model.predict(X[hold])
                assert np.isfinite(p).all()
                temp = path.with_suffix('.partial.npz')
                np.savez_compressed(temp, training_rows=tr[hold], probability=p)
                temp.replace(path)
                del model
                gc.collect()
            saved = np.load(path)
            np.testing.assert_array_equal(saved['training_rows'], tr[hold])
            oof[branch][hold] = saved['probability']
        assert np.isfinite(oof[branch]).all()
        if offset == 0:
            saved = np.load(OLD / f'official/lgb_{family}/seed_{seed}_predictions.npz')
            held[branch] = {}
            for group in ['valid', 'test']:
                np.testing.assert_array_equal(saved[group + '_rows'], idx[group])
                held[branch][group] = saved[group].copy()
        else:
            path = folder / f'{branch}_full.npz'
            if not path.exists():
                write(RUN / 'current_fit.json', {'seed': seed, 'branch': branch, 'fold': 'full-training', 'updated_utc': now()})
                print('Fit full', seed, branch, flush=True)
                model = lgb.train(params(actual_seed), lgb.Dataset(X, label=y[tr]), num_boost_round=900)
                model.save_model(str(folder / f'{branch}_full.lgb'))
                predictions = {g: model.predict(base[np.ix_(idx[g], sets[family])]) for g in ['valid', 'test']}
                np.testing.assert_allclose(lgb.Booster(model_file=str(folder / f'{branch}_full.lgb')).predict(base[np.ix_(idx['test'][:20], sets[family])]), predictions['test'][:20], atol=1e-12)
                temp = path.with_suffix('.partial.npz')
                np.savez_compressed(temp, **predictions)
                temp.replace(path)
                del model
            saved = np.load(path)
            held[branch] = {g: saved[g].copy() for g in ['valid', 'test']}
        del X
        gc.collect()
    np.savez_compressed(folder / 'oof.npz', training_rows=tr, **oof)
    predictions, meta_info = {}, {}
    for name, branches in [('FPD_stack', ['F', 'P', 'D']), ('P3_stack', ['P', 'P2', 'P3']), ('P_calibrated', ['P'])]:
        z = logits(np.column_stack([oof[b] for b in branches]))
        meta = meta_model(seed).fit(z, y[tr])
        assert int(meta.steps[-1][1].n_iter_.max()) < 2000
        joblib.dump(meta, folder / f'{name}.joblib')
        for group in ['valid', 'test']:
            zz = logits(np.column_stack([held[b][group] for b in branches]))
            predictions[name + '_' + group] = meta.predict_proba(zz)[:, 1]
        meta_info[name] = {'branches': branches, 'scaled_logit_coefficients': meta.steps[-1][1].coef_.tolist(),
                           'intercept': meta.steps[-1][1].intercept_.tolist(), 'oof_rows': len(tr)}
    concat = np.load(OLD / f'official/lgb_FPD/seed_{seed}_predictions.npz')
    for group in ['valid', 'test']:
        predictions['FPD_mean_' + group] = np.mean([held[b][group] for b in ['F', 'P', 'D']], axis=0)
        predictions['P3_mean_' + group] = np.mean([held[b][group] for b in ['P', 'P2', 'P3']], axis=0)
        predictions['P_single_' + group] = held['P'][group]
        predictions['FPD_concat_' + group] = concat[group]
        predictions[group + '_rows'] = idx[group]
    np.savez_compressed(folder / 'predictions.npz', **predictions)
    write(folder / 'meta.json', meta_info)
    write(folder / 'seal.json', {'seed': seed, 'completed_utc': now(), 'test_scored': False,
        'files': {p.name: sha(p) for p in folder.iterdir() if p.is_file() and p.name != 'seal.json'}})
    print('Sealed seed', seed, flush=True)


def score(y, p):
    assert np.isfinite(p).all() and ((p >= 0) & (p <= 1)).all()
    return {'AUROC': float(roc_auc_score(y, p)), 'AP': float(average_precision_score(y, p)),
            'MCC': float(matthews_corrcoef(y, p >= .5))}


def report():
    verify()
    for s in SEEDS:
        seal = json.loads((RUN / f'seed_{s}/seal.json').read_text())
        for name, h in seal['files'].items():
            assert sha(RUN / f'seed_{s}' / name) == h
    members, _, idx, _ = load_data()
    raw = pd.read_csv(ROOT / 'data/raw/SA_FG_fragments.csv')
    np.testing.assert_array_equal(members.COMPOUND_ID, raw.COMPOUND_ID)
    models = ['P_single', 'FPD_concat', 'FPD_mean', 'FPD_stack', 'P3_mean', 'P3_stack', 'P_calibrated']
    summary, records = [], []
    for group in ['valid', 'test']:
        yy = raw.TARGET.to_numpy()[idx[group]]
        for name in models:
            ps = []
            values = []
            for seed in SEEDS:
                saved = np.load(RUN / f'seed_{seed}/predictions.npz')
                np.testing.assert_array_equal(saved[group + '_rows'], idx[group])
                p = saved[name + '_' + group]
                ps.append(p)
                v = score(yy, p)
                values.append(v)
                records.append(dict(group=group, model=name, seed=seed, **v))
            row = dict(group=group, model=name, n_seeds=5)
            for metric in ['AUROC', 'AP', 'MCC']:
                row[metric] = float(np.mean([v[metric] for v in values]))
                row[metric + '_sd'] = float(np.std([v[metric] for v in values], ddof=1))
            summary.append(row)
            frame = raw.iloc[idx[group]][['COMPOUND_ID', 'TARGET']].copy()
            for seed, p in zip(SEEDS, ps):
                frame[f'seed_{seed}'] = p
            frame.to_csv(RUN / f'{name}_{group}_predictions.csv', index=False)
    pd.DataFrame(summary).to_csv(RUN / 'comparison.csv', index=False)
    write(RUN / 'results.json', {'completed_utc': now(), 'summary': summary, 'per_seed': records})
    lines = ['官方测试划分：五种子均值±样本SD；MCC阈值0.5。', '融合器仅用训练集折外预测拟合。', '']
    for r in summary:
        if r['group'] == 'test':
            lines.append(r['model'] + ' | ' + ' | '.join(f"{m} {r[m]:.4f} ± {r[m + '_sd']:.4f}" for m in ['AUROC', 'AP', 'MCC']))
    (RUN / '结果速览.txt').write_text('\n'.join(lines) + '\n')
    print('\n'.join(lines), flush=True)


def queue():
    verify()
    lock = (RUN / 'queue.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    status = {'state': 'running', 'pid': os.getpid(), 'started_utc': now(), 'completed_seeds': [], 'planned_seeds': SEEDS}
    env = dict(os.environ, OMP_NUM_THREADS='4', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
    for seed in SEEDS:
        with (RUN / f'seed_{seed}.log').open('a') as log:
            child = subprocess.Popen([sys.executable, '-u', __file__, 'train', '--seed', str(seed)], stdout=log, stderr=subprocess.STDOUT, env=env)
            status.update(current_seed=seed, child_pid=child.pid, updated_utc=now())
            write(RUN / 'status.json', status)
            code = child.wait()
        if code:
            status.update(state='failed', exit_code=code, updated_utc=now())
            write(RUN / 'status.json', status)
            raise RuntimeError(f'Seed {seed} failed; see log')
        status['completed_seeds'].append(seed)
    status.update(state='scoring', updated_utc=now())
    write(RUN / 'status.json', status)
    try:
        report()
    except Exception:
        status.update(state='scoring_failed', updated_utc=now())
        write(RUN / 'status.json', status)
        raise
    status.update(state='complete', current_seed=None, updated_utc=now())
    write(RUN / 'status.json', status)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['smoke', 'freeze', 'train', 'queue', 'report'])
    parser.add_argument('--seed', type=int, choices=SEEDS)
    args = parser.parse_args()
    if args.action == 'train':
        train_seed(args.seed)
    else:
        globals()[args.action]()
