"""Compute features, fit the predeclared models, seal predictions, then evaluate."""
import hashlib
import importlib.util
import importlib.metadata
import json
import os
import time
import traceback
from pathlib import Path

import joblib
import lightgbm as lgb
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.ensemble import RandomForestRegressor

from prepare import RUN, now, save, sha


def read(name):
    return json.loads((RUN/name).read_text())


def verify_prepared(protocol):
    for name, digest in protocol['prepared_hashes'].items():
        assert sha(RUN/name) == digest, name
    check = read('independent_data_verification.json')
    assert check['passed'] and check['membership_sha256'] == sha(RUN/'membership.csv')


def features(df):
    save('status.json', {'state':'featurizing','utc':now(),'pid':os.getpid(),'planned_models':18,'completed_models':0})
    names = read('feature_names.json')
    spec = importlib.util.spec_from_file_location('mic_feature_helper', RUN/'feature_helper_frozen.py')
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    start = time.monotonic()
    # Threads avoid repeatedly importing the full scientific stack into child workers.
    vectors = joblib.Parallel(n_jobs=4, prefer='threads', batch_size=32)(
        joblib.delayed(helper.one_feature)(s,names['fragment_names'],names['descriptor_names']) for s in df.canonical)
    x = np.stack(vectors)
    assert x.shape == (len(df),6519) and not np.isinf(x).any()
    assert np.isfinite(x[:,85:6396]).all()
    np.save(RUN/'features.npy',x)
    save('feature_metadata.json', {'shape':list(x.shape),'sha256':sha(RUN/'features.npy'),
        'membership_sha256':sha(RUN/'membership.csv'),'helper_sha256':sha(RUN/'feature_helper_frozen.py'),
        'F_columns':[0,85],'P_columns':[85,6396],'D_columns':[6396,6519],
        'NaN_count':int(np.isnan(x).sum()),'seconds':time.monotonic()-start,
        'missing_handling':'Nonfinite descriptor values are NaN; LightGBM native missing handling. RF sees only finite fingerprints.',
        'versions':{p:importlib.metadata.version(p) for p in ['numpy','pandas','scikit-learn','rdkit','lightgbm','joblib']}})
    print('Features complete', x.shape, flush=True)
    return x


def train(protocol,df,x):
    tr = np.flatnonzero(df.split.eq('training'))
    (RUN/'models').mkdir()
    (RUN/'predictions').mkdir()
    records=[]
    for model in protocol['models']:
        cols = slice(85,6396) if model.endswith('_P') else slice(None)
        for species in ['ec','pa']:
            y = df[species+'_log2_mic'].to_numpy()[tr]
            for seed in protocol['seeds']:
                key = f'{model}_{species}_{seed}'
                save('status.json', {'state':'training','active_model':key,'completed_models':len(records),
                    'planned_models':18,'utc':now(),'pid':os.getpid()})
                start = time.monotonic()
                print('START', key, 'train_rows',len(tr), flush=True)
                if model == 'rf_P':
                    fitted = RandomForestRegressor(**protocol['rf'],random_state=seed)
                    fitted.fit(x[tr,cols],y)
                    p = fitted.predict(x[:,cols])
                    path = RUN/'models'/f'{key}.joblib'
                    joblib.dump(fitted,path,compress=3)
                    loaded = joblib.load(path)
                else:
                    params = dict(protocol['lgb'], seed=seed, bagging_seed=seed,
                                  feature_fraction_seed=seed,data_random_seed=seed)
                    data = lgb.Dataset(x[tr,cols],label=y,free_raw_data=True)
                    fitted = lgb.train(params,data,num_boost_round=protocol['num_boost_round'])
                    p = fitted.predict(x[:,cols])
                    path = RUN/'models'/f'{key}.txt'
                    fitted.save_model(str(path))
                    loaded = lgb.Booster(model_file=str(path))
                assert np.isfinite(p).all()
                np.testing.assert_allclose(loaded.predict(x[:,cols]),p,rtol=0,atol=1e-10)
                pred_path = RUN/'predictions'/f'{key}.npy'
                np.save(pred_path,p)
                rec={'key':key,'model':model,'species':species,'seed':seed,'train_rows':len(tr),
                     'seconds':time.monotonic()-start,'model_file':str(path.relative_to(RUN)),
                     'model_sha256':sha(path),'prediction_sha256':sha(pred_path)}
                records.append(rec)
                save('training_progress.json',{'utc':now(),'completed':records})
                print('DONE',key,round(rec['seconds'],2),'seconds',flush=True)
    assert len(records)==18
    save('prediction_seal.json',{'utc':now(),'records':records,'membership_sha256':sha(RUN/'membership.csv'),
        'protocol_sha256':sha(RUN/'protocol.json'),'feature_sha256':sha(RUN/'features.npy')})
    save('status.json',{'state':'predictions_sealed','completed_models':18,'planned_models':18,'utc':now(),'pid':os.getpid()})


def metrics(y,p):
    diff=p-y
    ss=float(np.sum((y-y.mean())**2))
    rho=float(spearmanr(y,p).statistic) if np.ptp(y)>0 and np.ptp(p)>0 else None
    return {'n':len(y),'MAE':float(np.abs(diff).mean()),'RMSE':float(np.sqrt(np.mean(diff**2))),
            'R2':1-float(np.sum(diff**2))/ss if ss>0 else None,
            'Spearman':rho,'within_1_log2':float((np.abs(diff)<=1).mean())}


def score(protocol,df):
    seal=read('prediction_seal.json')
    assert len(seal['records'])==18
    for rec in seal['records']:
        assert sha(RUN/'predictions'/f'{rec["key"]}.npy')==rec['prediction_sha256']
        assert sha(RUN/rec['model_file'])==rec['model_sha256']
    truth={sp:df[sp+'_log2_mic'].to_numpy() for sp in ['ec','pa']}
    truth['delta']=truth['pa']-truth['ec']
    records=[]
    ensembles={}
    for model in protocol['models']+['training_mean']:
        outputs={}
        for species in ['ec','pa']:
            if model=='training_mean':
                outputs[species]=np.full((1,len(df)),truth[species][df.split.eq('training')].mean())
            else:
                outputs[species]=np.stack([np.load(RUN/'predictions'/f'{model}_{species}_{s}.npy') for s in protocol['seeds']])
        seed_list=protocol['seeds']+['ensemble'] if model!='training_mean' else ['constant']
        for k,seed in enumerate(seed_list):
            p={sp:v.mean(axis=0) if seed=='ensemble' else v[k] for sp,v in outputs.items()}
            p['delta']=p['pa']-p['ec']
            if seed in ['ensemble','constant']:
                ensembles[model]=p
                pred=df[['row','canonical','split','boundary_group','ec_log2_mic','pa_log2_mic','delta_log2_pa_minus_ec']].copy()
                for sp in p:pred[sp+'_predicted_log2']=p[sp]
                pred.to_csv(RUN/f'{model}_predictions.csv',index=False)
            for split in ['validation','test']:
                idx=np.flatnonzero(df.split.eq(split))
                for endpoint in ['ec','pa','delta']:
                    m=metrics(truth[endpoint][idx],p[endpoint][idx])
                    if endpoint=='delta':
                        mask=np.abs(truth['delta'][idx])>=2
                        m['observed_at_least_4fold_n']=int(mask.sum())
                        product=truth['delta'][idx][mask]*p['delta'][idx][mask]
                        m['preference_direction_accuracy']=float(np.mean((product>0)+.5*(product==0))) if mask.any() else None
                    records.append({'model':model,'seed':seed,'split':split,'endpoint':endpoint,**m})
    save('results.json',{'utc':now(),'units':'log2(ug/mL); delta=PA minus EC','records':records,
        'interpretation':'Exploratory fixed-scaffold-split complete-case regression. Not comparison to original classification paper or prospective validation.'})
    table=pd.DataFrame(records)
    table.to_csv(RUN/'all_metrics.csv',index=False)
    primary=table[table.split.eq('test') & table.seed.isin(protocol['seeds'])]
    summary=primary.groupby(['model','endpoint'])[['MAE','RMSE','R2','Spearman','within_1_log2']].agg(['mean','std'])
    summary.columns=['_'.join(c) for c in summary.columns]
    summary.reset_index().to_csv(RUN/'comparison_test.csv',index=False)
    print('TEST COMPARISON (mean over seeds)',flush=True)
    print(summary[['MAE_mean','RMSE_mean','Spearman_mean']].to_string(),flush=True)
    # Paired scaffold-cluster bootstrap for the same-learner representation comparison.
    te=np.flatnonzero(df.split.eq('test'))
    groups=df.boundary_group.to_numpy()[te]
    unique,inverse=np.unique(groups,return_inverse=True)
    rng=np.random.default_rng(20261108)
    contrast={}
    for endpoint in ['ec','pa','delta']:
        errors={m:np.abs(ensembles[m][endpoint][te]-truth[endpoint][te]) for m in ['lgb_P','lgb_FPD']}
        diff=errors['lgb_FPD']-errors['lgb_P']
        sums=np.bincount(inverse,weights=diff,minlength=len(unique))
        counts=np.bincount(inverse,minlength=len(unique))
        draws=[]
        for _ in range(2000):
            sample=rng.integers(0,len(unique),len(unique))
            draws.append(float(sums[sample].sum()/counts[sample].sum()))
        contrast[endpoint]={'FPD_minus_P_MAE':float(diff.mean()),'ci95':np.quantile(draws,[.025,.975]).tolist()}
    save('bootstrap.json',{'unit':'test Murcko groups','groups':len(unique),'molecules':len(te),'draws':2000,
        'comparison':'3-seed mean predictions, LGB_FPD minus LGB_P, negative favors FPD',
        'interpretation':'Pointwise exploratory intervals, one fixed split, not 3 independent splits','endpoints':contrast})


def verify_results(df):
    records=read('results.json')['records']
    for rec in records:
        idx=np.flatnonzero(df.split.eq(rec['split']))
        ys=df[['ec_log2_mic','pa_log2_mic']].to_numpy()
        if rec['model']=='training_mean':
            pp=np.repeat(ys[df.split.eq('training')].mean(axis=0)[None,:],len(df),axis=0)
        else:
            seeds=[42,7,2024] if rec['seed']=='ensemble' else [rec['seed']]
            pp=np.column_stack([np.mean([np.load(RUN/'predictions'/f'{rec["model"]}_{sp}_{s}.npy') for s in seeds],axis=0) for sp in ['ec','pa']])
        if rec['endpoint']=='delta':
            y,p=ys[idx,1]-ys[idx,0],pp[idx,1]-pp[idx,0]
        else:
            col=['ec','pa'].index(rec['endpoint']);y,p=ys[idx,col],pp[idx,col]
        np.testing.assert_allclose([np.mean(np.abs(p-y)),np.sqrt(np.mean((p-y)**2))],[rec['MAE'],rec['RMSE']],atol=1e-12,rtol=0)
        np.testing.assert_allclose(np.mean(np.abs(p-y)<=1),rec['within_1_log2'],atol=1e-12,rtol=0)
    save('metric_verification.json',{'passed':True,'metric_records_recomputed':len(records),
        'all_saved_models_reloaded_and_full_predictions_compared_during_training':True,'utc':now()})


def main():
    if (RUN/'training_protocol.json').exists():
        raise RuntimeError('Training already started; inspect outputs instead of silently overwriting')
    protocol=read('protocol.json')
    verify_prepared(protocol)
    (RUN/'run_experiment_frozen.py').write_bytes(Path(__file__).read_bytes())
    save('training_protocol.json',{'utc':now(),'pid':os.getpid(),'protocol_sha256':sha(RUN/'protocol.json'),
        'script_sha256':sha(__file__),'membership_sha256':sha(RUN/'membership.csv'),
        'planned_models':18,'fit_partition':'training only','early_stopping':False,'hyperparameter_search':False})
    df=pd.read_csv(RUN/'membership.csv')
    x=features(df)
    train(protocol,df,x)
    verify_prepared(protocol)
    score(protocol,df)
    verify_results(df)
    save('status.json',{'state':'complete','completed_models':18,'planned_models':18,'verified':True,
        'paired_molecules':len(df),'utc':now(),'pid':os.getpid()})
    manifest={str(p.relative_to(RUN)):sha(p) for p in RUN.rglob('*') if p.is_file() and p.name not in ['artifact_manifest.json','train.log','launcher.json']}
    save('artifact_manifest.json',manifest)
    print('COMPLETE: 18 models, predictions sealed, metrics verified.',flush=True)


if __name__=='__main__':
    try:
        main()
    except Exception as exc:
        save('status.json',{'state':'failed','utc':now(),'pid':os.getpid(),'error':str(exc)})
        traceback.print_exc()
        raise
