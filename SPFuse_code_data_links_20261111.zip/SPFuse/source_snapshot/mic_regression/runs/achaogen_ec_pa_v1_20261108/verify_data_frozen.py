"""Recompute split boundaries and MIC targets independently before fitting."""
import hashlib
import json
from itertools import combinations
from pathlib import Path

import numpy as np
import pandas as pd
from rdkit import Chem
from rdkit.Chem import Descriptors
from rdkit.Chem.Scaffolds import MurckoScaffold

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT/'runs/achaogen_ec_pa_v1_20261108'


def main():
    records=pd.read_csv(RUN/'filtered_records.csv.gz')
    df=pd.read_csv(RUN/'membership.csv')
    protocol=json.loads((RUN/'protocol.json').read_text())
    assert df.canonical.is_unique
    assert (records.media=='MHBCa').all() and (records.method=='CLSI').all()
    assert records.additives.isna().all() and (records.solvent=='DMSO').all()
    assert (records.solvent_percent=='< 1.0').all() and (records.reported_as=='Geomean').all()
    assert (records.source=='Achaogen 2019 LpxC contribution').all()
    assert (records[records.species.eq('ec')].strain=='ATCC 25922').all()
    assert (records[records.species.eq('pa')].strain=='ATCC 27853').all()
    source=pd.read_csv(ROOT.parent/'selectivity_pilot/mic_data_survey_20261108/sources/SPARK MIC Data.csv.gz',dtype=str)
    for r in records.itertuples():
        raw=source.iloc[r.source_row]
        assert raw['Compound Name']==r.compound_id and raw['Batch Compound-Batch ID']==r.batch
        assert raw['Curated & Transformed MIC Data: MIC (µg/mL)']==r.mic_raw
        assert Chem.MolToSmiles(Chem.MolFromSmiles(raw.SMILES),isomericSmiles=True)==r.canonical
        numeric=float(r.mic_raw.strip().lstrip('<>=≤≥').strip())
        np.testing.assert_allclose(np.log2(numeric),r.log2_value,rtol=0,atol=1e-12)
    independently_usable={}
    for (smiles,species),g in records.groupby(['canonical','species']):
        if set(g.relation)!={'='}:
            continue
        vals=np.log2(g.mic_ug_ml.to_numpy())
        if np.ptp(vals)>2.1:
            continue
        batch_vals=[np.median(np.log2(bg.mic_ug_ml.to_numpy())) for _,bg in g.groupby('batch')]
        independently_usable[(smiles,species)]=float(np.median(batch_vals))
    paired={s for s,sp in independently_usable if (s,'ec') in independently_usable and (s,'pa') in independently_usable}
    assert paired==set(df.canonical)
    for row in df.itertuples():
        mol=Chem.MolFromSmiles(row.canonical)
        assert len(Chem.GetMolFrags(mol))==1 and Descriptors.MolWt(mol)<=700
        sc=MurckoScaffold.GetScaffoldForMol(mol)
        Chem.RemoveStereochemistry(sc)
        scaffold=Chem.MolToSmiles(sc)
        key='scaffold:'+scaffold if scaffold else 'acyclic:'+Chem.MolToSmiles(mol,isomericSmiles=False)
        assert row.boundary_group==key
        bucket=int(hashlib.sha256(('mic_achaogen_ec_pa_v1|'+key).encode()).hexdigest()[:16],16)/(1<<64)
        expected='training' if bucket<.7 else 'validation' if bucket<.85 else 'test'
        assert row.split==expected
        np.testing.assert_allclose([row.ec_log2_mic,row.pa_log2_mic],
            [independently_usable[(row.canonical,'ec')],independently_usable[(row.canonical,'pa')]],atol=1e-12,rtol=0)
        np.testing.assert_allclose(row.delta_log2_pa_minus_ec,row.pa_log2_mic-row.ec_log2_mic,atol=1e-12,rtol=0)
    overlaps={}
    for s1,s2 in combinations(['training','validation','test'],2):
        a,b=df[df.split==s1],df[df.split==s2]
        ids1=set('|'.join(a.compound_ids).split('|'));ids2=set('|'.join(b.compound_ids).split('|'))
        overlap={'structures':len(set(a.canonical)&set(b.canonical)),
                 'scaffolds':len(set(a.boundary_group)&set(b.boundary_group)),
                 'compound_ids':len(ids1&ids2)}
        assert not any(overlap.values()),overlap
        overlaps[s1+'/'+s2]=overlap
    for name,digest in protocol['prepared_hashes'].items():
        assert hashlib.sha256((RUN/name).read_bytes()).hexdigest()==digest
    result={'passed':True,'source_records_checked':len(records),'paired_targets_recomputed':len(df)*2,
            'all_scaffold_keys_and_splits_recomputed':True,'overlaps':overlaps,
            'membership_sha256':hashlib.sha256((RUN/'membership.csv').read_bytes()).hexdigest()}
    (RUN/'independent_data_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    (RUN/'verify_data_frozen.py').write_bytes(Path(__file__).read_bytes())
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
