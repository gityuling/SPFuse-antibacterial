"""Frozen exploratory models, then common-endpoint and matched-pair evaluation."""
import argparse
import hashlib
import importlib.metadata
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import lightgbm as lgb
import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from rdkit import Chem, RDLogger
from rdkit.Chem import AllChem, Descriptors, MACCSkeys, rdMolDescriptors
from sklearn.metrics import (accuracy_score, average_precision_score, balanced_accuracy_score,
                             f1_score, matthews_corrcoef, roc_auc_score)

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
RUN = ROOT / "runs/feasibility_20261108"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((RUN / name).read_text())


def save(name, obj):
    (RUN / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False)+"\n")


def now():
    return datetime.now(timezone.utc).isoformat()


def one_feature(smiles, fragment_names, desc_names):
    RDLogger.DisableLog("rdApp.warning")
    mol = Chem.MolFromSmiles(smiles)
    funcs = dict(Descriptors._descList)
    values = []
    for name in fragment_names + desc_names:
        try:
            value = float(funcs[name](mol))
        except Exception:
            value = np.nan
        if not np.isfinite(value) or abs(value) > np.finfo(np.float32).max:
            value = np.nan
        values.append(value)
    fps = [AllChem.GetMorganFingerprintAsBitVect(mol, 2, nBits=2048),
           AllChem.GetMorganFingerprintAsBitVect(mol, 3, nBits=2048), MACCSkeys.GenMACCSKeys(mol),
           rdMolDescriptors.GetHashedAtomPairFingerprintAsBitVect(mol, nBits=1024),
           rdMolDescriptors.GetHashedTopologicalTorsionFingerprintAsBitVect(mol, nBits=1024)]
    return np.concatenate([np.asarray(values[:85]), *[np.asarray(fp) for fp in fps], np.asarray(values[85:])]).astype(np.float32)


def features():
    if (RUN / "features.npy").exists():
        raise RuntimeError("Features already exist")
    df = pd.read_csv(RUN / "coadd_membership.csv")
    fragment_names = [c for c in pd.read_csv(PROJECT / "data/raw/SA_FG_fragments.csv", nrows=0).columns if c.startswith("fr_")]
    desc_names = [n for n in json.loads((PROJECT / "optimization/cache/rd_desc_names.json").read_text()) if n not in fragment_names]
    assert len(fragment_names) == 85 and len(desc_names) == 123
    values = Parallel(n_jobs=8, batch_size=64, verbose=5)(delayed(one_feature)(s,fragment_names,desc_names) for s in df.canonical)
    x = np.stack(values)
    assert x.shape == (len(df),6519) and not np.isinf(x).any()
    np.save(RUN / "features.npy",x)
    fp_names = [f"{tag}_{j}" for tag,n in [("morgan2",2048),("morgan3",2048),("maccs",167),("atom_pair",1024),("torsion",1024)] for j in range(n)]
    save("feature_metadata.json",{"names":fragment_names+fp_names+desc_names,"shape":list(x.shape),
                                   "sha256":sha(RUN/"features.npy"),"nan_count":int(np.isnan(x).sum()),
                                   "membership_sha256":sha(RUN/"coadd_membership.csv"),
                                   "versions":{n:importlib.metadata.version(n) for n in ["rdkit","numpy","pandas","lightgbm","scikit-learn"]},
                                   "handling":"Recomputed counts/descriptors; non-finite or float32-overflow values become NaN; native missing-value handling."})
    print("Features ready",x.shape,flush=True)


def check_prepared():
    protocol = read("protocol.json")
    for name, expected in protocol["prepared_hashes"].items():
        assert sha(RUN/name) == expected, name
    assert sha(RUN/"features.npy") == read("feature_metadata.json")["sha256"]
    return protocol


def train():
    if (RUN / "prediction_seal.json").exists():
        raise RuntimeError("Predictions already sealed; do not overwrite")
    protocol = check_prepared()
    df = pd.read_csv(RUN / "coadd_membership.csv")
    x = np.load(RUN / "features.npy")
    tr = np.flatnonzero(df.split.eq("training"))
    te = np.flatnonzero(df.split.eq("test"))
    y_train = {s: np.where(df.split.eq("training"),df[s+"_target"],-1).astype(np.int8) for s in protocol["species"]}
    run_protocol = {"utc":now(),"protocol_sha256":sha(RUN/"protocol.json"),"script_sha256":sha(__file__),
                    "feature_metadata_sha256":sha(RUN/"feature_metadata.json"),
                    "extra_parameters":"seed, bagging_seed, feature_fraction_seed and data_random_seed each set to the stated seed; deterministic=True",
                    "planned_models":12,"scores_observed_before_plan":False}
    if (RUN / "training_protocol.json").exists():
        previous = read("training_protocol.json")
        assert previous["script_sha256"] == run_protocol["script_sha256"]
    else:
        save("training_protocol.json",run_protocol)
    (RUN / "models").mkdir(exist_ok=True)
    (RUN / "predictions").mkdir(exist_ok=True)
    records = []
    for model in protocol["models"]:
        cols = np.arange(85 if model == "lgb_F" else 6519)
        for species in protocol["species"]:
            for seed in protocol["seeds"]:
                key = f"{model}_{species}_{seed}"
                model_path, pred_path = RUN/"models"/(key+".txt"), RUN/"predictions"/(key+".npy")
                if pred_path.exists() or model_path.exists():
                    raise RuntimeError("Partial outputs exist; inspect instead of silently resuming")
                start = time.time()
                params = dict(protocol["lgb"],seed=seed,bagging_seed=seed,feature_fraction_seed=seed,
                              data_random_seed=seed,deterministic=True)
                assert (y_train[species][df.split.ne("training")] == -1).all()
                dataset = lgb.Dataset(x[tr][:,cols],label=y_train[species][tr],free_raw_data=True)
                booster = lgb.train(params,dataset,num_boost_round=protocol["num_boost_round"])
                p = booster.predict(x[:,cols])
                booster.save_model(str(model_path))
                reloaded = lgb.Booster(model_file=str(model_path))
                np.testing.assert_allclose(reloaded.predict(x[te[:32]][:,cols]),p[te[:32]],rtol=0,atol=1e-12)
                np.save(pred_path,p)
                record = {"key":key,"model":model,"species":species,"seed":seed,"seconds":time.time()-start,
                          "model_sha256":sha(model_path),"prediction_sha256":sha(pred_path)}
                records.append(record)
                save("status.json",{"state":"training","completed":len(records),"planned":12,"latest":key,"utc":now()})
                print(json.dumps(record),flush=True)
    save("prediction_seal.json",{"utc":now(),"membership_sha256":sha(RUN/"coadd_membership.csv"),"records":records})
    save("status.json",{"state":"predictions_sealed","models":len(records),"utc":now()})


def species_metrics(y,p):
    pred = p >= .5
    return {"n":len(y),"positive":int(y.sum()),"AUROC":float(roc_auc_score(y,p)) if len(np.unique(y))==2 else None,
            "AP":float(average_precision_score(y,p)),"MCC":float(matthews_corrcoef(y,pred)),
            "F1":float(f1_score(y,pred,zero_division=0))}


def pair_statistics(pairs,sa_p,ec_p):
    i,j = pairs.i.to_numpy(int),pairs.j.to_numpy(int)
    sa_delta,ec_delta = pairs.sa_delta.to_numpy(int),pairs.ec_delta.to_numpy(int)
    sa_diff,ec_diff = sa_p[j]-sa_p[i],ec_p[j]-ec_p[i]
    sa_hard = (sa_p[j]>=.5).astype(int)-(sa_p[i]>=.5).astype(int)
    ec_hard = (ec_p[j]>=.5).astype(int)-(ec_p[i]>=.5).astype(int)
    result = {"n_pairs":len(pairs),"n_molecules":len(set(i)|set(j))}
    for s,actual,diff in [("sa",sa_delta,sa_diff),("ec",ec_delta,ec_diff)]:
        mask = actual != 0
        sign_credit = (actual[mask]*diff[mask]>0).astype(float)+.5*(actual[mask]*diff[mask]==0)
        result[s+"_changed_pairs"] = int(mask.sum())
        result[s+"_change_direction_accuracy"] = float(sign_credit.mean()) if mask.any() else None
    changed = (sa_delta != 0) | (ec_delta != 0)
    predicted_changed = (sa_hard != 0) | (ec_hard != 0)
    exact = (sa_hard == sa_delta) & (ec_hard == ec_delta)
    result["changed_pairs"] = int(changed.sum())
    result["pattern_change_balanced_accuracy"] = float(balanced_accuracy_score(changed,predicted_changed)) if len(np.unique(changed))==2 else None
    result["exact_change_on_changed_pairs"] = float(exact[changed].mean()) if changed.any() else None
    result["exact_change_all_pairs"] = float(exact.mean()) if len(exact) else None
    ec_only_change = (sa_delta==0)&(ec_delta!=0)
    result["sa_constant_ec_changed_pairs"] = int(ec_only_change.sum())
    result["exact_change_sa_constant_ec_changed"] = float(exact[ec_only_change].mean()) if ec_only_change.any() else None
    return result


def score():
    if (RUN / "results.json").exists():
        raise RuntimeError("Results already exist")
    protocol=check_prepared()
    seal=read("prediction_seal.json")
    assert len(seal["records"])==12
    for r in seal["records"]:
        assert sha(RUN/"predictions"/(r["key"]+".npy"))==r["prediction_sha256"]
    df=pd.read_csv(RUN/"coadd_membership.csv")
    amendment=read("chemical_validation_amendment.json")
    assert sha(RUN/"matched_pairs_validated.csv")==amendment["validated_pairs_sha256"]
    pairs=pd.read_csv(RUN/"matched_pairs_validated.csv")
    records=[]
    outputs={}
    per_pair=[]
    for model in protocol["models"]:
        species_predictions={s:np.stack([np.load(RUN/"predictions"/f"{model}_{s}_{seed}.npy") for seed in protocol["seeds"]]) for s in protocol["species"]}
        ensemble={s:arr.mean(axis=0) for s,arr in species_predictions.items()}
        outputs[model]=ensemble
        for split in ["validation","test"]:
            idx=np.flatnonzero(df.split.eq(split)); target=df.pattern.to_numpy()[idx]
            pp=pairs[pairs.split.eq(split)]
            assert df.iloc[pp.i].split.eq(split).all() and df.iloc[pp.j].split.eq(split).all()
            for k,seed in enumerate(protocol["seeds"]+ ["ensemble"]):
                sa_p=ensemble["sa"] if seed=="ensemble" else species_predictions["sa"][k]
                ec_p=ensemble["ec"] if seed=="ensemble" else species_predictions["ec"][k]
                predicted=2*(sa_p[idx]>=.5).astype(int)+(ec_p[idx]>=.5).astype(int)
                records.append({"model":model,"split":split,"seed":seed,
                                "sa":species_metrics(df.sa_target.to_numpy()[idx],sa_p[idx]),
                                "ec":species_metrics(df.ec_target.to_numpy()[idx],ec_p[idx]),
                                "joint":{"pattern_accuracy":float(accuracy_score(target,predicted)),
                                         "macro_F1":float(f1_score(target,predicted,labels=[0,1,2,3],average="macro",zero_division=0)),
                                         "by_pattern_F1":f1_score(target,predicted,labels=[0,1,2,3],average=None,zero_division=0).tolist()},
                                "pairs":pair_statistics(pp,sa_p,ec_p)})
            predframe=df.iloc[idx].copy()
            predframe["sa_probability"]=ensemble["sa"][idx]
            predframe["ec_probability"]=ensemble["ec"][idx]
            predframe.to_csv(RUN/f"{model}_{split}_ensemble.csv",index=False)
    test_pairs=pairs[pairs.split.eq("test")].copy()
    for model,p in outputs.items():
        i,j=test_pairs.i.to_numpy(int),test_pairs.j.to_numpy(int)
        for species in protocol["species"]:
            test_pairs[f"{model}_{species}_probability_delta"]=p[species][j]-p[species][i]
            test_pairs[f"{model}_{species}_predicted_label_delta"]=(p[species][j]>=.5).astype(int)-(p[species][i]>=.5).astype(int)
    test_pairs.to_csv(RUN/"test_pair_predictions.csv",index=False)
    save("results.json",{"records":records,"scored_utc":now(),"interpretation":"Exploratory three-seed fixed-split source-controlled binary-label pilot. No claim of paper reproduction, quantitative MIC selectivity, mechanistic truth, or new wet-lab validation."})
    rows=[]
    for model in protocol["models"]:
        subset=[r for r in records if r["model"]==model and r["split"]=="test" and r["seed"]!="ensemble"]
        for section,metric in [("sa","AUROC"),("sa","AP"),("sa","MCC"),("ec","AUROC"),("ec","AP"),("ec","MCC"),
                               ("joint","macro_F1"),("pairs","sa_change_direction_accuracy"),("pairs","ec_change_direction_accuracy"),
                               ("pairs","exact_change_on_changed_pairs"),("pairs","pattern_change_balanced_accuracy")]:
            vals=[r[section][metric] for r in subset if r[section][metric] is not None]
            rows.append({"model":model,"metric":section+"_"+metric,"mean":float(np.mean(vals)) if vals else None,
                         "sd":float(np.std(vals,ddof=1)) if len(vals)>1 else None})
    pd.DataFrame(rows).to_csv(RUN/"comparison.csv",index=False)
    save("status.json",{"state":"scored","models":12,"utc":now(),"independent_verification_pending":True})
    print(pd.DataFrame(rows).to_string(index=False),flush=True)


if __name__=="__main__":
    ap=argparse.ArgumentParser();ap.add_argument("stage",choices=["features","train","score"])
    stage=ap.parse_args().stage
    globals()[stage]()
