"""Prepare a source/strain/condition-controlled paired MIC regression pilot."""
import gzip
import hashlib
import json
import re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
from rdkit import Chem, RDLogger
from rdkit.Chem import Descriptors
from rdkit.Chem.Scaffolds import MurckoScaffold

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
RUN = ROOT / 'runs/achaogen_ec_pa_v1_20261108'
SOURCE = PROJECT / 'selectivity_pilot/mic_data_survey_20261108/sources/SPARK MIC Data.csv.gz'
EXPECTED_SHA = 'becbfd63a406ba8f8b0530c06979eb820bac42e4cb6fc9163a25f5573b1f1b7e'
Q = 'Curated & Transformed MIC Data: '
SALT = 'mic_achaogen_ec_pa_v1|'
SPREAD_LIMIT = 2.1  # two dilution steps plus 0.1 for rounded reported concentrations
RDLogger.DisableLog('rdApp.warning')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def save(name, data):
    path = RUN / name
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    tmp.replace(path)


def parse_mic(text):
    match = re.fullmatch(r'\s*(<=|>=|<|>|=|≤|≥)?\s*([0-9]+(?:\.[0-9]*)?(?:[Ee][+-]?[0-9]+)?)\s*', str(text))
    if not match:
        raise ValueError(f'Unrecognized MIC: {text!r}')
    value = float(match.group(2))
    if not np.isfinite(value) or value <= 0:
        raise ValueError(f'MIC must be positive and finite: {text!r}')
    return (match.group(1) or '=').replace('≤', '<=').replace('≥', '>='), value


def split_group(smiles):
    mol = Chem.MolFromSmiles(smiles)
    scaffold = MurckoScaffold.MurckoScaffoldSmiles(mol=mol, includeChirality=False)
    return 'scaffold:' + scaffold if scaffold else 'acyclic:' + Chem.MolToSmiles(mol, isomericSmiles=False)


def assign_split(key):
    v = int(hashlib.sha256((SALT + key).encode()).hexdigest()[:16], 16) / 2**64
    return 'training' if v < .7 else 'validation' if v < .85 else 'test'


def aggregate(g):
    exact = g[g.relation.eq('=')]
    result = {'n_records': len(g), 'n_batches': int(g.batch.nunique()),
              'n_exact_records': len(exact), 'relations': '|'.join(sorted(set(g.relation))),
              'compound_ids': '|'.join(sorted(set(g.compound_id))),
              'status': '', 'log2_mic': None, 'exact_range_log2': None}
    if exact.empty:
        result['status'] = 'censored_only'
    elif not g.relation.eq('=').all():
        result['status'] = 'mixed_exact_and_censored'
    else:
        spread = float(g.log2_value.max() - g.log2_value.min())
        result['exact_range_log2'] = spread
        if spread > SPREAD_LIMIT:
            result['status'] = 'discordant_exact_values'
        else:
            # Published entries are geometric summaries, not identifiable raw replicates.
            # Give each compound batch equal weight after median aggregation within batch.
            result['log2_mic'] = float(g.groupby('batch').log2_value.median().median())
            result['status'] = 'exact_usable'
    return result


def main():
    if RUN.exists():
        raise RuntimeError(f'Run already exists; never replace a frozen experiment: {RUN}')
    RUN.mkdir(parents=True)
    save('status.json', {'state': 'preparing', 'utc': now()})
    h = hashlib.sha256()
    with gzip.open(SOURCE, 'rb') as handle:
        for b in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(b)
    assert h.hexdigest() == EXPECTED_SHA
    d = pd.read_csv(SOURCE, dtype=str)
    d['_source_row'] = np.arange(len(d))
    keep = ((d[Q+'Species'].eq('Escherichia coli') & d[Q+'Strain'].eq('ATCC 25922')) |
            (d[Q+'Species'].eq('Pseudomonas aeruginosa') & d[Q+'Strain'].eq('ATCC 27853')))
    funnel = {'full_export_rows': len(d), 'selected_strains_rows': int(keep.sum())}
    filters = [
        ('achaogen_inhibitors', d[Q+'Subset Person'].eq('Achaogen - LpxC, inhibitors')),
        ('test_articles', d[Q+'Test Article Type'].eq('Test article')),
        ('source', d[Q+'Source'].eq('Achaogen 2019 LpxC contribution')),
        ('no_recorded_additives', d[Q+'Additives'].fillna('').str.strip().eq('')),
        ('media_MHBCa', d[Q+'Media'].eq('MHBCa')),
        ('method_CLSI', d[Q+'Method used'].eq('CLSI')),
        ('DMSO_lt_one_percent', d[Q+'Solvent'].eq('DMSO') & d[Q+'Solvent Amt. (%)'].eq('< 1.0')),
        ('visual_endpoint', d[Q+'Threshold of growth inhibition'].eq('Visual')),
        ('wild_type', d[Q+'Accumulation phenotype'].eq('Wild type')),
        ('reported_geomean', d[Q+'MIC/GIC reported as'].eq('Geomean')),
        ('nonempty_MIC', d[Q+'MIC (µg/mL)'].notna()),
    ]
    for name, mask in filters:
        keep &= mask
        funnel[name] = int(keep.sum())
    a = d[keep].copy()
    curated = ['Compound Name', 'SMILES', 'Batch Compound-Batch ID'] + [c for c in d if c.startswith(Q)]
    dup = a.duplicated(curated)
    a.loc[dup, ['_source_row','Compound Name','Batch Compound-Batch ID']].to_csv(RUN/'duplicate_export_rows.csv', index=False)
    a = a[~dup]
    funnel['deduplicated_curated_export_rows'] = len(a)
    rows, excluded, chem = [], [], {}
    for s in a.SMILES.unique():
        mol = Chem.MolFromSmiles(s)
        reason = None
        if mol is None:
            reason = 'invalid_smiles'
        elif len(Chem.GetMolFrags(mol)) != 1:
            reason = 'disconnected_structure'
        elif not any(atom.GetAtomicNum() == 6 for atom in mol.GetAtoms()):
            reason = 'no_carbon'
        elif Descriptors.MolWt(mol) > 700:
            reason = 'MW_gt_700'
        elif any(atom.GetAtomicNum() not in {5,6,7,8,9,14,15,16,17,34,35,53} for atom in mol.GetAtoms()):
            reason = 'outside_organic_element_set'
        chem[s] = (None, None, reason) if reason else (Chem.MolToSmiles(mol, isomericSmiles=True), Descriptors.MolWt(mol), None)
    for _, r in a.iterrows():
        canonical, mw, reason = chem[r.SMILES]
        if reason:
            excluded.append({'source_row': int(r._source_row), 'compound_id': r['Compound Name'], 'reason': reason})
            continue
        relation, value = parse_mic(r[Q+'MIC (µg/mL)'])
        rows.append({'source_row': int(r._source_row), 'compound_id': r['Compound Name'],
                     'batch': r['Batch Compound-Batch ID'], 'canonical': canonical, 'mw': mw,
                     'species': 'ec' if r[Q+'Species'] == 'Escherichia coli' else 'pa',
                     'strain': r[Q+'Strain'], 'mic_raw': r[Q+'MIC (µg/mL)'], 'relation': relation,
                     'mic_ug_ml': value, 'log2_value': float(np.log2(value)), 'source': r[Q+'Source'],
                     'media': r[Q+'Media'], 'method': r[Q+'Method used'], 'additives': '',
                     'solvent': r[Q+'Solvent'], 'solvent_percent': r[Q+'Solvent Amt. (%)'],
                     'reported_as': r[Q+'MIC/GIC reported as']})
    records = pd.DataFrame(rows)
    records.to_csv(RUN/'filtered_records.csv.gz', index=False)
    pd.DataFrame(excluded, columns=['source_row','compound_id','reason']).to_csv(RUN/'excluded_chemistry.csv', index=False)
    endpoint = pd.DataFrame([{'canonical': c, 'species': sp, **aggregate(g)}
                            for (c, sp), g in records.groupby(['canonical','species'], sort=True)])
    endpoint.to_csv(RUN/'aggregated_endpoints.csv', index=False)
    all_mols = records.groupby('canonical', sort=True).agg(mw=('mw','first'), compound_ids=('compound_id', lambda x: '|'.join(sorted(set(x))))).reset_index()
    all_mols['boundary_group'] = all_mols.canonical.map(split_group)
    all_mols['split'] = all_mols.boundary_group.map(assign_split)
    all_mols.to_csv(RUN/'all_compound_membership.csv', index=False)
    pair = all_mols.copy()
    for species in ['ec','pa']:
        v = endpoint[(endpoint.species == species) & (endpoint.status == 'exact_usable')][['canonical','log2_mic','n_batches','n_records','exact_range_log2']]
        v = v.rename(columns={c: species+'_'+c for c in v if c != 'canonical'})
        pair = pair.merge(v, on='canonical', validate='one_to_one')
    pair = pair.sort_values('canonical').reset_index(drop=True)
    pair['row'] = np.arange(len(pair))
    pair['delta_log2_pa_minus_ec'] = pair.pa_log2_mic - pair.ec_log2_mic
    pair.to_csv(RUN/'membership.csv', index=False)
    splits = {s: {'molecules': len(g), 'scaffold_groups': int(g.boundary_group.nunique())} for s,g in pair.groupby('split')}
    assert set(splits) == {'training','validation','test'} and all(v['molecules'] >= 30 for v in splits.values())
    assert pair.canonical.is_unique and pair.groupby('boundary_group').split.nunique().max() == 1
    audit = {'funnel_rows': funnel, 'chemical_exclusions': dict(Counter(r['reason'] for r in excluded)),
             'filtered_records': len(records), 'filtered_structures': int(records.canonical.nunique()),
             'endpoint_statuses': {s: g.status.value_counts().to_dict() for s,g in endpoint.groupby('species')},
             'paired_exact_structures': len(pair), 'split_counts': splits,
             'structure_overlap_between_splits': 0, 'scaffold_group_overlap_between_splits': 0,
             'limitations': ['Published entries are geometric summaries; raw replicate counts unavailable.',
                 'Empty additive field means no recorded additive, not independent confirmation of none.',
                 'Temperature/incubation time not populated in the curated condition field.',
                 'Complete-case exact-MIC cohort excludes censored, mixed and discordant endpoints.',
                 'Single LpxC project; findings do not represent all antibiotic mechanisms.']}
    save('data_audit.json', audit)
    fragments = [c for c in pd.read_csv(PROJECT/'data/raw/SA_FG_fragments.csv', nrows=0).columns if c.startswith('fr_')]
    desc = [n for n in json.loads((PROJECT/'optimization/cache/rd_desc_names.json').read_text()) if n not in fragments]
    assert len(fragments) == 85 and len(desc) == 123
    save('feature_names.json', {'fragment_names': fragments, 'descriptor_names': desc})
    protocol = {
        'created_utc': now(), 'purpose': 'Exploratory fixed-strain paired MIC regression; no official paper regression benchmark is claimed.',
        'source_url': 'https://www.collaborativedrug.com/hubfs/SPARKDataDownload.zip',
        'source_member': 'SPARK MIC Data.csv', 'source_raw_sha256': EXPECTED_SHA,
        'species': {'ec': 'Escherichia coli ATCC 25922', 'pa': 'Pseudomonas aeruginosa ATCC 27853'},
        'cohort': 'Achaogen LpxC test articles, MW<=700, connected organic structures; fixed MHBCa/CLSI/DMSO<1%/visual/wild-type and no recorded additives.',
        'aggregation': 'Remove duplicate full curated export rows. Exclude an endpoint if any censoring or exact spread>2.1 log2. Median log2 within batch, then median across batches. Retain structures with both endpoints.',
        'spread_limit_log2': SPREAD_LIMIT,
        'target': 'log2(MIC / (1 ug/mL)); lower is more potent. Delta=log2(PA MIC / EC MIC); positive means more potent against EC.',
        'split': {'method': 'Nonchiral Murcko scaffold (acyclic fallback nonisomeric full structure), SHA256 first 16 hex digits / 2**64; <.70 train, <.85 validation, otherwise test', 'salt': SALT, 'seed_search': False},
        'seeds': [42,7,2024], 'models': ['rf_P','lgb_P','lgb_FPD'], 'planned_models': 18,
        'features': {'F': '85 RDKit fragment counts', 'P': 'Morgan r2/r3 2048 each, MACCS167, atom-pair1024, torsion1024', 'D': '123 frozen RDKit descriptors; same feature definitions as existing project'},
        'rf': {'n_estimators': 500, 'min_samples_leaf': 2, 'max_features': .33, 'n_jobs': 4, 'bootstrap': True},
        'lgb': {'objective':'regression','learning_rate':.03,'num_leaves':31,'min_data_in_leaf':10,
                'feature_fraction':.25,'bagging_fraction':.8,'bagging_freq':1,'lambda_l2':5,
                'max_bin':63,'num_threads':6,'verbosity':-1,'force_col_wise':True,'deterministic':True},
        'num_boost_round': 900,
        'parameter_provenance': 'Fixed pilot recipe, no search; FPD representation inherited, regression objective and 31 leaves chosen before fitting for smaller cohort. RF is a new local control, not paper-reported RF.',
        'tuning': 'No HPO, no early stopping, no validation refit. All 18 predictions sealed before scoring.',
        'evaluation': ['MAE/RMSE log2 units','R2','Spearman','within one log2 unit','PA-minus-EC delta errors','predefined >=4-fold observed preference direction accuracy'],
        'prepared_hashes': {n: sha(RUN/n) for n in ['membership.csv','filtered_records.csv.gz','aggregated_endpoints.csv','all_compound_membership.csv','data_audit.json','feature_names.json']},
    }
    save('protocol.json', protocol)
    (RUN/'prepare_frozen.py').write_bytes(Path(__file__).read_bytes())
    (RUN/'feature_helper_frozen.py').write_bytes((PROJECT/'selectivity_pilot/scripts/run_pilot.py').read_bytes())
    save('status.json', {'state':'prepared','paired_molecules':len(pair),'split_counts':splits,'planned_models':18,'utc':now()})
    print(json.dumps(audit,ensure_ascii=False,indent=2), flush=True)


if __name__ == '__main__':
    main()
