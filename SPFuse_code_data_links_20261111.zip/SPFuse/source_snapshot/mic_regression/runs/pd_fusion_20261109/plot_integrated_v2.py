from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap,Normalize
from matplotlib.patches import Rectangle
from PIL import Image,ImageChops
from rdkit import Chem
from rdkit.Chem import Draw,rdFMCS
R=Path(__file__).resolve().parent;OLD=R.parent/'achaogen_ec_pa_v1_20261108';OUT=R/'figures_integrated_v2';OUT.mkdir(exist_ok=True)
df=pd.read_csv(R/'comparison.csv').set_index(['endpoint','model']);pairs=pd.read_csv(R/'pd_molecular_pairs.csv');c=json.loads((R/'selected_pair_explanations.json').read_text())[0]
ink='#223b46';blue='#477b99';teal='#207b6b';grey='#607782'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42,'svg.fonttype':'none','text.color':ink,'axes.labelcolor':ink,'xtick.color':grey,'ytick.color':ink,'axes.spines.top':False,'axes.spines.right':False})
fig=plt.figure(figsize=(11.2,8.35),facecolor='white')
# Clear, aligned three-panel grid.
fig.text(.035,.965,'A',fontsize=14,fontweight='bold',va='center');fig.text(.075,.965,'MIC prediction',fontsize=11.5,fontweight='bold',va='center')
fig.text(.54,.965,'B',fontsize=14,fontweight='bold',va='center');fig.text(.58,.965,'Molecular-pair changes',fontsize=11.5,fontweight='bold',va='center')
fig.text(.035,.495,'C',fontsize=14,fontweight='bold',va='center');fig.text(.075,.495,'Interpreting a molecular pair',fontsize=11.5,fontweight='bold',va='center')
# A compact annotated MAE matrix; each entry contains mean and SD from the original table.
models=['RF · P','LightGBM · P','LightGBM · D','LightGBM · FPD','SPFuse'];endpoints=['ec','pa','delta']; keys=['P','P','D','FPD_concat','PD_fusion']; rf={'ec':(1.734,.010),'pa':(1.073,.004),'delta':(1.593,.006)}
means=np.zeros((5,3));sds=means.copy()
for i,key in enumerate(keys):
 for j,ep in enumerate(endpoints):
  means[i,j],sds[i,j]=rf[ep] if i==0 else (df.loc[(ep,key),'MAE_mean'],df.loc[(ep,key),'MAE_std'])
ax=fig.add_axes([.185,.595,.335,.30]);cmap=LinearSegmentedColormap.from_list('soft',['#b7ddd3','#edf6f3','#f7f9f9'])
ax.imshow(means,cmap=cmap,norm=Normalize(vmin=.9,vmax=1.8),aspect='auto')
for i in range(5):
 for j in range(3):
  ax.text(j,i,f'{means[i,j]:.3f}',ha='center',va='center',fontsize=10,fontweight='bold' if i==4 else 'normal',color=teal if i==4 else ink)
  ax.text(j,i+.26,f'± {sds[i,j]:.3f}',ha='center',va='center',fontsize=7,color=grey)
ax.set_xticks(range(3),['E. coli','P. aeruginosa','Δ']);ax.xaxis.tick_top();ax.tick_params(axis='both',length=0,pad=8);ax.set_yticks(range(5),models)
for tick in ax.get_yticklabels():
 if tick.get_text()=='SPFuse':tick.set_fontweight('bold');tick.set_color(teal)
for i in np.arange(-.5,5,1):ax.axhline(i,color='white',lw=2)
for j in np.arange(-.5,3,1):ax.axvline(j,color='white',lw=2)
ax.add_patch(Rectangle((-.5,3.5),3,1,fill=False,edgecolor=teal,lw=1.2));[v.set_visible(False) for v in ax.spines.values()]
fig.text(.185,.555,'MAE (log₂ MIC) · mean ± SD · lower is better',fontsize=8,color=grey)
# B scatter with accuracy summary; pair dependence is stated explicitly.
ax=fig.add_axes([.61,.64,.255,.255]);x=pairs.delta_observed_change.to_numpy();y=pairs.pd_predicted_delta_change.to_numpy();lim=11
ax.scatter(x,y,s=10,c=blue,alpha=.32,edgecolors='none',rasterized=True);ax.plot([-lim,lim],[-lim,lim],color='#9aadb4',ls='--',lw=.8);ax.axvline(0,color='#b6c5c9',lw=.65);ax.axhline(0,color='#b6c5c9',lw=.65)
ax.set_xlim(-lim,lim);ax.set_ylim(-lim,lim);ax.set_xticks([-10,-5,0,5,10]);ax.set_yticks([-10,-5,0,5,10]);ax.tick_params(labelsize=7,length=2);ax.set_xlabel('Observed change in Δ',fontsize=8);ax.set_ylabel('Predicted change in Δ',fontsize=8);ax.grid(color='#e9eff0',lw=.6);ax.set_axisbelow(True)
fig.text(.61,.585,'84.3%',fontsize=13,fontweight='bold',color=teal);fig.text(.695,.588,'|Δ change| ≥ 1   (n = 504)',fontsize=8,color=ink)
fig.text(.61,.548,'90.4%',fontsize=13,fontweight='bold',color=teal);fig.text(.695,.551,'|Δ change| ≥ 2   (n = 364)',fontsize=8,color=ink)
fig.text(.61,.517,'Direction agreement; molecular pairs can share compounds.',fontsize=7.5,color=grey)
# C: two independently cropped structures and the same attribution decomposition.
mem=pd.read_csv(OLD/'membership.csv');mols=[]
for name in (c['first'],c['second']):mols.append(Chem.MolFromSmiles(mem[mem.compound_ids.eq(name)].iloc[0].canonical))
mcs=rdFMCS.FindMCS(mols,ringMatchesRingOnly=True,completeRingsOnly=True,timeout=10);assert not mcs.canceled
q=Chem.MolFromSmarts(mcs.smartsString);matches=[set(m.GetSubstructMatch(q)) for m in mols]
for i,m in enumerate(mols):
 high=[a.GetIdx() for a in m.GetAtoms() if a.GetIdx() not in matches[i]]
 im=Draw.MolToImage(m,size=(600,360),highlightAtoms=high).convert('RGB');bbox=ImageChops.difference(im,Image.new('RGB',im.size,'white')).getbbox();im=im.crop((max(0,bbox[0]-14),max(0,bbox[1]-14),min(im.width,bbox[2]+14),min(im.height,bbox[3]+14)))
 a=fig.add_axes([.055+i*.225,.22,.21,.19]);a.imshow(im);a.axis('off');fig.text(.16+i*.225,.207,[c['first'],c['second']][i],ha='center',fontsize=8,color=ink)
fig.text(.275,.154,'Observed change  −10.06     Predicted  −6.83',ha='center',fontsize=9,fontweight='bold',color=ink)
fig.text(.275,.125,'Highlighted atoms differ from the shared core',ha='center',fontsize=8,color=grey)
ax=fig.add_axes([.67,.145,.28,.27]);top=c['top_features'][:7][::-1]; vals=[t['contribution'] for t in top]; sd=[t['seed_sd'] for t in top]; names=[t['name'].replace('_bit_',' bit ') for t in top];colors=[blue if t['branch']=='P' else teal for t in top]
ax.barh(names,vals,xerr=sd,color=colors,alpha=.9,capsize=2,error_kw={'elinewidth':.8});ax.axvline(0,color='#94a8ac',lw=.8);ax.grid(axis='x',color='#e8eded',lw=.6);ax.set_axisbelow(True);ax.tick_params(labelsize=8,length=0,pad=4);ax.set_xlabel('Contribution to predicted change in Δ',fontsize=8);ax.set_title('Leading feature contributions',loc='left',fontsize=9,pad=7);ax.spines['left'].set_visible(False);ax.spines['bottom'].set_color('#cad5d9')
fig.text(.54,.06,'Fingerprint',fontsize=8,color=blue);fig.text(.64,.06,'Property',fontsize=8,color=teal);fig.text(.735,.06,'Error bars: SD across 3 seeds',fontsize=8,color=grey)
for ext in ('png','pdf','svg'):fig.savefig(OUT/f'spfuse_mic_integrated.{ext}',dpi=300,facecolor='white')
print(OUT)
