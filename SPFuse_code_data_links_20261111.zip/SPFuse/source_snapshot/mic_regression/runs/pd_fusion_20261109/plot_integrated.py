from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import ImageChops, Image
from rdkit import Chem
from rdkit.Chem import Draw,rdFMCS
R=Path(__file__).resolve().parent; OLD=R.parent/'achaogen_ec_pa_v1_20261108'; O=R/'figures_integrated';O.mkdir(exist_ok=True)
df=pd.read_csv(R/'comparison.csv').set_index(['endpoint','model']);pairs=pd.read_csv(R/'pd_molecular_pairs.csv');c=json.loads((R/'selected_pair_explanations.json').read_text())[0]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42,'svg.fonttype':'none','text.color':'#263b48','axes.labelcolor':'#263b48','xtick.color':'#263b48','ytick.color':'#263b48','axes.spines.top':False,'axes.spines.right':False})
fig=plt.figure(figsize=(11.4,12.4),facecolor='white');gs=fig.add_gridspec(3,1,height_ratios=[2.2,2.4,3.1],left=.18,right=.96,top=.95,bottom=.055,hspace=.58)
fig.text(.045,.982,'A',fontsize=15,fontweight='bold',va='top');fig.text(.18,.982,'MIC prediction across models',fontsize=11,fontweight='bold',va='top')
g=gs[0].subgridspec(1,3,wspace=.25);models=['RF P','P','D','FPD_concat','PD_fusion'];labels=['RF · P','LightGBM · P','LightGBM · D','LightGBM · FPD','SPFuse']
rf={'ec':(1.734,.010),'pa':(1.073,.004),'delta':(1.593,.006)}
for j,(ep,title) in enumerate([('ec',r'$\it{E.\ coli}$'),('pa',r'$\it{P.\ aeruginosa}$'),('delta','Species difference')]):
 ax=fig.add_subplot(g[0,j]);
 for i,m in enumerate(models):
  mean,sd=rf[ep] if m=='RF P' else (df.loc[(ep,m),'MAE_mean'],df.loc[(ep,m),'MAE_std'])
  ax.errorbar(mean,i,xerr=sd,fmt='o',color='#208370' if m=='PD_fusion' else '#768694',markersize=5.4,capsize=2,lw=1,zorder=3)
  ax.text(mean+sd+.025,i,f'{mean:.3f}',va='center',fontsize=8,color='#156854' if m=='PD_fusion' else '#455968')
 ax.set_title(title,fontsize=10,pad=10);ax.set_xlim(.85,1.93);ax.set_ylim(4.6,-.6);ax.set_xticks([1,1.4,1.8]);ax.grid(axis='x',color='#e5ebed',lw=.7);ax.set_axisbelow(True)
 ax.tick_params(length=0,labelsize=8);ax.set_yticks(range(5),labels if j==0 else []);ax.spines['left'].set_visible(False);ax.spines['bottom'].set_color('#ccd5da');ax.set_xlabel('MAE (log₂ MIC)',fontsize=8)
fig.text(.045,.713,'B',fontsize=15,fontweight='bold',va='top');fig.text(.18,.713,'Molecular-pair changes in species difference',fontsize=11,fontweight='bold',va='top')
g=gs[1].subgridspec(1,2,width_ratios=[1.15,1],wspace=.4)
ax=fig.add_subplot(g[0]);x=pairs.delta_observed_change.to_numpy();y=pairs.pd_predicted_delta_change.to_numpy();lim=max(np.max(np.abs(x)),np.max(np.abs(y)))+.5
ax.scatter(x,y,s=13,c='#3f8191',alpha=.32,edgecolors='none',rasterized=True);ax.plot([-lim,lim],[-lim,lim],color='#8b9aa2',ls='--',lw=.8);ax.axhline(0,color='#aebbc1',lw=.6);ax.axvline(0,color='#aebbc1',lw=.6)
ax.set_xlim(-lim,lim);ax.set_ylim(-lim,lim);ax.set_xlabel('Observed change in Δ (log₂ MIC)',fontsize=8.5);ax.set_ylabel('Predicted change in Δ',fontsize=8.5);ax.grid(alpha=.12);ax.tick_params(labelsize=8)
ax=fig.add_subplot(g[1]);ax.axis('off');ax.text(0,.93,'Direction agreement',fontsize=10,fontweight='bold',va='top')
for i,(threshold,n,pct) in enumerate([(1,504,84.3),(2,364,90.4)]):
 yy=.71-i*.30;ax.text(0,yy, f'|Observed change| ≥ {threshold}',fontsize=9,va='center');ax.text(.69,yy,f'{pct:.1f}%',fontsize=15,color='#208370',fontweight='bold',va='center');ax.text(0,yy-.12,f'{n} molecular pairs',fontsize=8,color='#667984',va='center')
ax.text(0,.08,'Pairs can share molecules.',fontsize=8,color='#667984')
fig.text(.045,.388,'C',fontsize=15,fontweight='bold',va='top');fig.text(.18,.388,'One structural change and its predicted contribution',fontsize=11,fontweight='bold',va='top')
g=gs[2].subgridspec(1,2,width_ratios=[1.18,1],wspace=.46)
mem=pd.read_csv(OLD/'membership.csv');mols=[]
for name in [c['first'],c['second']]:mols.append(Chem.MolFromSmiles(mem[mem.compound_ids.eq(name)].iloc[0].canonical))
mcs=rdFMCS.FindMCS(mols,ringMatchesRingOnly=True,completeRingsOnly=True,timeout=10);assert not mcs.canceled
q=Chem.MolFromSmarts(mcs.smartsString); matches=[set(m.GetSubstructMatch(q)) for m in mols];high=[[a.GetIdx() for a in m.GetAtoms() if a.GetIdx() not in matches[i]] for i,m in enumerate(mols)]
im=Draw.MolsToGridImage(mols,molsPerRow=2,subImgSize=(600,380),highlightAtomLists=high)
im=im.convert('RGB'); bbox=ImageChops.difference(im,Image.new('RGB', im.size, 'white')).getbbox(); im=im.crop((max(0,bbox[0]-25), max(0,bbox[1]-25), min(im.width,bbox[2]+25), min(im.height,bbox[3]+25)))
ax=fig.add_subplot(g[0]);ax.imshow(im);ax.axis('off');ax.annotate(c['first'],(.25,0),xycoords='axes fraction',xytext=(0,-10),textcoords='offset points',ha='center',fontsize=8);ax.annotate(c['second'],(.75,0),xycoords='axes fraction',xytext=(0,-10),textcoords='offset points',ha='center',fontsize=8)
ax.annotate('Observed Δ change  −10.06    |    Predicted  −6.83',(.5,0),xycoords='axes fraction',xytext=(0,-25),textcoords='offset points',ha='center',fontsize=8.5,fontweight='bold')
ax.annotate('Highlighted atoms differ from the shared core',(.5,0),xycoords='axes fraction',xytext=(0,-38),textcoords='offset points',ha='center',fontsize=8,color='#667984')
ax=fig.add_subplot(g[1]); top=c['top_features'][:8][::-1];names=[t['name'].replace('_bit_',' bit ') for t in top]; vals=[t['contribution'] for t in top];sd=[t['seed_sd'] for t in top];colors=['#346B96' if t['branch']=='P' else '#328474' for t in top]
ax.barh(names,vals,xerr=sd,color=colors,capsize=2,alpha=.86);ax.axvline(0,color='#9baab0',lw=.8);ax.grid(axis='x',alpha=.15);ax.set_axisbelow(True);ax.tick_params(labelsize=8,length=0);ax.set_xlabel('Contribution to predicted Δ change',fontsize=8);ax.set_title('Leading feature contributions',fontsize=9,loc='left',pad=8)
fig.text(.18,.012,'A: mean ± SD across three seeds.  B: ensemble predictions for 613 verified pairs.  C: mean ± SD across three seeds.',fontsize=8,color='#536670')
for ext in ('png','pdf','svg'):fig.savefig(O/f'spfuse_mic_integrated.{ext}',dpi=300,facecolor='white')
print(O)
