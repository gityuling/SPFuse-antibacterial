"""Decompose PD-fusion species-difference changes for predefined molecular pairs."""
from pathlib import Path
import json
import joblib
import lightgbm as lgb
import numpy as np
import pandas as pd

R=Path(__file__).resolve().parent
OLD=R.parent/'achaogen_ec_pa_v1_20261108'
df=pd.read_csv(OLD/'membership.csv');X=np.load(OLD/'features.npy',mmap_mode='r')
schema=json.loads((OLD/'feature_names.json').read_text())
names=[f'{tag}_bit_{k}' for tag,n in [('Morgan_r2',2048),('Morgan_r3',2048),('MACCS',167),('AtomPair',1024),('Torsion',1024)] for k in range(n)]+schema['descriptor_names']
assert len(names)==6434
pairs=[('SPK-0123869','SPK-0125070')]
rows=[]
for first,second in pairs:
    idx=[]
    for name in [first,second]:
        matches=df.index[df.compound_ids.str.split(';').apply(lambda v:name in v)].tolist()
        assert len(matches)==1 and df.loc[matches[0],'split']=='test';idx.append(matches[0])
    seed_details=[]
    for seed in [42,7,2024]:
        sp_results={}
        for sp in ['ec','pa']:
            meta=joblib.load(R/f'fusion_{sp}_{seed}.joblib');scaler,reg=meta.steps[0][1],meta.steps[1][1]
            weight=reg.coef_/scaler.scale_; contrib=[]; residual=[]
            for j,(branch,cols) in enumerate([('P',slice(85,6396)),('D',slice(6396,6519))]):
                path=OLD/f'models/lgb_P_{sp}_{seed}.txt' if branch=='P' else R/f'D_{sp}_{seed}.lgb'
                model=lgb.Booster(model_file=str(path));features=np.asarray(X[idx,cols]);raw=model.predict(features,num_threads=4)
                terms=model.predict(features,pred_contrib=True,num_threads=4)
                contrib.append(weight[j]*(terms[1,:-1]-terms[0,:-1]))
                residual.append(weight[j]*((raw[1]-terms[1].sum())-(raw[0]-terms[0].sum())))
            p=np.load(R/f'predictions_{sp}_{seed}.npz')['PD_fusion']
            actual=float(p[idx[1]]-p[idx[0]])
            recovered=float(sum(x.sum() for x in contrib)+sum(residual))
            assert abs(actual-recovered)<1e-9
            sp_results[sp]={'features':np.concatenate(contrib),'residual':sum(residual),'actual_change':actual,'weights':weight.tolist()}
        delta=sp_results['pa']['features']-sp_results['ec']['features']
        residual=sp_results['pa']['residual']-sp_results['ec']['residual']
        predicted=sp_results['pa']['actual_change']-sp_results['ec']['actual_change']
        np.testing.assert_allclose(delta.sum()+residual,predicted,atol=1e-9)
        seed_details.append({'seed':seed,'delta_features':delta,'residual':residual,'predicted_delta_change':predicted,
                             'ec_weights':sp_results['ec']['weights'],'pa_weights':sp_results['pa']['weights']})
    values=np.stack([x['delta_features'] for x in seed_details]);mean=values.mean(axis=0)
    top=np.argsort(-np.abs(mean))[:12]
    observed=float(df.delta_log2_pa_minus_ec.iloc[idx[1]]-df.delta_log2_pa_minus_ec.iloc[idx[0]])
    rows.append({'first':first,'second':second,'observed_delta_change':observed,
                 'predicted_delta_change_mean':float(np.mean([x['predicted_delta_change'] for x in seed_details])),
                 'P_sum_mean':float(mean[:6311].sum()),'D_sum_mean':float(mean[6311:].sum()),
                 'residual_mean':float(np.mean([x['residual'] for x in seed_details])),
                 'top_features':[{'name':names[k],'branch':'P' if k<6311 else 'D','contribution':float(mean[k]),
                                  'seed_sd':float(values[:,k].std(ddof=1))} for k in top]})
(R/'alternate_pair_explanations.json').write_text(json.dumps(rows,indent=2,allow_nan=False)+'\n')
print(json.dumps(rows,indent=2))
