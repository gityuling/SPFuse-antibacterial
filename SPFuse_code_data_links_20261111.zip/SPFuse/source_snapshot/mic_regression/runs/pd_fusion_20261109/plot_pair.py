from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from rdkit import Chem
from rdkit.Chem import Draw, rdFMCS

R=Path(__file__).resolve().parent
OLD=R.parent/'achaogen_ec_pa_v1_20261108'
case=json.loads((R/'selected_pair_explanations.json').read_text())[0]
df=pd.read_csv(OLD/'membership.csv'); mols=[]
for name in [case['first'],case['second']]:
    row=df[df.compound_ids.eq(name)].iloc[0];mols.append(Chem.MolFromSmiles(row.canonical))
mcs=rdFMCS.FindMCS(mols,ringMatchesRingOnly=True,completeRingsOnly=True,timeout=10)
assert not mcs.canceled
query=Chem.MolFromSmarts(mcs.smartsString)
matches=[set(m.GetSubstructMatch(query)) for m in mols]
assert all(matches)
highlights=[[a.GetIdx() for a in m.GetAtoms() if a.GetIdx() not in matches[i]] for i,m in enumerate(mols)]
im=Draw.MolsToGridImage(mols,molsPerRow=2,subImgSize=(550,320),highlightAtomLists=highlights)
fig=plt.figure(figsize=(11,5.5));gs=fig.add_gridspec(1,2,width_ratios=[1.25,1],wspace=.4)
ax=fig.add_subplot(gs[0]);ax.imshow(im);ax.axis('off')
ax.text(.25,.14,case['first'],transform=ax.transAxes,ha='center',fontsize=9)
ax.text(.75,.14,case['second'],transform=ax.transAxes,ha='center',fontsize=9)
ax.text(.5,-.04,'Colored atoms: structures outside the shared core',transform=ax.transAxes,ha='center',fontsize=9,color='#4a5763')
ax=fig.add_subplot(gs[1]);top=case['top_features'][:8][::-1]
names=[t['name'].replace('_bit_',' bit ') for t in top];vals=[t['contribution'] for t in top];sd=[t['seed_sd'] for t in top]
colors=['#2473a6' if t['branch']=='P' else '#13866c' for t in top]
ax.barh(names,vals,xerr=sd,color=colors,alpha=.88,capsize=2);ax.axvline(0,color='#8795a0',lw=.8)
ax.set_xlabel('Contribution to predicted Δ change (log₂ MIC units)');ax.set_title('Largest feature contributions')
ax.spines[['top','right']].set_visible(False);ax.grid(axis='x',alpha=.2);ax.set_axisbelow(True)
fig.suptitle('SPFuse: a molecular pair with different species activity',x=.055,ha='left',fontweight='bold',fontsize=14)
fig.subplots_adjust(bottom=.24,top=.84)
fig.text(.055,.035,f"Observed Δ change: {case['observed_delta_change']:.2f}; predicted: {case['predicted_delta_change_mean']:.2f}. "
         f"Summed P contribution: {case['P_sum_mean']:.2f}; D contribution: {case['D_sum_mean']:.2f}.",fontsize=9)
for ext in ['png','pdf']:
    fig.savefig(R/f'pd_mic_pair.{ext}',dpi=300,bbox_inches='tight')
