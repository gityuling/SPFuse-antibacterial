from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

r=Path(__file__).resolve().parent
df=pd.read_csv(r/'comparison.csv').set_index(['endpoint','model'])
fig,axs=plt.subplots(1,3,figsize=(11,4.2),sharey=True)
models=['P','D','FPD_concat','PD_fusion']
labels=['Fingerprint (P)','Descriptors (D)','FPD concatenation','SPFuse']
for ax,endpoint,title in zip(axs,['ec','pa','delta'],['E. coli','P. aeruginosa','Species difference']):
    for i,m in enumerate(models):
        d=df.loc[(endpoint,m)]
        ax.errorbar(d.MAE_mean,i,xerr=d.MAE_std,fmt='o',capsize=3,markersize=6,
                    color='#12876c' if m=='PD_fusion' else '#72818d')
        ax.annotate(f'{d.MAE_mean:.3f}',(d.MAE_mean+d.MAE_std,i),xytext=(5,0),textcoords='offset points',va='center',fontsize=9)
    ax.set_title(title,fontstyle='italic' if endpoint!='delta' else 'normal');ax.set_xlim(.85,1.9)
    ax.grid(axis='x',alpha=.2);ax.set_xlabel('MAE (log₂ MIC units)')
    ax.spines[['top','right']].set_visible(False)
axs[0].set_yticks(np.arange(4),labels);axs[0].invert_yaxis()
fig.suptitle('MIC prediction with fingerprint and descriptor fusion',x=.16,ha='left',fontweight='bold')
fig.text(.16,.015,'Points: mean over three seeds; error bars: sample standard deviation. Lower MAE is better.',fontsize=9)
fig.subplots_adjust(left=.19,right=.98,top=.83,bottom=.18,wspace=.15)
for ext in ['png','pdf']:
    fig.savefig(r/f'pd_mic_comparison.{ext}',dpi=300,bbox_inches='tight')
