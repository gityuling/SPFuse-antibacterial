"""Scaffold-grouped OOF fusion for paired species-specific MIC regression."""
from pathlib import Path
import hashlib
import json
import os
import time
import joblib
import lightgbm as lgb
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from scipy.stats import spearmanr

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
OLD = ROOT / 'mic_regression/runs/achaogen_ec_pa_v1_20261108'
SEEDS = [42, 7, 2024]

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for x in iter(lambda:f.read(1048576),b''): h.update(x)
    return h.hexdigest()

def save(path, obj):
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n');tmp.replace(path)

def main():
    assert not (OUT/'protocol.json').exists(), 'Existing run: inspect before restart'
    df=pd.read_csv(OLD/'membership.csv'); X=np.load(OLD/'features.npy',mmap_mode='r')
    config=json.loads((OLD/'protocol.json').read_text())
    tr=np.flatnonzero(df.split.eq('training')); va=np.flatnonzero(df.split.eq('validation')); te=np.flatnonzero(df.split.eq('test'))
    assert (len(tr),len(va),len(te))==(1105,94,174)
    groups=df.boundary_group.to_numpy(); folds=np.full(len(tr),-1)
    for k,(fit,hold) in enumerate(GroupKFold(n_splits=5).split(tr,groups=groups[tr])):
        assert not set(groups[tr[fit]]) & set(groups[tr[hold]])
        folds[hold]=k
    assert (folds>=0).all()
    for a,b in [(tr,va),(tr,te),(va,te)]: assert not set(groups[a]) & set(groups[b])
    np.savez_compressed(OUT/'folds.npz',training_rows=tr,fold=folds)
    files=[Path(__file__),OLD/'protocol.json',OLD/'membership.csv',OLD/'features.npy',OUT/'folds.npz']
    for sp in ['ec','pa']:
        for s in SEEDS:
            files += [OLD/f'predictions/lgb_P_{sp}_{s}.npy',OLD/f'predictions/lgb_FPD_{sp}_{s}.npy']
    save(OUT/'protocol.json',{'purpose':'Independent species-specific PD regression fusion on the prior SPARK fixed scaffold partition.',
        'partitions':{'train':len(tr),'validation':len(va),'test':len(te)},'folds':'GroupKFold 5 on training scaffold groups',
        'branches':'Same fixed LightGBM regression parameters as the previous MIC experiment; separate P and D models.',
        'fusion':'StandardScaler plus Ridge(alpha=1) fitted on scaffold-grouped OOF training predictions, separately per species.',
        'selection':'No validation or test tuning. Test scores after all predictions are sealed.',
        'seeds':SEEDS,'inputs_sha256':{str(p.relative_to(ROOT)):sha(p) for p in files}})
    Xp=np.asarray(X[:,85:6396]); Xd=np.asarray(X[:,6396:6519]); all_pred={}
    for species in ['ec','pa']:
        target=df[species+'_log2_mic'].to_numpy()
        for seed in SEEDS:
            start=time.monotonic(); O=np.full((len(tr),2),np.nan); preds={}
            for j,(name,x) in enumerate([('P',Xp),('D',Xd)]):
                for k in range(5):
                    save(OUT/'status.json',{'state':'training','species':species,'seed':seed,'branch':name,'fold':k,'pid':os.getpid()})
                    fit=tr[folds!=k]; hold=tr[folds==k]
                    assert not set(groups[fit]) & set(groups[hold])
                    params=dict(config['lgb'],seed=seed,bagging_seed=seed,feature_fraction_seed=seed,data_random_seed=seed,num_threads=4)
                    model=lgb.train(params,lgb.Dataset(x[fit],label=target[fit]),num_boost_round=config['num_boost_round'])
                    O[folds==k,j]=model.predict(x[hold],num_threads=4)
                if name=='P':
                    preds[name]=np.load(OLD/f'predictions/lgb_P_{species}_{seed}.npy')
                else:
                    model=lgb.train(params,lgb.Dataset(x[tr],label=target[tr]),num_boost_round=config['num_boost_round'])
                    model.save_model(str(OUT/f'D_{species}_{seed}.lgb'))
                    preds[name]=model.predict(x,num_threads=4)
            assert np.isfinite(O).all()
            meta=make_pipeline(StandardScaler(),Ridge(alpha=1.0)).fit(O,target[tr])
            joblib.dump(meta,OUT/f'fusion_{species}_{seed}.joblib')
            preds['PD_fusion']=meta.predict(np.column_stack([preds['P'],preds['D']]))
            preds['FPD_concat']=np.load(OLD/f'predictions/lgb_FPD_{species}_{seed}.npy')
            np.savez_compressed(OUT/f'predictions_{species}_{seed}.npz',**preds,oof=O)
            all_pred[species,seed]=preds
            print('Completed',species,seed,'seconds',round(time.monotonic()-start,1),flush=True)
    save(OUT/'prediction_seal.json',{'predictions_sha256':{p.name:sha(p) for p in OUT.glob('predictions_*.npz')},'scored':False})
    rows=[]
    for endpoint in ['ec','pa','delta']:
        for model in ['P','D','PD_fusion','FPD_concat']:
            for seed in SEEDS:
                if endpoint=='delta':
                    y=(df.pa_log2_mic-df.ec_log2_mic).to_numpy()[te]
                    p=all_pred['pa',seed][model][te]-all_pred['ec',seed][model][te]
                else:
                    y=df[endpoint+'_log2_mic'].to_numpy()[te];p=all_pred[endpoint,seed][model][te]
                rows.append({'endpoint':endpoint,'model':model,'seed':seed,'MAE':mean_absolute_error(y,p),
                    'RMSE':float(np.sqrt(mean_squared_error(y,p))),'R2':r2_score(y,p),'Spearman':float(spearmanr(y,p).statistic)})
    frame=pd.DataFrame(rows);frame.to_csv(OUT/'per_seed.csv',index=False)
    summary=frame.groupby(['endpoint','model'])[['MAE','RMSE','R2','Spearman']].agg(['mean','std'])
    summary.columns=['_'.join(c) for c in summary.columns];summary.reset_index().to_csv(OUT/'comparison.csv',index=False)
    save(OUT/'status.json',{'state':'complete','pid':os.getpid()})
    print(summary.to_string(),flush=True)

if __name__=='__main__': main()
