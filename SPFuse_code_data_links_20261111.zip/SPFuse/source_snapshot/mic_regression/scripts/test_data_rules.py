"""Protect scientifically meaningful censoring, conflict and batch aggregation rules."""
import unittest
import numpy as np
import pandas as pd
from prepare import aggregate, parse_mic, assign_split, split_group


def frame(relations,values,batches=None):
    return pd.DataFrame({'relation':relations,'log2_value':np.log2(values),
        'batch':batches or [str(i) for i in range(len(values))], 'compound_id':['x']*len(values)})


class Rules(unittest.TestCase):
    def test_inequality_is_preserved(self):
        self.assertEqual(parse_mic('> 64.0'),('>',64.0))
        self.assertEqual(parse_mic('<= 0.125'),('<=',.125))
        self.assertEqual(parse_mic('2.50E+01'),('=',25.0))
        for invalid in ['0','-1','nan','32 ug/ml','1-2','']:
            with self.assertRaises(ValueError):parse_mic(invalid)

    def test_bound_does_not_become_exact(self):
        for relations,status in [(['>','>'],'censored_only'),(['=','>'],'mixed_exact_and_censored')]:
            result=aggregate(frame(relations,[16,32]))
            self.assertEqual(result['status'],status)
            self.assertIsNone(result['log2_mic'])

    def test_conflicts_and_batch_balance(self):
        self.assertEqual(aggregate(frame(['=','='],[1,16]))['status'],'discordant_exact_values')
        result=aggregate(frame(['=']*4,[1,1,2,4],['a','a','a','b']))
        self.assertAlmostEqual(result['log2_mic'],1.)

    def test_stereoisomers_share_boundary(self):
        a=split_group('C[C@H](O)c1ccccc1');b=split_group('C[C@@H](O)c1ccccc1')
        self.assertEqual(a,b)
        self.assertEqual(assign_split(a),assign_split(b))


if __name__=='__main__':unittest.main()
