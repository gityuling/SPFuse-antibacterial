"""Bounded explanation feasibility check on frozen models and held-out molecules.

Native additive feature contributions explain predictions, not biological causes.
MMP prediction agreement is an observational consistency check, not validation
of unique atom-level causal attributions. No fitting, tuning or new data.
"""
from collections import defaultdict
from functools import lru_cache
from itertools import combinations
from pathlib import Path
import hashlib
import json
import time

import lightgbm as lgb
import numpy as np
import pandas as pd
from rdkit import Chem, RDLogger
from rdkit.Chem import rdMMPA

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT/'runs/achaogen_ec_pa_v1_20261108'
OUT = ROOT/'explainability/feasibility_20261108'
SEEDS = [42,7,2024]
RDLogger.DisableLog('rdApp.warning')


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def save(name,value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


@lru_cache(None)
def reconstruct(core,var):
    mol=Chem.molzip(Chem.MolFromSmiles(core+'.'+var))
    Chem.SanitizeMol(mol)
    return Chem.MolToSmiles(mol,isomericSmiles=True)


def pairs(frame):
    cores=defaultdict(set)
    for r in frame.itertuples():
        mol=Chem.MolFromSmiles(r.canonical)
        for _,frags in rdMMPA.FragmentMol(mol,minCuts=1,maxCuts=1,maxCutBonds=100,resultsAsMols=False):
            parts=frags.split('.')
            if len(parts)!=2:continue
            ms=[Chem.MolFromSmiles(s) for s in parts]
            if any(m is None for m in ms):continue
            counts=[sum(a.GetAtomicNum()>0 for a in m.GetAtoms()) for m in ms]
            for k in [0,1]:
                if counts[k]>=8 and counts[k]>=2*mol.GetNumHeavyAtoms()/3 and 1<=counts[1-k]<=8:
                    cores[parts[k]].add((r.row,parts[1-k],counts[k]))
    candidates={}
    for core in sorted(cores):
        for a,b in combinations(sorted(cores[core]),2):
            i,j=a[0],b[0]
            if i==j or a[1]==b[1]:continue
            key=(i,j)
            if key not in candidates or candidates[key]['core_heavy_atoms']<a[2]:
                candidates[key]={'i':i,'j':j,'core':core,'from_fragment':a[1],'to_fragment':b[1],'core_heavy_atoms':a[2]}
    valid,bad=[],[]
    lookup=frame.set_index('row')
    for r in candidates.values():
        try:
            good=(reconstruct(r['core'],r['from_fragment'])==lookup.loc[r['i'],'canonical'] and
                  reconstruct(r['core'],r['to_fragment'])==lookup.loc[r['j'],'canonical'])
        except Exception:
            good=False
        (valid if good else bad).append(r)
    pd.DataFrame(bad).to_csv(OUT/'excluded_stereo_reconstruction.csv',index=False)
    return pd.DataFrame(valid),len(candidates),len(bad)


def main():
    if OUT.exists():raise RuntimeError('Explanation output already exists; inspect instead of replacing')
    OUT.mkdir(parents=True)
    for name,digest in json.loads((RUN/'artifact_manifest.json').read_text()).items():
        assert sha(RUN/name)==digest,name
    frame=pd.read_csv(RUN/'membership.csv')
    test=frame[frame.split.eq('test')].copy()
    idx=test.row.to_numpy(int)
    x=np.load(RUN/'features.npy')[idx]
    spec=json.loads((RUN/'feature_names.json').read_text())
    names=spec['fragment_names']+[f'{tag}_bit_{i}' for tag,n in [('Morgan_r2',2048),('Morgan_r3',2048),('MACCS',167),('AtomPair',1024),('Torsion',1024)] for i in range(n)]+spec['descriptor_names']
    assert len(names)==6519
    family=['fragment']*85+['fingerprint']*6311+['descriptor']*123
    save('protocol.json',{'scope':'Post hoc exploratory explanation of frozen LGB_FPD models on the existing 174 test molecules; no training or selection of new models.',
        'source_run':str(RUN),'membership_sha256':sha(RUN/'membership.csv'),'feature_sha256':sha(RUN/'features.npy'),
        'contributions':'LightGBM native pred_contrib; final column expected value; difference PA minus EC is an additive difference of endpoint explanations.',
        'mmp_rules':'Single cut; common core >=8 heavy atoms and >=2/3 of each molecule; variable fragments 1..8 heavy atoms. Largest core per pair then exact isomeric reconstruction of both molecules. Only both-endpoints-held-out pairs.',
        'mmp_evaluation':'All validated pairs, with descriptive observed-change thresholds 1 and 2 log2 units. Related pairs are not independent observations.',
        'case_selection':'Among |observed delta change|>=1, choose largest absolute observed change within correct-direction and wrong-direction strata; stable row-id tie break. Display both if available.',
        'cautions':['Correlated descriptors distribute attribution; named-feature charts are a subset of the full explanation.',
                    'Hashed fingerprint bits can represent multiple substructures, not unique chemical groups.',
                    'Prediction consistency on MMPs does not establish biological mechanism or causal feature effects.'],
        'documentation':'https://lightgbm.readthedocs.io/en/latest/pythonapi/lightgbm.Booster.html'})
    contributions={}
    diagnostics=[]
    for sp in ['ec','pa']:
        arr=[]
        for seed in SEEDS:
            start=time.monotonic()
            key=f'lgb_FPD_{sp}_{seed}'
            model=lgb.Booster(model_file=str(RUN/'models'/f'{key}.txt'))
            c=model.predict(x,pred_contrib=True,num_threads=4)
            prediction=np.load(RUN/'predictions'/f'{key}.npy')[idx]
            error=float(np.max(np.abs(c.sum(axis=1)-prediction)))
            np.testing.assert_allclose(c.sum(axis=1),prediction,atol=1e-8,rtol=0)
            arr.append(c)
            diagnostics.append({'model':key,'max_additivity_error':error,'seconds':time.monotonic()-start})
            print(key,'contributions verified',round(time.monotonic()-start,2),'s',flush=True)
        contributions[sp]=np.stack(arr)
    contributions['delta']=contributions['pa']-contributions['ec']
    np.savez_compressed(OUT/'test_contributions.npz',rows=idx,**contributions)
    averages={sp:c.mean(axis=0) for sp,c in contributions.items()}
    ranking=[]
    stability={}
    for sp,c in contributions.items():
        global_seed=np.mean(np.abs(c[:,:,:-1]),axis=1)
        global_mean=np.mean(np.abs(averages[sp][:,:-1]),axis=0)
        for i,name in enumerate(names):
            ranking.append({'endpoint':sp,'feature':name,'feature_index':i,'family':family[i],
                'mean_abs_ensemble_contribution':float(global_mean[i]),'seed_mean_importance_sd':float(global_seed[:,i].std(ddof=1))})
        top=[set(np.argsort(-v)[:20]) for v in global_seed]
        stability[sp]={'top20_seed_Jaccard':[len(a&b)/len(a|b) for a,b in combinations(top,2)]}
    ranked=pd.DataFrame(ranking).sort_values(['endpoint','mean_abs_ensemble_contribution'],ascending=[True,False])
    ranked.to_csv(OUT/'feature_rankings.csv',index=False)
    pred=test[['row','canonical','compound_ids','boundary_group','ec_log2_mic','pa_log2_mic','delta_log2_pa_minus_ec']].copy()
    for sp,c in averages.items():pred[sp+'_predicted']=c.sum(axis=1)
    pred.to_csv(OUT/'test_explanation_membership.csv',index=False)
    mmp,candidate_count,rejected_count=pairs(test)
    lookup=pred.set_index('row')
    summary={'test_molecules':len(test),'candidate_pairs':candidate_count,'reconstruction_rejected_pairs':rejected_count,
             'validated_pairs':len(mmp),'paired_molecules':len(set(mmp.i)|set(mmp.j)) if len(mmp) else 0,
             'additivity_checks':diagnostics,'stability':stability,'pair_metrics':{}}
    if len(mmp):
        for sp,truthcol in [('ec','ec_log2_mic'),('pa','pa_log2_mic'),('delta','delta_log2_pa_minus_ec')]:
            mmp[sp+'_observed_change']=lookup.loc[mmp.j,truthcol].to_numpy()-lookup.loc[mmp.i,truthcol].to_numpy()
            mmp[sp+'_predicted_change']=lookup.loc[mmp.j,sp+'_predicted'].to_numpy()-lookup.loc[mmp.i,sp+'_predicted'].to_numpy()
            obs=mmp[sp+'_observed_change'].to_numpy();out=mmp[sp+'_predicted_change'].to_numpy()
            r={'all_pair_change_MAE':float(np.abs(obs-out).mean())}
            for threshold in [1,2]:
                mask=np.abs(obs)>=threshold
                product=obs[mask]*out[mask]
                r[f'abs_change_ge_{threshold}']={'pairs':int(mask.sum()),
                    'direction_accuracy':float(np.mean((product>0)+.5*(product==0))) if mask.any() else None}
            summary['pair_metrics'][sp]=r
        mmp.to_csv(OUT/'test_matched_pairs.csv',index=False)
        local={int(r):i for i,r in enumerate(idx)}
        selected=[]
        candidates=mmp[mmp.delta_observed_change.abs()>=1].copy()
        candidates['abs_observed']=candidates.delta_observed_change.abs()
        candidates['correct_direction']=candidates.delta_observed_change*candidates.delta_predicted_change>0
        for correct in [True,False]:
            g=candidates[candidates.correct_direction==correct].sort_values(['abs_observed','i','j'],ascending=[False,True,True])
            if g.empty:continue
            r=g.iloc[0]
            i,j=int(r.i),int(r.j)
            change=averages['delta'][local[j]]-averages['delta'][local[i]]
            np.testing.assert_allclose(change.sum(),r.delta_predicted_change,atol=1e-8,rtol=0)
            top_indices=np.argsort(-np.abs(change[:-1]))[:10]
            named_indices=[k for k in np.argsort(-np.abs(change[:-1])) if family[k]!='fingerprint'][:10]
            def items(indices):
                return [{'feature':names[k],'family':family[k],'contribution_change':float(change[k])} for k in indices]
            selected.append({'i':i,'j':j,'correct_direction':correct,'core':r.core,'from_fragment':r.from_fragment,'to_fragment':r.to_fragment,
                'observed_delta_change':float(r.delta_observed_change),'predicted_delta_change':float(r.delta_predicted_change),
                'from_compound':lookup.loc[i].to_dict(),'to_compound':lookup.loc[j].to_dict(),
                'top_all_features':items(top_indices),'top_named_features':items(named_indices),
                'baseline_difference':float(change[-1]),'all_feature_changes_sum':float(change[:-1].sum())})
        save('illustrative_cases.json',selected)
    summary['top_named_delta_features']=ranked[(ranked.endpoint=='delta') & ranked.family.ne('fingerprint')].head(10).to_dict('records')
    summary['top_all_delta_features']=ranked[ranked.endpoint=='delta'].head(10).to_dict('records')
    summary['state']='complete'
    save('feasibility_summary.json',summary)
    (OUT/'check_explainability_frozen.py').write_bytes(Path(__file__).read_bytes())
    save('artifact_manifest.json',{p.name:sha(p) for p in OUT.iterdir() if p.is_file() and p.name!='artifact_manifest.json'})
    print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)


if __name__=='__main__':main()
