"""Scientific preview from frozen explanation outputs; no model fitting."""
from pathlib import Path
import hashlib
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from rdkit import Chem
from rdkit.Chem import Draw

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'explainability/feasibility_20261108'
RUN=ROOT/'runs/achaogen_ec_pa_v1_20261108'
cases=json.loads((OUT/'illustrative_cases.json').read_text())
case=next(c for c in cases if c['correct_direction'])
fig=plt.figure(figsize=(12,8.5),constrained_layout=True)
grid=fig.add_gridspec(3,2,height_ratios=[1.25,.50,1.5])
for col,key,label in [(0,'from_compound','A'),(1,'to_compound','B')]:
    z=case[key]
    ax=fig.add_subplot(grid[0,col])
    im=Draw.MolToImage(Chem.MolFromSmiles(z['canonical']),size=(700,330))
    ax.imshow(im);ax.axis('off')
    ax.set_title(f"{label}  |  {z['compound_ids']}",fontsize=12,weight='bold')
    txt=fig.add_subplot(grid[1,col]);txt.axis('off')
    txt.text(.05,.85,f"Observed MIC: EC {2**z['ec_log2_mic']:.3g} / PA {2**z['pa_log2_mic']:.3g} µg/mL",fontsize=11)
    txt.text(.05,.45,f"Predicted MIC: EC {2**z['ec_predicted']:.3g} / PA {2**z['pa_predicted']:.3g} µg/mL",fontsize=11)
    txt.text(.05,.05,f"Observed Δ = {z['delta_log2_pa_minus_ec']:+.2f}; predicted Δ = {z['delta_predicted']:+.2f}",fontsize=11)
ax=fig.add_subplot(grid[2,:])
items=case['top_all_features'][:7]
names=[v['feature'] for v in items]
vals=[v['contribution_change'] for v in items]
names.append('All remaining features')
vals.append(case['all_feature_changes_sum']-sum(vals))
ax.barh(np.arange(len(vals)),vals,color=['#257a9e' if v<0 else '#dc884b' for v in vals])
ax.set_yticks(np.arange(len(vals)),names,fontsize=10)
ax.invert_yaxis();ax.axvline(0,color='#67717c',linewidth=.8)
ax.set_xlabel('Contribution to the predicted change in Δ (B − A), log₂ units',fontsize=11)
ax.set_title(f"Observed change {case['observed_delta_change']:+.2f}; model predicts {case['predicted_delta_change']:+.2f}",loc='left',fontsize=12)
for spine in ['top','right']:ax.spines[spine].set_visible(False)
fig.suptitle('Explaining a predicted change in EC–PA activity preference\nΔ = log₂(MIC_PA / MIC_EC); positive favors EC',fontsize=14,weight='bold')
fig.savefig(OUT/'explanation_preview.png',dpi=160)
fig.savefig(OUT/'explanation_preview.pdf')
plt.close(fig)

# Verify the displayed negative case's representation limitation.
x=np.load(RUN/'features.npy')
negative=next(c for c in cases if not c['correct_direction'])
i,j=negative['i'],negative['j']
smiles=[negative[k]['canonical'] for k in ['from_compound','to_compound']]
connectivity=[Chem.MolToSmiles(Chem.MolFromSmiles(s),isomericSmiles=False) for s in smiles]
check={'negative_case_rows':[i,j], 'distinct_isomeric_structures':smiles[0]!=smiles[1],
       'same_nonstereo_connectivity':connectivity[0]==connectivity[1],
       'identical_6519_features_including_NaN':bool(np.array_equal(x[i],x[j],equal_nan=True)),
       'predicted_delta_change':negative['predicted_delta_change'],
       'observed_delta_change':negative['observed_delta_change']}
assert check['distinct_isomeric_structures'] and check['same_nonstereo_connectivity'] and check['identical_6519_features_including_NaN']
(OUT/'case_verification.json').write_text(json.dumps(check,indent=2)+'\n')
(OUT/'plot_explanation_preview_frozen.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps(check))
