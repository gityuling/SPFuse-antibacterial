"""Run both frozen baselines for all five seeds, persist status and summaries."""
from datetime import datetime, timezone
import fcntl
import json
import os
import subprocess
import sys

import numpy as np
import pandas as pd

from common import ROOT, RUN, digest, metrics, write_json


def now():
    return datetime.now(timezone.utc).isoformat()


def summarize(protocol):
    members, summaries, ensembles = [], [], {}
    for model in protocol['models']:
        predictions = []
        per_model = []
        for seed in protocol['seeds']:
            folder = RUN / model / f'seed_{seed}'
            file = folder / 'metrics.json'
            if not file.exists():
                continue
            result = json.loads(file.read_text())
            row = {'model': model, 'seed': seed, **result['test']}
            members.append(row); per_model.append(row)
            pred = pd.read_csv(folder / 'test_predictions.csv')
            if predictions:
                pd.testing.assert_frame_equal(pred[['COMPOUND_ID', 'TARGET']], predictions[0][['COMPOUND_ID', 'TARGET']])
            predictions.append(pred)
        if per_model:
            frame = pd.DataFrame(per_model)
            summary = {'model': model, 'n_seeds': len(frame), 'complete': len(frame) == len(protocol['seeds'])}
            for metric in ['AUROC', 'AP', 'MCC']:
                summary[metric + '_mean'] = float(frame[metric].mean())
                summary[metric + '_sd'] = float(frame[metric].std(ddof=1)) if len(frame) > 1 else None
            summaries.append(summary)
        if len(predictions) == len(protocol['seeds']):
            out = predictions[0][['COMPOUND_ID', 'PROCESSED_SMILES', 'TARGET', 'group']].copy()
            out['probability'] = np.mean([p.probability.to_numpy() for p in predictions], axis=0)
            out.to_csv(RUN / model / 'ensemble_test_predictions.csv', index=False)
            ensembles[model] = metrics(out.TARGET, out.probability)
    if members:
        pd.DataFrame(members).to_csv(RUN / 'individual_test_results.csv', index=False)
        pd.DataFrame(summaries).to_csv(RUN / 'results_summary.csv', index=False)
    write_json(RUN / 'ensemble_results.json', ensembles)


def main():
    lock = (RUN / 'queue.lock').open('w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    protocol = json.loads((RUN / 'protocol.json').read_text())
    assert digest(RUN / 'protocol.json') == (RUN / 'protocol.sha256').read_text().strip()
    for path, value in {**protocol['source_sha256'], **protocol['upstream_core_sha256']}.items():
        assert digest(ROOT / path) == value, path
    env = {**os.environ, 'OMP_NUM_THREADS': '4', 'OPENBLAS_NUM_THREADS': '1',
           'MKL_NUM_THREADS': '4', 'PYTHONUNBUFFERED': '1'}
    plan = [(seed, model) for seed in protocol['seeds'] for model in protocol['models']]
    failures, finished = [], []
    (RUN / 'queue.pid').write_text(str(os.getpid()) + '\n')
    for seed, model in plan:
        out = RUN / model / f'seed_{seed}'
        out.mkdir(parents=True, exist_ok=True)
        if (out / 'metrics.json').exists():
            finished.append({'model': model, 'seed': seed})
            continue
        script = 'train_chemprop.py' if model == 'wong_dmpnn' else 'train_gneprop.py'
        with (out / 'run.log').open('a') as log:
            process = subprocess.Popen([sys.executable, '-u', str(ROOT / 'scripts' / script), '--seed', str(seed)],
                stdout=log, stderr=subprocess.STDOUT, cwd=ROOT.parent, env=env)
            write_json(RUN / 'status.json', {'status': 'running', 'updated_utc': now(), 'queue_pid': os.getpid(),
                'current': {'model': model, 'seed': seed, 'pid': process.pid}, 'finished': finished,
                'failures': failures, 'planned_fits': len(plan)})
            print(now(), 'started', model, seed, 'PID', process.pid, flush=True)
            code = process.wait()
        if code == 0 and (out / 'metrics.json').exists():
            finished.append({'model': model, 'seed': seed})
        else:
            failures.append({'model': model, 'seed': seed, 'exit_code': code})
        summarize(protocol)
        print(now(), 'finished', model, seed, 'exit', code, flush=True)
    write_json(RUN / 'status.json', {'status': 'complete' if not failures else 'completed_with_failures',
        'updated_utc': now(), 'finished': finished, 'failures': failures, 'planned_fits': len(plan)})


if __name__ == '__main__':
    main()
