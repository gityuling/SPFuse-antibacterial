"""Supervised GNEprop (from scratch) on the frozen official partition.

Uses the authors' GNEpropGIN class, featurization, Adam and Bolts schedule.
The single-GPU runner replaces the legacy distributed Lightning orchestration.
"""
import argparse
import json
import random
import time

import numpy as np
import pandas as pd
import torch
from torch_geometric.loader import DataLoader

from common import ROOT, RUN, digest, metrics, write_json
from gneprop_components import GNEpropGIN, LinearWarmupCosineAnnealingLR, smiles_to_data


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def make_model(config):
    return GNEpropGIN(in_channels=133, edge_dim=12, hidden_channels=config['hidden_size'],
                      ffn_hidden_channels=None, num_layers=config['depth'], out_channels=1,
                      num_readout_layers=config['num_readout_layers'], dropout=config['dropout'],
                      mol_features_size=0, aggr='mean', jk='cat', skip_last_relu=False)


@torch.no_grad()
def predict(model, loader):
    model.eval()
    predictions = []
    for batch in loader:
        batch = batch.to('cuda')
        logits = model(batch.x, batch.edge_index, batch.edge_attr, None, batch.batch)
        predictions.append(torch.sigmoid(logits).cpu().numpy().reshape(-1))
    return np.concatenate(predictions)


def smoke(config, out):
    seed_everything(42)
    model = make_model(config).cuda()
    examples = ['CCO', 'c1ccccc1', 'C[C@H](N)C(=O)O', 'CC(=O)Oc1ccccc1C(=O)O']
    graphs = [smiles_to_data(s, legacy=True) for s in examples]
    for i, g in enumerate(graphs):
        g.y = torch.tensor([float(i % 2)])
    batch = next(iter(DataLoader(graphs, batch_size=4))).to('cuda')
    opt = torch.optim.Adam(model.parameters(), lr=config['lr'])
    model.train()
    losses = []
    for _ in range(3):
        opt.zero_grad(set_to_none=True)
        z = model(batch.x, batch.edge_index, batch.edge_attr, None, batch.batch).reshape(-1)
        loss = torch.nn.functional.binary_cross_entropy_with_logits(z, batch.y)
        assert torch.isfinite(loss)
        loss.backward()
        assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
        opt.step()
        losses.append(float(loss.detach()))
    p = predict(model, DataLoader(graphs, batch_size=4))
    out.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), out / 'roundtrip.pt')
    other = make_model(config).cuda()
    other.load_state_dict(torch.load(out / 'roundtrip.pt', weights_only=True))
    np.testing.assert_allclose(p, predict(other, DataLoader(graphs, batch_size=4)), atol=1e-7)
    # Atom-permutation invariance checks graph representation/edge indexing.
    reverse = []
    for g in graphs:
        gg = g.clone()
        order = torch.arange(gg.num_nodes - 1, -1, -1)
        gg.x = gg.x[order]
        gg.edge_index = order[gg.edge_index]
        reverse.append(gg)
    np.testing.assert_allclose(p, predict(model, DataLoader(reverse, batch_size=4)), atol=1e-6)
    result = {'status': 'passed', 'parameters': sum(p.numel() for p in model.parameters()),
              'finite_forward_backward': True, 'checkpoint_roundtrip': True,
              'atom_permutation_invariance': True, 'smoke_losses': losses,
              'torch': torch.__version__, 'device': torch.cuda.get_device_name()}
    write_json(out / 'checks.json', result)
    print(json.dumps(result), flush=True)


def train(config, seed):
    protocol = json.loads((RUN / 'protocol.json').read_text())
    assert seed in protocol['seeds']
    assert config == protocol['models']['gneprop_scratch']['config']
    for path, value in protocol['data_sha256'].items():
        assert digest(RUN / path) == value, path
    out = RUN / 'gneprop_scratch' / f'seed_{seed}'
    out.mkdir(parents=True, exist_ok=True)
    if (out / 'metrics.json').exists():
        print('Completed output exists; skipping', out, flush=True)
        return
    seed_everything(seed)
    membership = pd.read_csv(RUN / 'data/membership.csv')
    graphs = torch.load(RUN / 'data/gneprop_graphs.pt', weights_only=False, map_location='cpu')
    assert len(graphs) == len(membership)
    rows = {s: np.flatnonzero(membership.group.eq(s)) for s in ['training', 'valid', 'test']}
    loaders = {s: DataLoader([graphs[i] for i in ids], batch_size=config['batch_size'] if s == 'training' else 256,
                            shuffle=s == 'training', drop_last=s == 'training', num_workers=0)
               for s, ids in rows.items()}
    model = make_model(config).cuda()
    optimizer = torch.optim.Adam(model.parameters(), lr=config['lr'], weight_decay=0.)
    scheduler = LinearWarmupCosineAnnealingLR(optimizer, warmup_epochs=5 * len(loaders['training']),
        max_epochs=config['epochs'] * len(loaders['training']), eta_min=config['lr'] / 10)
    started = time.time()
    best_ap, best_epoch, start_epoch = -1., -1, 0
    last = out / 'last.pt'
    history = []
    if last.exists():
        state = torch.load(last, map_location='cpu', weights_only=False)
        model.load_state_dict(state['model'])
        optimizer.load_state_dict(state['optimizer'])
        scheduler.load_state_dict(state['scheduler'])
        best_ap, best_epoch, start_epoch = state['best_ap'], state['best_epoch'], state['epoch'] + 1
        history = state['history']
        random.setstate(state['python_rng']); np.random.set_state(state['numpy_rng'])
        torch.set_rng_state(state['torch_rng']); torch.cuda.set_rng_state(state['cuda_rng'])
    for epoch in range(start_epoch, config['epochs']):
        model.train()
        t = time.time()
        total, count = 0., 0
        for batch in loaders['training']:
            batch = batch.to('cuda')
            optimizer.zero_grad(set_to_none=True)
            logits = model(batch.x, batch.edge_index, batch.edge_attr, None, batch.batch).reshape(-1)
            loss = torch.nn.functional.binary_cross_entropy_with_logits(logits, batch.y)
            if not torch.isfinite(loss):
                raise RuntimeError(f'Nonfinite loss at epoch {epoch}')
            loss.backward()
            optimizer.step()
            scheduler.step()
            total += float(loss.detach()) * batch.num_graphs
            count += batch.num_graphs
        p = predict(model, loaders['valid'])
        scores = metrics(membership.TARGET.iloc[rows['valid']], p)
        if scores['AP'] > best_ap:
            best_ap, best_epoch = scores['AP'], epoch
            torch.save(model.state_dict(), out / 'best.pt')
        row = {'epoch': epoch + 1, 'train_loss': total / count, 'val_AUROC': scores['AUROC'],
               'val_AP': scores['AP'], 'val_MCC': scores['MCC'], 'lr': scheduler.get_last_lr()[0],
               'seconds': time.time() - t, 'best_epoch': best_epoch + 1}
        history.append(row)
        pd.DataFrame(history).to_csv(out / 'history.csv', index=False)
        checkpoint = {'model': model.state_dict(), 'optimizer': optimizer.state_dict(),
                      'scheduler': scheduler.state_dict(), 'epoch': epoch, 'best_ap': best_ap,
                      'best_epoch': best_epoch, 'history': history, 'python_rng': random.getstate(),
                      'numpy_rng': np.random.get_state(), 'torch_rng': torch.get_rng_state(),
                      'cuda_rng': torch.cuda.get_rng_state()}
        torch.save(checkpoint, out / 'last.tmp.pt')
        (out / 'last.tmp.pt').replace(last)
        write_json(out / 'status.json', dict(status='training', seed=seed, **row))
        print(json.dumps(row), flush=True)
    model.load_state_dict(torch.load(out / 'best.pt', weights_only=True, map_location='cpu'))
    result = {'model': 'gneprop_scratch', 'seed': seed, 'best_epoch': best_epoch + 1,
              'selection_metric': 'validation AP', 'training_seconds_this_invocation': time.time() - started,
              'parameters': sum(p.numel() for p in model.parameters()), 'config': config}
    for group in ['valid', 'test']:
        pred = predict(model, loaders[group])
        frame = membership.iloc[rows[group]].copy()
        frame['probability'] = pred
        frame.to_csv(out / f'{group}_predictions.csv', index=False)
        result[group] = metrics(frame.TARGET, pred)
    write_json(out / 'metrics.json', result)
    write_json(out / 'status.json', {'status': 'complete', 'seed': seed, 'best_epoch': best_epoch + 1})
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--smoke', action='store_true')
    args = parser.parse_args()
    torch.set_num_threads(4)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    config = json.loads((ROOT / 'configs/gneprop_scratch.json').read_text())
    if args.smoke:
        smoke(config, RUN / 'smoke/gneprop')
    else:
        train(config, args.seed)
