"""Freeze source, configurations and exact data before scoring study models."""
from datetime import datetime, timezone
import importlib.metadata
import json
import subprocess
import sys

from common import ROOT, RUN, digest, write_json


def main():
    destination = RUN / 'protocol.json'
    if destination.exists():
        raise RuntimeError('Protocol already frozen; create a new run for changes.')
    audit = json.loads((RUN / 'data/audit.json').read_text())
    assert audit['status'] == 'complete'
    for model in ['gneprop', 'chemprop']:
        assert json.loads((RUN / f'smoke/{model}/checks.json').read_text())['status'] == 'passed'
    commits = {name: subprocess.check_output(['git', '-C', str(ROOT / 'upstream' / name),
        'rev-parse', 'HEAD'], text=True).strip() for name in ['chemprop', 'gneprop']}
    assert commits['chemprop'] == '9c8ff4074bd89b93f43a21adc49b458b0cab9e7f'
    protocol = {
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'purpose': 'Published small-molecule antibacterial methods retrained on Onawole released S. aureus partition.',
        'seeds': [42, 7, 2024, 13, 99],
        'split': audit['split_files'], 'training_data': 'Official training rows only; no validation refit or external activity labels.',
        'evaluation': {'metrics': ['AUROC', 'AP', 'MCC'], 'MCC_threshold': .5,
                       'AP_definition': 'sklearn average_precision_score (noninterpolated)',
                       'primary_summary': 'Arithmetic mean and sample standard deviation (ddof=1) of 5 individual models.',
                       'secondary_summary': 'Equal-probability ensemble of all 5 members; kept separate.',
                       'tuning': 'No hyperparameter search on this benchmark. Author configurations fixed before new test scoring.'},
        'models': {
            'wong_dmpnn': {'title': 'Discovery of a structural class of antibiotics with explainable deep learning',
                'doi': '10.1038/s41586-023-06887-8', 'paper_year': 2024,
                'code': 'https://github.com/felixjwong/antibioticsai',
                'trainer': 'https://github.com/chemprop/chemprop',
                'commit': commits['chemprop'], 'config': json.loads((ROOT / 'configs/wong_dmpnn.json').read_text()),
                'features': 'Original directed molecular graph and 200 RDKit2DNormalized descriptors.',
                'initialization': 'Random; no downloaded antibiotic checkpoints.',
                'selection': 'Highest validation AUROC across 30 epochs (original Chemprop default).',
                'author_config_source': 'working_example/hyperparameters.json plus pinned Chemprop TrainArgs defaults.',
                'adaptation': 'Fixed separate train/validation/test CSV files; 5 independent single-member fits instead of the paper final 20-member ensemble. Precomputed normalized descriptors are passed as features_path with no further scaling.'},
            'gneprop_scratch': {'title': 'Deep-learning-based virtual screening of antibacterial compounds',
                'doi': '10.1038/s41587-025-02814-6', 'online_year': 2025,
                'code': 'https://github.com/Genentech/gneprop', 'commit': commits['gneprop'],
                'config': json.loads((ROOT / 'configs/gneprop_scratch.json').read_text()),
                'features': 'Original 133-dimensional atom/12-dimensional bond vectors, legacy=True; no molecule descriptors.',
                'initialization': 'Random; explicitly the author-released supervised scratch variant, not the pretrained/FLAG model.',
                'selection': 'Highest validation AP across 30 epochs.',
                'optimizer': 'Adam, weight_decay=0; per-step original Bolts0.7 linear warmup for 5 epochs, cosine to lr/10.',
                'author_config_source': 'README supervised training (public dataset), without pretrained weights.',
                'adaptation': 'Unchanged upstream GNEpropGIN encoder and featurizer loaded by AST selection; plain single-GPU training runner replaces legacy Lightning/Ray orchestration. Original class weighting disabled; shuffled train batch50 with drop_last=True. All 30 validation epochs eligible for checkpoint selection; eval batch256, workers0.'}
        },
        'runtime_adaptations': [
            'PyTorch2.7.1 CUDA12.8 supports the local RTX5060Ti; original 2022 RDKit retained.',
            'Restore np.float = float within descriptor-generation process for legacy RDKit Ipc.',
            'TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD=1 only in Chemprop process for locally produced legacy checkpoint format.',
            'GNEprop import adapter omits unused Lightning/Ray/DGL dependencies and Bolts warning-only decorator; model bodies and scheduler math unchanged.',
            'No AMP or TF32; fixed seeds, but GPU scatter operations need not be bitwise deterministic.'
        ],
        'data_sha256': {str(p.relative_to(RUN)): digest(p) for p in sorted((RUN / 'data').iterdir()) if p.is_file()},
        'source_sha256': {str(p.relative_to(ROOT)): digest(p) for p in sorted((ROOT / 'scripts').glob('*.py'))},
        'upstream_core_sha256': {str(p.relative_to(ROOT)): digest(p) for p in [
            ROOT / 'upstream/gneprop/models.py', ROOT / 'upstream/gneprop/gneprop/featurization.py',
            ROOT / 'upstream/gneprop/gneprop_pyg.py', ROOT / 'reference/bolts_lr_scheduler.py']}
    }
    packages = ['torch', 'torch-geometric', 'numpy', 'pandas', 'rdkit', 'scikit-learn', 'descriptastorus',
                'typed-argument-parser', 'tensorboardX', 'hyperopt']
    write_json(RUN / 'environment.json', {'python': sys.version, 'packages': {k: importlib.metadata.version(k) for k in packages}})
    write_json(destination, protocol)
    (RUN / 'protocol.sha256').write_text(digest(destination) + '\n')
    print('Frozen', destination, digest(destination))


if __name__ == '__main__':
    main()
