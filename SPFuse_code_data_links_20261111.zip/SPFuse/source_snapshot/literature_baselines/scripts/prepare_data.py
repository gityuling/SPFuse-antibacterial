"""Export exact official membership and cache label-free molecular features."""
import argparse
from concurrent.futures import ProcessPoolExecutor
import multiprocessing as mp

import numpy as np
# RDKit 2022's Ipc calls the retired NumPy alias (identical to builtin float).
# Restore it in this process instead of silently replacing this descriptor by 0.
if 'float' not in np.__dict__:
    np.float = float
import pandas as pd
from rdkit import Chem
import torch

from common import PROJECT, ROOT, RUN, digest, write_json


def descriptors(smiles):
    from descriptastorus.descriptors.rdNormalizedDescriptors import RDKit2DNormalized
    global _generator
    if '_generator' not in globals():
        _generator = RDKit2DNormalized()
    result = _generator.process(smiles)
    assert result is not None and result[0], smiles
    x = np.asarray(result[1:], dtype=np.float32)
    assert len(x) == 200
    # Matches Chemprop's missing-feature replacement.
    return np.where(np.isnan(x), 0., x)


def graph(smiles):
    from gneprop_components import smiles_to_data
    g = smiles_to_data(smiles, legacy=True)
    assert g.x.ndim == 2 and g.x.shape[1] == 133
    if g.edge_attr.numel() == 0:
        g.edge_attr = g.edge_attr.reshape(0, 12)
    assert g.edge_attr.shape[1] == 12
    return g


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--workers', type=int, default=6)
    args = parser.parse_args()
    torch.set_num_threads(1)
    out = RUN / 'data'
    out.mkdir(parents=True, exist_ok=True)
    source = PROJECT / 'data/processed/s_aureus_master.csv'
    membership = PROJECT / 'official_comparison/runs/fixed_20261105/membership.csv'
    d = pd.read_csv(source)
    m = pd.read_csv(membership)
    for col in ['COMPOUND_ID', 'PROCESSED_SMILES', 'group']:
        assert d[col].equals(m[col]), col
    assert d.COMPOUND_ID.is_unique
    assert set(d.TARGET.unique()) == {0, 1}
    assert d.groupby('group').size().to_dict() == {'training': 35006, 'valid': 4378, 'test': 4393}
    canonical = d.PROCESSED_SMILES.map(lambda s: Chem.MolToSmiles(Chem.MolFromSmiles(s), isomericSmiles=True))
    for a, b in [('training', 'valid'), ('training', 'test'), ('valid', 'test')]:
        assert not set(canonical[d.group == a]) & set(canonical[d.group == b])
    d[['COMPOUND_ID', 'PROCESSED_SMILES', 'TARGET', 'group']].to_csv(out / 'membership.csv', index=False)
    audit = {'source_sha256': digest(source), 'official_membership_sha256': digest(membership),
             'same_rows_labels_and_membership': True, 'canonical_overlap_between_splits': 0,
             'inputs': ['PROCESSED_SMILES'], 'target': 'TARGET', 'split_files': {}}
    for group in ['training', 'valid', 'test']:
        part = d.loc[d.group == group]
        file = out / f'{group}.csv'
        part[['PROCESSED_SMILES', 'TARGET']].rename(columns={'PROCESSED_SMILES': 'smiles', 'TARGET': 'activity'}).to_csv(file, index=False)
        audit['split_files'][group] = {'rows': len(part), 'positive': int(part.TARGET.sum()), 'sha256': digest(file)}
    write_json(out / 'audit.json', audit)
    print('Membership verified:', audit['split_files'], flush=True)
    ctx = mp.get_context('spawn')
    if not (out / 'rdkit_normalized.npy').exists():
        with ProcessPoolExecutor(args.workers, mp_context=ctx) as pool:
            features = np.stack(list(pool.map(descriptors, d.PROCESSED_SMILES, chunksize=128)))
        assert features.shape == (len(d), 200) and np.isfinite(features).all()
        np.save(out / 'rdkit_normalized.npy', features)
        print('Computed 200 normalized RDKit features for every molecule.', flush=True)
    features = np.load(out / 'rdkit_normalized.npy')
    for group in ['training', 'valid', 'test']:
        np.savez_compressed(out / f'{group}_features.npz', features=features[d.group == group])
    if not (out / 'gneprop_graphs.pt').exists():
        with ProcessPoolExecutor(args.workers, mp_context=ctx) as pool:
            graphs = list(pool.map(graph, d.PROCESSED_SMILES, chunksize=128))
        for i, g in enumerate(graphs):
            g.y = torch.tensor([float(d.TARGET.iloc[i])])
        torch.save(graphs, out / 'gneprop_graphs.pt')
        print('Cached GNEprop graphs for all molecules.', flush=True)
    audit['cache_sha256'] = {f: digest(out / f) for f in ['membership.csv', 'rdkit_normalized.npy', 'gneprop_graphs.pt']}
    audit['status'] = 'complete'
    write_json(out / 'audit.json', audit)


if __name__ == '__main__':
    main()
