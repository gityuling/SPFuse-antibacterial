"""Load the authors' exact GNEprop encoder/featurizer without unused trainers.

The upstream Lightning trainer imports meta-learning, Ray, Ax, DGL and plotting
packages even for plain supervised training. Only the unchanged GNEpropGIN
class and RDKit/PyG featurization functions are needed here. AST selection
leaves their function/class bodies unchanged; selected code is hash-recorded.
"""
import ast
import importlib.util
import sys

from common import ROOT

UPSTREAM = ROOT / 'upstream/gneprop'


def module_from_file(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def selected_namespace(path, reject_imports=(), class_names=None):
    tree = ast.parse(path.read_text(), filename=str(path))
    nodes = []
    for node in tree.body:
        if isinstance(node, ast.Import):
            if any(alias.name in reject_imports for alias in node.names):
                continue
        if isinstance(node, ast.ImportFrom) and node.module in reject_imports:
            continue
        if isinstance(node, ast.ClassDef) and class_names is not None and node.name not in class_names:
            continue
        nodes.append(node)
    namespace = {'__name__': 'selected_' + path.stem}
    # Bolts' decorator only emits API stability warnings; scheduler math is unchanged.
    namespace['under_review'] = lambda: (lambda cls: cls)
    # Same behavior as dgllife.utils.one_hot_encoding with encode_unknown=False,
    # the only mode called by this featurizer. No learned transforms or labels.
    namespace['one_hot_encoding'] = lambda value, choices: [value == choice for choice in choices]
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), 'exec'), namespace)
    return namespace


module_from_file('chemprop_featurizer', UPSTREAM / 'chemprop_featurizer.py')
_model = selected_namespace(UPSTREAM / 'models.py', ('pytorch_lightning',), {'GNEpropGIN'})
GNEpropGIN = _model['GNEpropGIN']
_features = selected_namespace(UPSTREAM / 'gneprop/featurization.py', ('dgllife', 'dgllife.utils'))
smiles_to_data = _features['smiles_to_data']
LinearWarmupCosineAnnealingLR = selected_namespace(
    ROOT / 'reference/bolts_lr_scheduler.py', ('pl_bolts.utils.stability',),
    {'LinearWarmupCosineAnnealingLR'})['LinearWarmupCosineAnnealingLR']
