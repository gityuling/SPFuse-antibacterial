"""Fixed-partition evaluation utilities for published antibacterial methods."""
import hashlib
import json
from pathlib import Path

import numpy as np
from sklearn.metrics import average_precision_score, matthews_corrcoef, roc_auc_score

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
RUN = ROOT / 'runs/fixed_20261109'


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    tmp.replace(path)


def metrics(y, p):
    y, p = np.asarray(y), np.asarray(p).reshape(-1)
    assert len(y) == len(p) and np.isfinite(p).all()
    assert ((p >= 0) & (p <= 1)).all()
    return dict(AUROC=float(roc_auc_score(y, p)), AP=float(average_precision_score(y, p)),
                MCC=float(matthews_corrcoef(y, p >= .5)))
