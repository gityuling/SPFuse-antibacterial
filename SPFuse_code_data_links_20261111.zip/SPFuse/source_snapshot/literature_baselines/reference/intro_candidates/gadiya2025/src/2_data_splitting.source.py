
# CELL 1
import os
from collections import Counter
import pandas as pd
from tqdm import tqdm
from sklearn.model_selection import train_test_split
from imblearn.over_sampling import SMOTE

# CELL 2
import warnings

warnings.filterwarnings(action="ignore", category=pd.errors.PerformanceWarning)

# CELL 4
fingerprint_df_dict = {}

for fingperint_name in ["ecfp8", "rdkit", "maccs", "mhfp6", "erg", "chem_phys"]:
    fingerprint_df_dict[fingperint_name] = pd.read_csv(
        f"../data/fingerprints/combined_{fingperint_name}.tsv", sep="\t"
    )

len(fingerprint_df_dict)

# CELL 7
SPLITS_DIR = "../data/splits"
os.makedirs(SPLITS_DIR, exist_ok=True)

# CELL 8
def smote_base_sampling(df: pd.DataFrame, name: str, sample_type: str, labels: dict):
    sample_dir = f"{SPLITS_DIR}/{sample_type}"
    os.makedirs(sample_dir, exist_ok=True)

    print(f"Processing {name} dataset")

    # Split the data into training and testing sets
    train, test = train_test_split(
        df,
        test_size=0.2,  # 80% training and 20% testing
        random_state=42,  # to ensure that the split is always the same
        shuffle=True,
        stratify=df[
            "label"
        ],  # to ensure that the distribution of the labels is the same in both splits
    )

    # Saving the orginal splits
    train.to_csv(f"{sample_dir}/{name}_train.csv", index=False)
    test.to_csv(f"{sample_dir}/{name}_test.csv", index=False)

    print("Original dataset shape %s" % Counter(train["label"]))

    # Map the labels to integers (SMOTE only works with integers)
    train["label"] = train["label"].map(labels)

    # Split the training data
    X_train = train.drop(columns=["label", "cmp_id"])
    y_train = train["label"]

    # Apply SMOTE to the training data
    sm = SMOTE(random_state=42)
    smote_sampled_train, smote_sampled_labels = sm.fit_resample(X_train, y_train)

    # Map the labels back to their original values
    smote_sampled_train["label"] = smote_sampled_labels
    smote_sampled_train["label"] = smote_sampled_train["label"].map(
        {v: k for k, v in labels.items()}
    )

    print("SMOTE dataset shape %s" % Counter(smote_sampled_train["label"]))

    # Saving the SMOTE splits
    smote_sampled_train.to_csv(f"{sample_dir}/{name}_smote_train.csv", index=False)
    print("\n")

# CELL 9
for fingerprint_name, df in tqdm(fingerprint_df_dict.items()):
    labels = {
        "gram-negative": 1,
        "gram-positive": 2,
        "acid-fast": 3,
        "fungi": 4,
        "inactive": 5,
    }
    smote_base_sampling(df, fingerprint_name, sample_type="combined", labels=labels)

# CELL 11
for pathogen_class in ["gram-negative", "gram-positive", "acid-fast", "fungi"]:
    for fingerprint_name in tqdm(fingerprint_df_dict):
        pathogen_df = pd.read_csv(
            f"../data/fingerprints/{pathogen_class}_{fingerprint_name}.tsv", sep="\t"
        )

        labels = {
            "active": 1,
            "inactive": 0,
        }

        smote_base_sampling(
            pathogen_df, fingerprint_name, sample_type=pathogen_class, labels=labels
        )

# CELL 12
