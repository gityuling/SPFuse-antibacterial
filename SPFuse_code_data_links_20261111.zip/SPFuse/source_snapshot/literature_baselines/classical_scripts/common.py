"""Independent classical literature baseline run; leaves the GPU queue untouched."""
import hashlib
import json
from pathlib import Path
import numpy as np
from sklearn.metrics import roc_auc_score, average_precision_score, matthews_corrcoef

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'runs/intro_20261109'
SOURCE_DATA = ROOT / 'runs/fixed_20261109/data/membership.csv'
REF = ROOT / 'reference/intro_candidates'
SEEDS = [42, 7, 2024, 13, 99]
MODELS = ['lathem_et', 'lathem_gbt', 'gadiya_mhfp6_rf']
NAMES = {'lathem_et': 'Lathem: property9 + ExtraTrees',
         'lathem_gbt': 'Lathem: property9 + GradientBoosting',
         'gadiya_mhfp6_rf': 'Gadiya: MHFP6 + RF (SMOTE)'}


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    tmp.replace(path)


def metrics(y, p):
    assert len(y) == len(p) and np.isfinite(p).all() and ((p >= 0) & (p <= 1)).all()
    return {'AUROC': float(roc_auc_score(y, p)), 'AP': float(average_precision_score(y, p)),
            'MCC': float(matthews_corrcoef(y, p >= .5))}


def model_for(name, seed):
    from sklearn.ensemble import ExtraTreesClassifier, GradientBoostingClassifier, RandomForestClassifier
    if name == 'lathem_et':
        return ExtraTreesClassifier(random_state=seed, n_jobs=4)
    if name == 'lathem_gbt':
        return GradientBoostingClassifier(random_state=seed)
    if name == 'gadiya_mhfp6_rf':
        params = json.loads((REF / 'gadiya2025/mhfp6_rf_parameters.json').read_text())['parameters']
        return RandomForestClassifier(**dict(params, random_state=seed, n_jobs=4))
    raise ValueError(name)


def verify_protocol():
    p = RUN / 'protocol.json'
    assert digest(p) == (RUN / 'protocol.sha256').read_text().strip(), 'Changed protocol'
    protocol = json.loads(p.read_text())
    for filename, expected in protocol['source_sha256'].items():
        assert digest(ROOT / filename) == expected, filename
    assert digest(SOURCE_DATA) == protocol['membership_sha256']
    assert digest(RUN / 'data/membership.csv') == protocol['membership_sha256']
    return protocol
