"""Freeze, validate, train and aggregate three transferable JCIM model pipelines."""
import argparse
from datetime import datetime, timezone
import fcntl
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback
import joblib
import numpy as np
import pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from common import ROOT, RUN, REF, SOURCE_DATA, SEEDS, MODELS, NAMES, digest, write_json, metrics, model_for, verify_protocol
from features import check_author_features, lathem_row, mhfp_row, prepare


def now():
    return datetime.now(timezone.utc).isoformat()


def smoke():
    df = pd.read_csv(SOURCE_DATA)
    assert len(df) == 43777 and df.COMPOUND_ID.is_unique
    assert df.groupby('group').size().to_dict() == {'test': 4393, 'training': 35006, 'valid': 4378}
    # Training-only smoke: no held-out evaluation used to select implementations.
    sample = pd.concat([df[(df.group == 'training') & (df.TARGET == c)].head(32) for c in [0, 1]])
    smiles = sample.PROCESSED_SMILES.tolist()
    check_author_features(smiles[:5] + smiles[-5:])
    X9 = np.asarray([lathem_row(s) for s in smiles])
    XM = np.asarray([mhfp_row(s) for s in smiles])
    y = sample.TARGET.to_numpy()
    details = []
    for name in MODELS:
        model = model_for(name, 42)
        # Exercise complete configured models on a small training-only sample.
        X = XM if name == 'gadiya_mhfp6_rf' else X9
        if name.startswith('lathem'):
            model = make_pipeline(StandardScaler(), model)
        fit_X, fit_y = X, y
        if name == 'gadiya_mhfp6_rf':
            from imblearn.over_sampling import SMOTE
            selected = np.r_[0:20, 32:64]
            fit_X, fit_y = SMOTE(random_state=42).fit_resample(X[selected], y[selected])
            assert fit_X.dtype == np.int64 and len(fit_y) == 64
            np.testing.assert_array_equal(fit_X[:len(selected)], X[selected])
        model.fit(fit_X, fit_y)
        p = model.predict_proba(X)[:, list(model.classes_).index(1)]
        assert np.isfinite(p).all() and ((p >= 0) & (p <= 1)).all()
        tmp = RUN / 'smoke' / f'{name}.joblib'
        tmp.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(model, tmp)
        np.testing.assert_allclose(joblib.load(tmp).predict_proba(X)[:, 1], p, rtol=0, atol=1e-14)
        details.append({'model': name, 'probability_finite': True, 'reload_max_tolerance': 1e-14})
    write_json(RUN / 'smoke/checks.json', {'status': 'passed', 'rows': len(sample),
        'source': 'Training rows only', 'feature_matches_original_cells': True, 'models': details})
    print('Smoke passed', flush=True)


def freeze():
    assert not (RUN / 'protocol.json').exists(), 'Protocol already frozen'
    assert json.loads((RUN / 'smoke/checks.json').read_text())['status'] == 'passed'
    (RUN / 'data').mkdir(parents=True, exist_ok=True)
    shutil.copyfile(SOURCE_DATA, RUN / 'data/membership.csv')
    paths = list((ROOT / 'classical_scripts').glob('*.py')) + [
        REF / 'gadiya2025/mhfp6_rf_header.bin', REF / 'gadiya2025/mhfp6_rf_parameters.json',
        REF / 'gadiya2025/src/1_fingerprint_generator.ipynb', REF / 'gadiya2025/src/2_data_splitting.ipynb',
        REF / 'gadiya2025/src/6_model_training.ipynb', REF / 'lathem2025/antibiotic_analysis.ipynb']
    p = {'created_utc': now(), 'seeds': SEEDS, 'membership_sha256': digest(SOURCE_DATA),
         'data_source': str(SOURCE_DATA), 'train_rows': 35006, 'valid_rows': 4378, 'test_rows': 4393,
         'training': 'Official training rows only; no validation refit, external labels or pretrained activity weights.',
         'selection': 'No hyperparameter search or threshold tuning; original configurations fixed before scoring.',
         'evaluation': {'metrics': ['AUROC', 'AP', 'MCC'], 'threshold': .5,
                        'summary': 'Five individual models: arithmetic mean and sample SD (ddof=1).',
                        'AP': 'sklearn average_precision_score; distinct from precision.',
                        'ensemble': 'Secondary equal-probability five-member ensemble, reported separately.'},
         'models': {name: {'name': NAMES[name], 'config_at_seed42': model_for(name, 42).get_params()}
                    for name in MODELS},
         'gadiya': {'doi': '10.1021/acs.jcim.4c02347', 'year': 2025,
                    'code': 'https://github.com/IMI-COMBINE/broad_spectrum_prediction',
                    'commit': '3c222f96dfbab8172b4533d6f772f2de3b5350f6',
                    'config_source': 'Static inspection of author Zenodo13868088 mhfp6_rf.pkl; sklearn1.2.2',
                    'features': 'MHFP1.9.6,2048 permutations,encoder seed42,radius3; canonical SMILES; numeric minhash int64.',
                    'sampling': 'SMOTE0.11.0,random_state42,k_neighbors5,auto; only training data. One fixed resample shared across model seeds.',
                    'adaptation': 'Transfer the published MHFP6-RF configuration to S. aureus binary labels and released partition; model seed3544 replaced by five study seeds, CPU jobs4. No original training data or learned weights.'},
         'lathem': {'doi': '10.1021/acs.jcim.5c01321', 'year': 2025,
                    'code': 'https://doi.org/10.6084/m9.figshare.29410085.v2',
                    'features': 'Nine charge/physicochemical features from original cells33,34,95; Max Partial Charge excluded as in classification code. No Mordred or cyanine-specific one-hot encoding.',
                    'config_source': 'Default ExtraTreesClassifier and GradientBoostingClassifier in original cells96 onward.',
                    'adaptation': 'Transfer property-only classifiers to official S. aureus binary labels; train-only StandardScaler instead of fitting before split. Released split replaces 1000 random holdouts; five model seeds replace seed0. No MIC relabeling.'},
         'source_sha256': {str(f.relative_to(ROOT)): digest(f) for f in paths}}
    env = {'python': sys.version, 'packages': {k: importlib.metadata.version(k) for k in
           ['numpy', 'scipy', 'pandas', 'scikit-learn', 'imbalanced-learn', 'mhfp', 'rdkit', 'joblib']}}
    write_json(RUN / 'environment.json', env)
    write_json(RUN / 'protocol.json', p)
    (RUN / 'protocol.sha256').write_text(digest(RUN / 'protocol.json') + '\n')
    print('Protocol frozen', digest(RUN / 'protocol.json'), flush=True)


def fit(name, seed):
    verify_protocol()
    folder = RUN / 'models' / name / f'seed_{seed}'
    folder.mkdir(parents=True, exist_ok=True)
    assert not (folder / 'metrics.json').exists(), 'Completed fit already exists'
    df = pd.read_csv(RUN / 'data/membership.csv')
    train = df.group.eq('training').to_numpy()
    kind = 'mhfp6' if name.startswith('gadiya') else 'lathem9'
    a = json.loads((RUN / f'data/{kind}_audit.json').read_text())
    assert digest(RUN / f'data/{kind}.npy') == a['feature_sha256']
    X = np.load(RUN / f'data/{kind}.npy', mmap_mode='r')
    y = df.TARGET.to_numpy(dtype=int)
    model = model_for(name, seed)
    if name.startswith('lathem'):
        model = make_pipeline(StandardScaler(), model)
        xx, yy = X[train], y[train]
    else:
        for f, h in a['smote_sha256'].items():
            assert digest(RUN / 'data' / f) == h
        xx = np.load(RUN / 'data/mhfp6_smote_X.npy', mmap_mode='r')
        yy = np.load(RUN / 'data/mhfp6_smote_y.npy', mmap_mode='r')
    started = time.time()
    print(f'Fitting {name} seed{seed}: {xx.shape}', flush=True)
    model.fit(xx, yy)
    elapsed = time.time() - started
    if name.startswith('lathem'):
        np.testing.assert_allclose(model.steps[0][1].mean_, np.mean(X[train], axis=0))
    joblib.dump(model, folder / 'model.joblib', compress=3)
    result = {'model': name, 'seed': seed, 'fit_seconds': elapsed, 'completed_utc': now(),
              'training_rows': len(yy), 'protocol_sha256': digest(RUN / 'protocol.json')}
    positive = list(model.classes_).index(1)
    for group in ['valid', 'test']:
        mask = df.group.eq(group).to_numpy()
        p = model.predict_proba(X[mask])[:, positive]
        result[group] = metrics(y[mask], p)
        out = df.loc[mask, ['COMPOUND_ID', 'PROCESSED_SMILES', 'TARGET', 'group']].copy()
        out['probability'] = p
        out.to_csv(folder / f'{group}_predictions.csv', index=False)
    write_json(folder / 'metrics.json', result)
    print(json.dumps(result), flush=True)


def report():
    rows, summary, ensemble = [], [], []
    df = pd.read_csv(RUN / 'data/membership.csv')
    test = df[df.group == 'test']
    for name in MODELS:
        preds = []
        current = []
        for seed in SEEDS:
            folder = RUN / 'models' / name / f'seed_{seed}'
            if not (folder / 'metrics.json').exists():
                continue
            r = json.loads((folder / 'metrics.json').read_text())
            row = dict(model=name, seed=seed, **r['test'])
            rows.append(row)
            current.append(row)
            p = pd.read_csv(folder / 'test_predictions.csv', float_precision='round_trip')
            assert p.COMPOUND_ID.tolist() == test.COMPOUND_ID.tolist()
            assert p.TARGET.tolist() == test.TARGET.tolist()
            checked = metrics(p.TARGET.to_numpy(), p.probability.to_numpy())
            for k in checked:
                assert abs(checked[k] - r['test'][k]) < 1e-12
            preds.append(p.probability.to_numpy())
        if current:
            row = {'model': name, 'name': NAMES[name], 'n_seeds': len(current), 'complete': len(current) == 5}
            for metric in ['AUROC', 'AP', 'MCC']:
                values = [r[metric] for r in current]
                row[metric + '_mean'] = float(np.mean(values))
                row[metric + '_sd'] = float(np.std(values, ddof=1)) if len(values) > 1 else None
            summary.append(row)
        if len(preds) == 5:
            ensemble.append(dict(model=name, **metrics(test.TARGET.to_numpy(), np.mean(preds, axis=0))))
    pd.DataFrame(rows).to_csv(RUN / 'per_seed_metrics.csv', index=False)
    pd.DataFrame(summary).to_csv(RUN / 'comparison.csv', index=False)
    pd.DataFrame(ensemble).to_csv(RUN / 'ensemble_secondary.csv', index=False)
    write_json(RUN / 'results.json', {'updated_utc': now(), 'models': summary, 'secondary_ensemble': ensemble})
    lines = ['新增文献方法：官方 S. aureus 划分', '训练35006；验证4378；测试4393；MCC阈值0.5。',
             '主结果为5个独立随机种子的均值±样本标准差；未满5次标为进行中。', '']
    for r in summary:
        label = '完成' if r['complete'] else '进行中'
        text = f"{r['name']} [{r['n_seeds']}/5,{label}]"
        for k in ['AUROC', 'AP', 'MCC']:
            sd = f" ± {r[k + '_sd']:.4f}" if r[k + '_sd'] is not None else ''
            text += f" | {k} {r[k + '_mean']:.4f}{sd}"
        lines.append(text)
    lines.extend(['', '既有参照：LightGBM FPD，AUROC 0.9235 ± 0.0005；AP 0.9600 ± 0.0004；MCC 0.6606 ± 0.0035。',
                  '以上新增方法均迁移后重新训练；不是原论文报告分数。',
                  'Gadiya2025：10.1021/acs.jcim.4c02347；Lathem2025：10.1021/acs.jcim.5c01321。'])
    (RUN / '结果速览.txt').write_text('\n'.join(lines) + '\n')


def queue():
    verify_protocol()
    lock = (RUN / 'queue.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    status = {'status': 'running', 'queue_pid': os.getpid(), 'started_utc': now(),
              'planned_fits': 15, 'finished': [], 'failures': []}
    (RUN / 'queue.pid').write_text(str(os.getpid()) + '\n')
    env = dict(os.environ, OMP_NUM_THREADS='4', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
               NUMEXPR_NUM_THREADS='1', PYTHONUNBUFFERED='1')
    commands = [('prepare_lathem9', ['prepare', '--kind', 'lathem9'])]
    commands += [(f'{m}_seed{s}', ['fit', '--model', m, '--seed', str(s)]) for s in SEEDS for m in MODELS[:2]]
    commands += [('prepare_mhfp6', ['prepare', '--kind', 'mhfp6'])]
    commands += [(f'gadiya_mhfp6_rf_seed{s}', ['fit', '--model', 'gadiya_mhfp6_rf', '--seed', str(s)]) for s in SEEDS]
    for task, args in commands:
        if args[0] == 'fit':
            folder = RUN / 'models' / args[2] / f'seed_{args[4]}'
            if (folder / 'metrics.json').exists():
                status['finished'].append(task)
                continue
        log = RUN / 'logs' / f'{task}.log'
        log.parent.mkdir(parents=True, exist_ok=True)
        with log.open('a') as stream:
            child = subprocess.Popen([sys.executable, '-u', __file__, *args], stdout=stream, stderr=subprocess.STDOUT, env=env)
            status.update(current={'task': task, 'pid': child.pid}, updated_utc=now())
            write_json(RUN / 'status.json', status)
            code = child.wait()
        if code:
            status['failures'].append({'task': task, 'exit_code': code, 'log': str(log)})
            if args[0] == 'prepare':
                status.update(status='failed', updated_utc=now())
                write_json(RUN / 'status.json', status)
                raise RuntimeError(f'Feature preparation failed: {task}')
        else:
            status['finished'].append(task)
        report()
    status.update(status='complete' if not status['failures'] else 'complete_with_failures',
                  current=None, updated_utc=now())
    write_json(RUN / 'status.json', status)
    report()
    print(json.dumps(status), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['smoke', 'freeze', 'prepare', 'fit', 'queue', 'report'])
    parser.add_argument('--kind', choices=['lathem9', 'mhfp6'])
    parser.add_argument('--model', choices=MODELS)
    parser.add_argument('--seed', type=int, choices=SEEDS)
    args = parser.parse_args()
    RUN.mkdir(parents=True, exist_ok=True)
    if args.action == 'prepare':
        prepare(args.kind)
    elif args.action == 'fit':
        fit(args.model, args.seed)
    else:
        globals()[args.action]()
