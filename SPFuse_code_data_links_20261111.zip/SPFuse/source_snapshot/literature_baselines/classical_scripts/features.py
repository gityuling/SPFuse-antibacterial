"""Author feature definitions, with deterministic generation in official row order."""
import ast
import json
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor
import numpy as np
import pandas as pd
from rdkit import Chem
from rdkit.Chem import Descriptors, Lipinski, rdMolDescriptors
from common import REF, RUN, digest, verify_protocol, write_json

PATTERNS = [Chem.MolFromSmarts(s) for s in [
    '[NH2;X3;!$(NC=O)]', '[NH1;X3;!$(NC=O)]', '[N;H0;X3;!$(NC=O)]',
    '[N+;X4]', '[N;X2;$(NC(N)=N)]', '[N;X2;$(NC=N)]']]
NAMES = ['Mol. Weight', 'LogP', 'TPSA', 'Num. Rotatable Bonds', 'Num. Amide Bonds',
         'Num. H Donors', 'Num. H Acceptors', 'Num. Positive Charge Sites', 'Num. Rings']


def lathem_row(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f'Invalid official SMILES: {smiles}')
    return [Descriptors.MolWt(mol), Descriptors.MolLogP(mol), Descriptors.TPSA(mol),
            rdMolDescriptors.CalcNumRotatableBonds(mol), rdMolDescriptors.CalcNumAmideBonds(mol),
            Lipinski.NumHDonors(mol), Lipinski.NumHAcceptors(mol),
            sum(len(mol.GetSubstructMatches(p)) for p in PATTERNS), rdMolDescriptors.CalcNumRings(mol)]


_encoder = None


def mhfp_row(smiles):
    global _encoder
    from mhfp.encoder import MHFPEncoder
    if _encoder is None:
        _encoder = MHFPEncoder(n_permutations=2048, seed=42)
    # Original source canonicalizes before MHFPEncoder.encode(radius=3).
    return _encoder.encode(Chem.CanonSmiles(smiles), radius=3).astype(np.int64)


def check_author_features(smiles):
    # Execute only the two inspected feature-definition cells, not the analysis notebook.
    nb = json.loads((REF / 'lathem2025/antibiotic_analysis.ipynb').read_text())
    src = '\n'.join(''.join(nb['cells'][i]['source']) for i in [33, 34])
    tree = ast.parse(src)
    assert all(isinstance(n, (ast.Assign, ast.FunctionDef)) for n in tree.body)
    scope = dict(MolFromSmarts=Chem.MolFromSmarts, Descriptors=Descriptors,
                 rdMolDescriptors=rdMolDescriptors, Lipinski=Lipinski, pd=pd)
    exec(compile(tree, '<author Lathem feature cells 33/34>', 'exec'), scope)
    author = scope['get_basic_descriptors'](pd.Series([Chem.MolFromSmiles(s) for s in smiles]))
    expected = author.drop(columns=['Max Partial Charge'])
    assert expected.columns.tolist() == NAMES
    np.testing.assert_allclose(np.array([lathem_row(s) for s in smiles]), expected.to_numpy(), rtol=0, atol=0)
    from mhfp.encoder import MHFPEncoder
    encoder = MHFPEncoder(n_permutations=2048, seed=42)
    for s in smiles:
        np.testing.assert_array_equal(mhfp_row(s), encoder.encode(Chem.CanonSmiles(s), radius=3))


def prepare(kind):
    verify_protocol()
    data = RUN / 'data'
    dest = data / f'{kind}.npy'
    audit_path = data / f'{kind}_audit.json'
    if audit_path.exists():
        a = json.loads(audit_path.read_text())
        assert a['status'] == 'complete' and digest(dest) == a['feature_sha256']
        if kind == 'mhfp6':
            for f, h in a['smote_sha256'].items():
                assert digest(data / f) == h
        print('Verified existing feature cache', kind, flush=True)
        return
    df = pd.read_csv(data / 'membership.csv')
    dim = 9 if kind == 'lathem9' else 2048
    dtype = np.float64 if kind == 'lathem9' else np.int64
    tmp = data / f'{kind}.partial.npy'
    out = np.lib.format.open_memmap(tmp, mode='w+', dtype=dtype, shape=(len(df), dim))
    fn = lathem_row if kind == 'lathem9' else mhfp_row
    with ProcessPoolExecutor(max_workers=4, mp_context=mp.get_context('spawn')) as pool:
        for i, row in enumerate(pool.map(fn, df.PROCESSED_SMILES, chunksize=64)):
            out[i] = row
            if (i + 1) % 2000 == 0:
                print(f'{kind}: {i + 1}/{len(df)}', flush=True)
    assert np.isfinite(out).all()
    out.flush()
    del out
    tmp.replace(dest)
    info = {'status': 'complete', 'shape': [len(df), dim], 'dtype': str(dtype),
            'membership_sha256': digest(data / 'membership.csv'), 'feature_sha256': digest(dest),
            'dropped_rows': 0}
    if kind == 'lathem9':
        info['feature_names'] = NAMES
    else:
        from imblearn.over_sampling import SMOTE
        X = np.load(dest, mmap_mode='r')
        train = df.group.eq('training').to_numpy()
        y = df.TARGET.to_numpy(dtype=int)
        print('Applying fixed SMOTE(seed42) to original training rows only', flush=True)
        sm = SMOTE(random_state=42)
        xx, yy = sm.fit_resample(np.asarray(X[train]), y[train])
        assert np.array_equal(xx[:train.sum()], X[train]) and np.array_equal(yy[:train.sum()], y[train])
        assert xx.dtype == np.int64 and xx.shape == (46960, 2048)
        np.save(data / 'mhfp6_smote_X.npy', xx)
        np.save(data / 'mhfp6_smote_y.npy', yy)
        info['smote'] = {'input_rows': int(train.sum()), 'output_rows': len(yy), 'seed': 42,
                         'counts': {str(c): int((yy == c).sum()) for c in np.unique(yy)},
                         'dtype_policy': 'int64, matching author TSV reload and SMOTE integer casting'}
        info['smote_sha256'] = {f: digest(data / f) for f in ['mhfp6_smote_X.npy', 'mhfp6_smote_y.npy']}
    write_json(audit_path, info)
    print('Features complete', kind, info['shape'], flush=True)
