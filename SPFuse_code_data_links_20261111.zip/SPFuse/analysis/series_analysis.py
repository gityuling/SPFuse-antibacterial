"""Fixed-rule, non-overlapping MMP-core series analysis of held-out MIC data."""
from pathlib import Path
import json,hashlib
import numpy as np,pandas as pd,joblib,lightgbm as lgb
from rdkit import Chem,DataStructs,RDLogger
from rdkit.Chem import AllChem,rdRGroupDecomposition
from scipy.stats import spearmanr
from itertools import combinations
RDLogger.DisableLog('rdApp.warning')
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];R=ROOT/'mic_regression/runs/pd_fusion_20261109';OLD=R.parent/'achaogen_ec_pa_v1_20261108';SEEDS=[42,7,2024]
mem=pd.read_csv(OLD/'membership.csv');mmp=pd.read_csv(R/'pd_molecular_pairs.csv');schema=json.loads((OLD/'feature_names.json').read_text());names=schema['descriptor_names'];assert len(names)==123
candidates=[]
for core,frame in mmp.groupby('core'):
 ids=sorted(set(frame.i)|set(frame.j));assert all(mem.iloc[ids].split.eq('test'))
 if len(ids)<5:continue
 mols=[Chem.MolFromSmiles(mem.iloc[i].canonical) for i in ids];query=Chem.MolFromSmiles(core)
 if query is None or sum(a.GetAtomicNum()==0 for a in query.GetAtoms())!=1:continue
 prm=rdRGroupDecomposition.RGroupDecompositionParameters();prm.substructMatchParams.useChirality=True
 rows,unmatched=rdRGroupDecomposition.RGroupDecompose([query],mols,asSmiles=True,asRows=True,options=prm)
 eligible=[idx for j,idx in enumerate(ids) if j not in unmatched]
 if len(eligible)>=5:candidates.append({'core':core,'core_heavy_atoms':int(frame.core_heavy_atoms.iloc[0]),'ids':eligible,'candidate_count':len(ids),'unmatched':len(unmatched)})
candidates.sort(key=lambda v:(-len(v['ids']),-v['core_heavy_atoms'],v['core']))
seen=set();series=[]
for g in candidates:
 ids=[i for i in g['ids'] if i not in seen]
 if len(ids)<5:continue
 mols=[Chem.MolFromSmiles(mem.iloc[i].canonical) for i in ids];query=Chem.MolFromSmiles(g['core']);params=rdRGroupDecomposition.RGroupDecompositionParameters();params.substructMatchParams.useChirality=True
 rows,unmatched=rdRGroupDecomposition.RGroupDecompose([query],mols,asSmiles=True,asRows=True,options=params);assert not unmatched and len(rows)==len(ids)
 assert all(set(x.keys())=={'Core','R1'} for x in rows)
 fps=[AllChem.GetMorganFingerprintAsBitVect(m,2,nBits=2048) for m in mols];mean_sim=[sum(DataStructs.BulkTanimotoSimilarity(f,fps))/len(fps) for f in fps]
 order=sorted(range(len(ids)),key=lambda k:(-mean_sim[k],str(mem.iloc[ids[k]].compound_ids)))
 ref=ids[order[0]];members=[]
 for idx,row,sim in zip(ids,rows,mean_sim):members.append({'row':idx,'id':mem.iloc[idx].compound_ids,'smiles':mem.iloc[idx].canonical,'R1':row['R1'],'mean_within_series_similarity':sim,'reference':idx==ref})
 # Order by R-group canonical isomeric SMILES; tie by ID, independent of activity/prediction.
 members.sort(key=lambda x:(x['R1'],x['id']));g.update(id='S'+str(len(series)+1).zfill(2),members=members,reference_row=ref,post_overlap_count=len(ids));del g['ids'];series.append(g);seen.update(ids)
print('Structural candidates',len(candidates),'retained nonoverlap',len(series),'molecules',len(seen),flush=True)
pred={}
for sp in ['ec','pa']:
 for model in ['P','D','FPD_concat','PD_fusion']:
  pred[sp,model]=np.mean([np.load(R/f'predictions_{sp}_{s}.npz')[model] for s in SEEDS],axis=0)
records=[];molrecords=[]
for g in series:
 ids=[m['row'] for m in g['members']];y=mem.iloc[ids].delta_log2_pa_minus_ec.to_numpy();a,b=np.array(list(combinations(range(len(ids)),2))).T
 for model in ['P','D','FPD_concat','PD_fusion']:
  ec=pred['ec',model][ids];pa=pred['pa',model][ids];p=pa-ec;obs=y[b]-y[a];diff=p[b]-p[a]
  rho=spearmanr(y,p).statistic if len(np.unique(y))>1 and len(np.unique(p))>1 else np.nan
  records.append({'series_id':g['id'],'model':model,'n_molecules':len(ids),'n_pairs':len(obs),'delta_pair_MAE':np.mean(np.abs(diff-obs)),'delta_spearman':rho,'observed_delta_range':np.ptp(y),'n_scaffold_groups':int(mem.iloc[ids].boundary_group.nunique()),'scaffold_groups':';'.join(sorted(mem.iloc[ids].boundary_group.unique()))})
 for m in g['members']:
  i=m['row'];rec={'series_id':g['id'],**m,'observed_ec':float(mem.iloc[i].ec_log2_mic),'observed_pa':float(mem.iloc[i].pa_log2_mic),'observed_delta':float(mem.iloc[i].delta_log2_pa_minus_ec)}
  for model in ['P','D','FPD_concat','PD_fusion']:
   rec[f'{model}_ec']=float(pred['ec',model][i]);rec[f'{model}_pa']=float(pred['pa',model][i]);rec[f'{model}_delta']=float(pred['pa',model][i]-pred['ec',model][i])
  molrecords.append(rec)
pd.DataFrame(records).to_csv(OUT/'series_metrics.csv',index=False);member_frame=pd.DataFrame(molrecords);member_frame.insert(1,'series_member_number',member_frame.groupby('series_id').cumcount()+1);member_frame.to_csv(OUT/'series_members_predictions.csv',index=False)
# Attribution for preselected first series, weighted differences relative to its structure medoid.
g=series[0];ids=[x['row'] for x in g['members']];ref=ids.index(g['reference_row']);X=np.load(OLD/'features.npy',mmap_mode='r');attrib=[]
for seed in SEEDS:
 species={}
 for sp in ['ec','pa']:
  pipeline=joblib.load(R/f'fusion_{sp}_{seed}.joblib');sc,lr=[v for _,v in pipeline.steps];weight=lr.coef_/sc.scale_;parts=[]
  for j,(b,cols) in enumerate([('P',slice(85,6396)),('D',slice(6396,6519))]):
   path=OLD/f'models/lgb_P_{sp}_{seed}.txt' if b=='P' else R/f'D_{sp}_{seed}.lgb';model=lgb.Booster(model_file=str(path));v=model.predict(np.asarray(X[ids,cols]),pred_contrib=True,num_threads=4);parts.append(weight[j]*(v[:,:-1]-v[ref,:-1]))
  species[sp]=np.concatenate(parts,axis=1)
 delta=species['pa']-species['ec'];expected=np.load(R/f'predictions_pa_{seed}.npz')['PD_fusion'][ids]-np.load(R/f'predictions_ec_{seed}.npz')['PD_fusion'][ids];np.testing.assert_allclose(delta.sum(axis=1),expected-expected[ref],atol=1e-9);attrib.append(delta)
a=np.stack(attrib);mean=a.mean(axis=0);desc=mean[:,6311:];top=np.argsort(-np.mean(np.abs(desc),axis=0))[:4]
table=[]
for k,m in enumerate(g['members']):
 record={'series_id':g['id'],'row':m['row'],'id':m['id'],'reference':m['reference'],'P_sum':float(mean[k,:6311].sum()),'D_sum':float(desc[k].sum())}
 record.update({names[i]:float(desc[k,i]) for i in top});table.append(record)
pd.DataFrame(table).to_csv(OUT/'selected_series_attribution.csv',index=False)
summary={'candidate_cores':len(candidates),'retained_groups':len(series),'retained_unique_molecules':len(seen),'independent_groups_claimed':False,'note':'Each series may contain multiple Bemis–Murcko boundary groups; different series can also share groups.','selection':"Structural candidate size, common-core size and canonical core; greedy remove molecule overlap; minimum 5 per series; no performance/target in selection.",'target_selected':g['id'],'reference_id':mem.iloc[g['reference_row']].compound_ids,'top_descriptor_contributions':[names[i] for i in top],'series':series}
(OUT/'series_manifest.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
print(pd.DataFrame(records).pivot(index='series_id',columns='model',values='delta_pair_MAE').round(3).to_string());print('Reference',summary['reference_id'],'top descriptors',summary['top_descriptor_contributions'])
