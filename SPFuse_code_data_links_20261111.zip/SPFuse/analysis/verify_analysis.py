from pathlib import Path
import json
import numpy as np,pandas as pd
from itertools import combinations
from rdkit import Chem,DataStructs,RDLogger
from rdkit.Chem import AllChem
RDLogger.DisableLog('rdApp.warning')
R=Path(__file__).resolve().parent;ROOT=R.parents[1];manifest=json.loads((R/'series_manifest.json').read_text());members=pd.read_csv(R/'series_members_predictions.csv');score=pd.read_csv(R/'series_metrics.csv');attr=pd.read_csv(R/'selected_series_attribution.csv');assert members.row.is_unique and len(members)==79
for series in manifest['series']:
 g=members[members.series_id.eq(series['id'])].copy();assert len(g)>=5
 for _,row in g.iterrows():
  combined=Chem.MolFromSmiles(series['core']+'.'+row.R1);z=Chem.molzip(combined)
  assert Chem.MolToSmiles(z,isomericSmiles=True)==Chem.MolToSmiles(Chem.MolFromSmiles(row.smiles),isomericSmiles=True),row.id
 a,b=np.array(list(combinations(range(len(g)),2))).T;y=g.observed_delta.to_numpy();
 for mod in ['P','D','FPD_concat','PD_fusion']:
  pr=g[f'{mod}_delta'].to_numpy();mae=np.mean(np.abs((pr[b]-pr[a])-(y[b]-y[a])));v=score[score.series_id.eq(series['id']) & score.model.eq(mod)].iloc[0];assert abs(v.delta_pair_MAE-mae)<1e-12 and v.n_pairs==len(a)
g=members[members.series_id.eq('S01')].set_index('row');a=attr.set_index('row');ref=g[g.reference].iloc[0];np.testing.assert_allclose(a.P_sum+a.D_sum,g.loc[a.index,'PD_fusion_delta']-ref.PD_fusion_delta,atol=1e-9)
# Independently generate fresh fingerprints from SMILES, not cached fingerprint bits.
from rdkit.Chem import AllChem
for partition in ['official','scaffold']:
 frame=pd.read_csv(R/f'classification_{partition}_test.csv');membership=pd.read_csv(ROOT/f'feature_ablation/runs/fixed_20261108/{partition}/membership.csv');train=membership[membership.group.eq('training')].PROCESSED_SMILES
 fps=[AllChem.GetMorganFingerprintAsBitVect(Chem.MolFromSmiles(s),2,nBits=2048) for s in train]
 lookup=membership.set_index('row').PROCESSED_SMILES
 for row in frame.sample(10,random_state=20261110).itertuples():
  mol=Chem.MolFromSmiles(lookup.loc[row.row]);fp=AllChem.GetMorganFingerprintAsBitVect(mol,2,nBits=2048);val=max(DataStructs.BulkTanimotoSimilarity(fp,fps));assert abs(val-row.nearest_train_tanimoto)<1e-12
bins=pd.read_csv(R/'classification_similarity_bins.csv')
for p in ['official','scaffold']:
 frame=pd.read_csv(R/f'classification_{p}_test.csv');summary=bins[bins.partition.eq(p)];assert summary.n.sum()==len(frame) and summary.n_positive.sum()==frame.TARGET.sum()
for name in ['figure2_chemical_space','figure6_molecular_series']:
 for ext in ['pdf','svg','png']:assert (R/'figures'/f'{name}.{ext}').is_file()
(R/'independent_audit.json').write_text(json.dumps({'passed':True,'molecules_reconstructed':len(members),'series':len(manifest['series']),'model_series_scores_checked':len(score),'neighbor_fingerprints_recomputed':20,'attribution_reconstruction_checked':len(a),'similarity_bins_exhaustive':True},indent=2)+'\n')
print((R/'independent_audit.json').read_text())
